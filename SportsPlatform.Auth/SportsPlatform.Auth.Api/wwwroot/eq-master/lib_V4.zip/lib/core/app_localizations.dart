import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

/// Lightweight, codegen-free localization for the app.
///
/// Why hand-written instead of gen-l10n / .arb files: this compiles the moment
/// `flutter pub get` runs (it only needs `flutter_localizations` from the SDK),
/// with no `flutter gen-l10n` / build_runner step and no generated files to keep
/// in sync. Strings live in the [_values] map keyed by language code.
///
/// Usage in a widget:
///   final t = AppLocalizations.of(context);
///   Text(t.settings);
///
/// RTL is automatic: Flutter flips the layout to right-to-left whenever the
/// active locale is Arabic, because 'ar' is a known RTL language — no manual
/// [Directionality] needed as long as [MaterialApp.locale] / supportedLocales
/// are wired up (see main.dart).
class AppLocalizations {
  AppLocalizations(this.locale);

  final Locale locale;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  /// The single delegate to register in `MaterialApp.localizationsDelegates`.
  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// All locales the app ships translations for.
  static const List<Locale> supportedLocales = [
    Locale('en'),
    Locale('ar'),
  ];

  /// Full bundle of delegates to hand to `MaterialApp.localizationsDelegates`
  /// (our strings + Flutter's Material/Widgets/Cupertino localizations, which
  /// provide translated system widgets, date pickers, and correct text
  /// direction for Arabic).
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = [
    AppLocalizations.delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ];

  /// Maps a saved/selected language code to a supported [Locale], defaulting to
  /// English for anything unrecognised.
  static Locale localeForCode(String code) {
    switch (code) {
      case 'ar':
        return const Locale('ar');
      case 'en':
      default:
        return const Locale('en');
    }
  }

  /// Human-readable name for a language code, shown in the language picker.
  static String displayName(String code) {
    switch (code) {
      case 'ar':
        return 'العربية';
      case 'en':
      default:
        return 'English';
    }
  }

  String get _code => locale.languageCode;

  String _t(String key) {
    return _values[_code]?[key] ?? _values['en']![key] ?? key;
  }

  // ── Settings ──────────────────────────────────────────────────────────────
  String get settings => _t('settings');
  String get language => _t('language');
  String get theme => _t('theme');
  String get lightMode => _t('lightMode');
  String get darkMode => _t('darkMode');
  String get myTeams => _t('myTeams');
  String get myClubs => _t('myClubs');
  String get noTeamsAvailable => _t('noTeamsAvailable');
  String get noClubsAvailable => _t('noClubsAvailable');
  String get teamMember => _t('teamMember');
  String get member => _t('member');
  String get termsOfPrivacy => _t('termsOfPrivacy');
  String get logOut => _t('logOut');
  String get logOutConfirm => _t('logOutConfirm');
  String get yesLogOut => _t('yesLogOut');
  String get leaveTeam => _t('leaveTeam');
  String get leaveClub => _t('leaveClub');

  // ── Common actions ────────────────────────────────────────────────────────
  String get cancel => _t('cancel');
  String get save => _t('save');
  String get delete => _t('delete');
  String get edit => _t('edit');
  String get leave => _t('leave');
  String get next => _t('next');
  String get back => _t('back');
  String get skip => _t('skip');
  String get ok => _t('ok');
  String get retry => _t('retry');

  // ── Navigation tabs ───────────────────────────────────────────────────────
  String get home => _t('home');
  String get events => _t('events');
  String get team => _t('team');
  String get profile => _t('profile');
  String get messages => _t('messages');

  // ── Auth: login ───────────────────────────────────────────────────────────
  String get login => _t('login');
  String get loginTitle => _t('loginTitle');
  String get email => _t('email');
  String get emailOrPhone => _t('emailOrPhone');
  String get password => _t('password');
  String get forgotPassword => _t('forgotPassword');
  String get signIn => _t('signIn');
  String get signInWithGoogle => _t('signInWithGoogle');
  String get noAccount => _t('noAccount');
  String get createAccount => _t('createAccount');

  // ── Auth: reset password ──────────────────────────────────────────────────
  String get resetPassword => _t('resetPassword');
  String get resetPasswordEmailHint => _t('resetPasswordEmailHint');
  String get resetPasswordCodeHint => _t('resetPasswordCodeHint');
  String get sendCode => _t('sendCode');
  String get resendCode => _t('resendCode');
  String get sixDigitCode => _t('sixDigitCode');
  String get newPassword => _t('newPassword');
  String get confirmNewPassword => _t('confirmNewPassword');

  static const Map<String, Map<String, String>> _values = {
    'en': {
      // Settings
      'settings': 'Settings',
      'language': 'Language',
      'theme': 'Theme',
      'lightMode': 'Light',
      'darkMode': 'Dark',
      'myTeams': 'My Teams',
      'myClubs': 'My Clubs',
      'noTeamsAvailable': 'No teams available',
      'noClubsAvailable': 'No clubs available',
      'teamMember': 'Team member',
      'member': 'Member',
      'termsOfPrivacy': 'Terms of privacy',
      'logOut': 'Log out',
      'logOutConfirm': 'Are you sure you want\nto log out ?',
      'yesLogOut': 'Yes Log out',
      'leaveTeam': 'Leave team',
      'leaveClub': 'Leave Club',
      // Common
      'cancel': 'Cancel',
      'save': 'Save',
      'delete': 'Delete',
      'edit': 'Edit',
      'leave': 'Leave',
      'next': 'Next',
      'back': 'Back',
      'skip': 'Skip',
      'ok': 'OK',
      'retry': 'Retry',
      // Nav
      'home': 'Home',
      'events': 'Events',
      'team': 'Team',
      'profile': 'Profile',
      'messages': 'Messages',
      // Login
      'login': 'Login',
      'loginTitle': 'WELCOME BACK',
      'email': 'Email',
      'emailOrPhone': 'Email or phone',
      'password': 'Password',
      'forgotPassword': 'Forgot password?',
      'signIn': 'Sign in',
      'signInWithGoogle': 'Sign in with Google',
      'noAccount': "Don't have an account?",
      'createAccount': 'Create Account',
      // Reset
      'resetPassword': 'Reset password',
      'resetPasswordEmailHint':
          "Enter the email linked to your account and we'll send you a 6-digit code.",
      'resetPasswordCodeHint':
          'Enter the code we emailed you and choose a new password.',
      'sendCode': 'Send code',
      'resendCode': 'Resend code',
      'sixDigitCode': '6-digit code',
      'newPassword': 'New password',
      'confirmNewPassword': 'Confirm new password',
    },
    'ar': {
      // Settings
      'settings': 'الإعدادات',
      'language': 'اللغة',
      'theme': 'المظهر',
      'lightMode': 'فاتح',
      'darkMode': 'داكن',
      'myTeams': 'فِرَقي',
      'myClubs': 'أنديتي',
      'noTeamsAvailable': 'لا توجد فرق متاحة',
      'noClubsAvailable': 'لا توجد أندية متاحة',
      'teamMember': 'عضو في الفريق',
      'member': 'عضو',
      'termsOfPrivacy': 'سياسة الخصوصية',
      'logOut': 'تسجيل الخروج',
      'logOutConfirm': 'هل أنت متأكد أنك تريد\nتسجيل الخروج؟',
      'yesLogOut': 'نعم، تسجيل الخروج',
      'leaveTeam': 'مغادرة الفريق',
      'leaveClub': 'مغادرة النادي',
      // Common
      'cancel': 'إلغاء',
      'save': 'حفظ',
      'delete': 'حذف',
      'edit': 'تعديل',
      'leave': 'مغادرة',
      'next': 'التالي',
      'back': 'رجوع',
      'skip': 'تخطّي',
      'ok': 'حسناً',
      'retry': 'إعادة المحاولة',
      // Nav
      'home': 'الرئيسية',
      'events': 'الأحداث',
      'team': 'الفريق',
      'profile': 'الملف الشخصي',
      'messages': 'الرسائل',
      // Login
      'login': 'تسجيل الدخول',
      'loginTitle': 'مرحباً بعودتك',
      'email': 'البريد الإلكتروني',
      'emailOrPhone': 'البريد الإلكتروني أو الهاتف',
      'password': 'كلمة المرور',
      'forgotPassword': 'هل نسيت كلمة المرور؟',
      'signIn': 'تسجيل الدخول',
      'signInWithGoogle': 'الدخول عبر جوجل',
      'noAccount': 'ليس لديك حساب؟',
      'createAccount': 'إنشاء حساب',
      // Reset
      'resetPassword': 'إعادة تعيين كلمة المرور',
      'resetPasswordEmailHint':
          'أدخل البريد الإلكتروني المرتبط بحسابك وسنرسل لك رمزاً من 6 أرقام.',
      'resetPasswordCodeHint':
          'أدخل الرمز الذي أرسلناه إليك واختر كلمة مرور جديدة.',
      'sendCode': 'إرسال الرمز',
      'resendCode': 'إعادة إرسال الرمز',
      'sixDigitCode': 'رمز من 6 أرقام',
      'newPassword': 'كلمة المرور الجديدة',
      'confirmNewPassword': 'تأكيد كلمة المرور الجديدة',
    },
  };
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      AppLocalizations.supportedLocales
          .any((l) => l.languageCode == locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    // Normalise to a supported locale so an unsupported country/script variant
    // (e.g. ar_EG) still resolves to our base 'ar' strings.
    final normalized = AppLocalizations.localeForCode(locale.languageCode);
    return AppLocalizations(normalized);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
