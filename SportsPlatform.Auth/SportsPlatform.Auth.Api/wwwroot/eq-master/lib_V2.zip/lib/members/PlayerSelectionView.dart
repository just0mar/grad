import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appbar/CustomAppBar.dart';
import '../core/responsive_system.dart';
import '../team/team_bloc.dart';
import 'MemberDetailView.dart';
import 'MemberModel.dart';
import 'UploadPdfView.dart';
import 'UploadVideoView.dart';

class PlayerSelectionView extends StatelessWidget {
  final String userRole;
  final String actionType;

  const PlayerSelectionView({
    super.key,
    required this.userRole,
    required this.actionType,
  });

  String get _title {
    switch (actionType) {
      case 'fitness':
        return 'Select Player - Fitness PDF';
      case 'analysis':
        return 'Select Player - Analysis PDF';
      case 'video':
        return 'Select Player - Analysis Video';
      case 'medical':
        return 'Select Player - Medical Record';
      default:
        return 'Select Player';
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return BlocBuilder<TeamBloc, TeamState>(
      builder: (context, state) {
        final members = state.members
            .where((member) => member.role.trim() == 'Player')
            .toList();

        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: CustomAppBar(title: _title),
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isDark
                    ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                    : [Colors.green, Colors.white],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              image: const DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
                opacity: 0.2,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.only(top: kToolbarHeight + 8),
              child: members.isEmpty
                  ? Center(
                      child: Text(
                        'No players added yet.',
                        style: TextStyle(
                          color: isDark ? Colors.white54 : Colors.black54,
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: ResponsiveSystem.pagePadding(context),
                      itemCount: members.length,
                      itemBuilder: (context, index) {
                        final member = members[index];
                        final originalIndex = state.members.indexOf(member);
                        return _buildMemberTile(
                          context,
                          member,
                          originalIndex,
                          isDark,
                        );
                      },
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildMemberTile(
    BuildContext context,
    Member member,
    int index,
    bool isDark,
  ) {
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final subTextColor = isDark ? Colors.white54 : Colors.black54;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage(member.image),
          radius: 24,
        ),
        title: Text(
          member.name,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: ResponsiveSystem.bodyFontSize(context) + 1,
            color: textColor,
          ),
        ),
        subtitle: Text(
          member.role,
          style: TextStyle(
            fontSize: ResponsiveSystem.bodyFontSize(context) - 1,
            color: subTextColor,
          ),
        ),
        trailing: Icon(
          Icons.chevron_right,
          color: isDark ? Colors.white38 : Colors.black45,
        ),
        onTap: () => _navigate(context, member, index),
      ),
    );
  }

  void _navigate(BuildContext context, Member member, int index) {
    if (actionType == 'medical') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => MemberDetailView(
            member: member,
            memberIndex: index,
          ),
        ),
      );
    } else if (actionType == 'video') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => UploadVideoView(
            member: member,
            memberIndex: index,
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => UploadPdfView(
            member: member,
            memberIndex: index,
            actionType: actionType,
          ),
        ),
      );
    }
  }
}
