import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../gamehistory/GameHistoryModel.dart';
import '../services/api_client.dart';
import '../services/stats_service.dart';

abstract class StatsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadStats extends StatsEvent {
  final String sport;
  final String? clubId;
  final String? teamId;

  LoadStats(this.sport, {this.clubId, this.teamId});

  @override
  List<Object?> get props => [sport, clubId, teamId];
}

class UpdateTableStats extends StatsEvent {
  final List<Map<String, dynamic>> tableRows;

  UpdateTableStats(this.tableRows);

  @override
  List<Object?> get props => [tableRows];
}

class StatsState extends Equatable {
  final List<Map<String, dynamic>> tableRows;
  final List<Map<String, dynamic>> chartLines;
  final List<GameHistory> gameHistory;
  final bool isLoading;
  final String? error;

  const StatsState({
    this.tableRows = const [],
    this.chartLines = const [],
    this.gameHistory = const [],
    this.isLoading = false,
    this.error,
  });

  StatsState copyWith({
    List<Map<String, dynamic>>? tableRows,
    List<Map<String, dynamic>>? chartLines,
    List<GameHistory>? gameHistory,
    bool? isLoading,
    String? error,
    bool clearError = false,
  }) {
    return StatsState(
      tableRows: tableRows ?? this.tableRows,
      chartLines: chartLines ?? this.chartLines,
      gameHistory: gameHistory ?? this.gameHistory,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : error ?? this.error,
    );
  }

  @override
  List<Object?> get props =>
      [tableRows, chartLines, gameHistory, isLoading, error];
}

class StatsBloc extends Bloc<StatsEvent, StatsState> {
  final StatsService _statsService = StatsService();

  StatsBloc() : super(const StatsState()) {
    on<LoadStats>(_onLoadStats);
    on<UpdateTableStats>(_onUpdateTableStats);
  }

  Future<void> _onLoadStats(
    LoadStats event,
    Emitter<StatsState> emit,
  ) async {
    if ((event.clubId ?? '').isEmpty || (event.teamId ?? '').isEmpty) {
      emit(state.copyWith(
        tableRows: const [],
        chartLines: const [],
        gameHistory: const [],
        clearError: true,
      ));
      return;
    }
    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      final aggregates =
          await _statsService.getTeamAggregates(event.clubId!, event.teamId!);
      final matches =
          await _statsService.getMatchHistory(event.clubId!, event.teamId!);
      final tableRows = aggregates.entries
          .where((entry) =>
              entry.value != null && entry.value is! Map && entry.value is! List)
          .map(
            (entry) => {
              'title': entry.key,
              'lastGame': '-',
              'cumulative': '${entry.value}',
            },
          )
          .toList();
      final chartLines = tableRows.take(3).map((row) {
        final index = tableRows.indexOf(row);
        return {
          'label': row['title'],
          'color': [Colors.blue.shade700, Colors.green.shade400, Colors.orange]
              [index % 3],
          'spots': const <double>[0, 0, 0, 0, 0, 0, 0],
        };
      }).toList();
      final history = matches.map((raw) {
        final map = Map<String, dynamic>.from(raw as Map);
        return GameHistory(
          opponent: (map['opponent'] ?? map['opponentName'] ?? 'Match')
              .toString(),
          date: (map['date'] ?? map['playedAt'] ?? '').toString(),
          ourScore: (map['ourScore'] as num?)?.toInt() ??
              (map['teamScore'] as num?)?.toInt() ??
              0,
          theirScore: (map['theirScore'] as num?)?.toInt() ??
              (map['opponentScore'] as num?)?.toInt() ??
              0,
          stats: map.entries
              .where((entry) =>
                  entry.value != null &&
                  entry.value is! Map &&
                  entry.value is! List)
              .map((entry) => {
                    'title': entry.key,
                    'value': '${entry.value}',
                  })
              .toList(),
          pdfFiles: const [],
          videos: const [],
        );
      }).toList();
      emit(state.copyWith(
        tableRows: tableRows,
        chartLines: chartLines,
        gameHistory: history,
        isLoading: false,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(isLoading: false, error: 'Could not load stats.'));
    }
  }

  void _onUpdateTableStats(UpdateTableStats event, Emitter<StatsState> emit) {
    emit(state.copyWith(tableRows: event.tableRows));
  }
}
