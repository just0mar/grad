import 'package:eqq/addplans/AddPlansView.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/api_models.dart';
import '../services/api_client.dart';
import '../services/plan_service.dart';
import '../team/team_bloc.dart';

class PlansView extends StatefulWidget {
  const PlansView({super.key});

  @override
  State<PlansView> createState() => _PlansViewState();
}

class _PlansViewState extends State<PlansView> {
  final PlanService _planService = PlanService();
  List<PlanDto> _plans = const [];
  bool _isLoading = false;
  String _selectedCategory = 'Offensive';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadPlans());
  }

  Future<void> _loadPlans() async {
    final contextInfo = _teamContext();
    if (contextInfo == null) return;
    setState(() => _isLoading = true);
    try {
      final plans = await _planService.getTeamPlans(
        contextInfo.clubId,
        contextInfo.teamId,
      );
      if (!mounted) return;
      setState(() => _plans = plans);
    } on ApiException catch (e) {
      if (!mounted) return;
      _showSnack(e.message);
    } catch (_) {
      if (!mounted) return;
      _showSnack('Could not load plans.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  _TeamContext? _teamContext() {
    final state = context.read<TeamBloc>().state;
    final selected =
        state.availableTeams.where((t) => t.id == state.selectedTeamId).toList();
    if (selected.isEmpty || (selected.first.clubId ?? '').isEmpty) {
      _showSnack('Select a team first.');
      return null;
    }
    return _TeamContext(selected.first.clubId!, state.selectedTeamId);
  }

  Future<void> _deletePlan(PlanDto plan) async {
    final contextInfo = _teamContext();
    if (contextInfo == null) return;
    try {
      await _planService.deletePlan(
        contextInfo.clubId,
        contextInfo.teamId,
        plan.planId,
      );
      await _loadPlans();
    } on ApiException catch (e) {
      _showSnack(e.message);
    } catch (_) {
      _showSnack('Could not delete plan.');
    }
  }

  Future<void> _onPlanAdded(Map<String, dynamic> newPlan) async {
    final contextInfo = _teamContext();
    if (contextInfo == null) return;
    try {
      await _planService.createPlan(
        contextInfo.clubId,
        contextInfo.teamId,
        {
          'title': '${newPlan["category"] ?? "Plan"} plan',
          'description': newPlan['description'] ?? '',
          'content': newPlan['description'] ?? '',
          'visibility': 'Published',
        },
      );
      await _loadPlans();
    } on ApiException catch (e) {
      _showSnack(e.message);
    } catch (_) {
      _showSnack('Could not add plan.');
    }
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: RefreshIndicator(
        onRefresh: _loadPlans,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                Expanded(
                  child: _categoryButton('Offensive', isDark, textColor),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _categoryButton('Defensive', isDark, textColor),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    backgroundColor: Colors.blueGrey,
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AddPlanScreen(onPlanAdded: _onPlanAdded),
                      ),
                    );
                  },
                  child: const Icon(Icons.add, size: 20),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (_isLoading)
              const Center(child: CircularProgressIndicator())
            else if (_plans.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 40),
                  child: Text(
                    'No plans yet.\nTap + to add one.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16,
                      color: isDark ? Colors.white70 : Colors.black54,
                    ),
                  ),
                ),
              )
            else
              ..._plans.map(
                (plan) => Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: isDark
                        ? cardBg
                        : Colors.white.withValues(alpha: 0.9),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              plan.title,
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: textColor,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.delete,
                              color: isDark ? Colors.white54 : Colors.black54,
                            ),
                            onPressed: () => _deletePlan(plan),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        plan.description?.isNotEmpty == true
                            ? plan.description!
                            : plan.visibility ?? 'Plan',
                        style: TextStyle(fontSize: 16, color: textColor),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _categoryButton(String category, bool isDark, Color textColor) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 10),
        backgroundColor: _selectedCategory == category
            ? Colors.green
            : isDark
                ? const Color(0xFF1B3A2D)
                : Colors.grey.shade300,
        foregroundColor: _selectedCategory == category ? Colors.white : textColor,
        textStyle: const TextStyle(fontSize: 13),
      ),
      onPressed: () => setState(() => _selectedCategory = category),
      child: Text(category),
    );
  }
}

class _TeamContext {
  final String clubId;
  final String teamId;

  const _TeamContext(this.clubId, this.teamId);
}
