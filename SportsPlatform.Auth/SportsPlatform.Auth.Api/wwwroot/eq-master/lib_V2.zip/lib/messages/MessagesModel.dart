class TeamMember {
  final String conversationId;
  final String name;
  final String role;
  final String image;
  final int unreadCount;

  TeamMember({
    this.conversationId = '',
    required this.name,
    required this.role,
    required this.image,
    this.unreadCount = 0,
  });
}
