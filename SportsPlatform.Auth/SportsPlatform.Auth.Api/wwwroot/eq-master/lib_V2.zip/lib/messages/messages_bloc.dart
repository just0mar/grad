import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../services/api_client.dart';
import '../services/messaging_service.dart';
import 'MessagesModel.dart';

abstract class MessagesEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadMessages extends MessagesEvent {}

class SearchMembers extends MessagesEvent {
  final String query;

  SearchMembers(this.query);

  @override
  List<Object?> get props => [query];
}

class MessagesState extends Equatable {
  final List<TeamMember> members;
  final List<TeamMember> filteredMembers;
  final bool isLoading;
  final String? error;

  const MessagesState({
    this.members = const [],
    this.filteredMembers = const [],
    this.isLoading = false,
    this.error,
  });

  MessagesState copyWith({
    List<TeamMember>? members,
    List<TeamMember>? filteredMembers,
    bool? isLoading,
    String? error,
    bool clearError = false,
  }) {
    return MessagesState(
      members: members ?? this.members,
      filteredMembers: filteredMembers ?? this.filteredMembers,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : error ?? this.error,
    );
  }

  @override
  List<Object?> get props => [members, filteredMembers, isLoading, error];
}

class MessagesBloc extends Bloc<MessagesEvent, MessagesState> {
  final MessagingService _messagingService = MessagingService();

  MessagesBloc() : super(const MessagesState()) {
    on<LoadMessages>(_onLoadMessages);
    on<SearchMembers>(_onSearchMembers);
  }

  Future<void> _onLoadMessages(
    LoadMessages event,
    Emitter<MessagesState> emit,
  ) async {
    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      final conversations = await _messagingService.getConversations();
      final members = conversations.map((conversation) {
        final title = conversation.title?.isNotEmpty == true
            ? conversation.title!
            : conversation.participants.map((p) => p.name).join(', ');
        return TeamMember(
          conversationId: conversation.conversationId,
          name: title.isNotEmpty ? title : 'Conversation',
          role: conversation.lastMessage?.isNotEmpty == true
              ? conversation.lastMessage!
              : 'No messages yet',
          image: 'assets/profile.png',
          unreadCount: conversation.unreadCount,
        );
      }).toList();
      emit(state.copyWith(
        members: members,
        filteredMembers: members,
        isLoading: false,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(
        isLoading: false,
        error: 'Could not load conversations.',
      ));
    }
  }

  void _onSearchMembers(SearchMembers event, Emitter<MessagesState> emit) {
    if (event.query.isEmpty) {
      emit(state.copyWith(filteredMembers: state.members));
    } else {
      final filtered = state.members
          .where((m) => m.name.toLowerCase().contains(event.query.toLowerCase()))
          .toList();
      emit(state.copyWith(filteredMembers: filtered));
    }
  }
}
