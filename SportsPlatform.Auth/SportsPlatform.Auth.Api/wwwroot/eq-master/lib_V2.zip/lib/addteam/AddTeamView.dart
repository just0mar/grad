import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appbar/CustomAppBar.dart';
import '../core/responsive_system.dart';
import '../core/responsive_widgets.dart';
import '../services/api_client.dart';
import '../services/team_service.dart';
import 'AddTeamModel.dart';
import 'add_team_bloc.dart';

class AddTeamView extends StatelessWidget {
  const AddTeamView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AddTeamBloc()..add(LoadAddTeamOptions()),
      child: const _AddTeamContent(),
    );
  }
}

class _AddTeamContent extends StatefulWidget {
  const _AddTeamContent();

  @override
  State<_AddTeamContent> createState() => _AddTeamContentState();
}

class _AddTeamContentState extends State<_AddTeamContent> {
  final TeamService _teamService = TeamService();
  bool _isSaving = false;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final labelColor = isDark ? Colors.white70 : null;
    final textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: 'ADD TEAM'),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            image: const DecorationImage(
              image: AssetImage('assets/background.png'),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(top: kToolbarHeight + 48),
            child: SafeArea(
              top: false,
              child: BlocConsumer<AddTeamBloc, AddTeamState>(
                listener: (context, state) {
                  if (state.error != null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(state.error!)),
                    );
                  }
                },
                builder: (context, state) {
                  return SingleChildScrollView(
                    padding: ResponsiveSystem.pagePadding(context),
                    child: Column(
                      children: [
                        _buildDropdown(
                          context,
                          label: 'Country',
                          items: state.countries,
                          currentValue: state.selectedCountry,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(CountryChanged(val)),
                        ),
                        const SizedBox(height: 16),
                        _buildDropdown(
                          context,
                          label: 'Club',
                          items: state.clubs,
                          currentValue: state.selectedClub,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(ClubChanged(val)),
                        ),
                        const SizedBox(height: 16),
                        _buildDropdown(
                          context,
                          label: 'Sport',
                          items: state.sports,
                          currentValue: state.selectedSport,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(SportChanged(val)),
                        ),
                        const SizedBox(height: 16),
                        _buildDropdown(
                          context,
                          label: 'Team Category',
                          items: state.categories,
                          currentValue: state.selectedCategory,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(CategoryChanged(val)),
                        ),
                        const SizedBox(height: 24),
                        ResponsivePrimaryButton.icon(
                          context: context,
                          backgroundColor: fieldColor,
                          foregroundColor: isDark ? Colors.white : Colors.green,
                          icon: Icons.location_on,
                          label: 'Allow Location',
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Location is not required by the backend for teams.',
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 24),
                        ResponsivePrimaryButton(
                          context: context,
                          label: _isSaving ? 'Adding...' : 'Add Team',
                          onPressed: () async {
                            if (_isSaving) return;
                            final selectedClub = state.selectedClubDto;
                            final selectedCategory = state.selectedCategoryDto;
                            if (selectedClub == null ||
                                selectedCategory == null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'Choose a club and category first.',
                                  ),
                                ),
                              );
                              return;
                            }
                            setState(() => _isSaving = true);
                            try {
                              final now = DateTime.now();
                              final teamName =
                                  '${state.selectedClub ?? selectedClub.name} ${state.selectedCategory ?? selectedCategory.name}';
                              final dto = await _teamService.createTeam(
                                selectedClub.clubId,
                                {
                                  'teamName': teamName,
                                  'categoryId': selectedCategory.categoryId,
                                  'seasonLabel': '${now.year}/${now.year + 1}',
                                  'seasonStartDate':
                                      '${now.year}-01-01',
                                  'seasonEndDate':
                                      '${now.year + 1}-12-31',
                                },
                              );
                              if (!mounted) return;
                              Navigator.pop(
                                context,
                                Team(
                                  id: dto.teamId,
                                  clubId: dto.clubId ?? selectedClub.clubId,
                                  country: state.selectedCountry ?? '',
                                  club: dto.teamName,
                                  sport: state.selectedSport ?? 'Basketball',
                                  category: dto.categoryName ??
                                      state.selectedCategory ??
                                      '',
                                  memberRoles: {'self': dto.myRole ?? ''},
                                ),
                              );
                            } on ApiException catch (e) {
                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(e.message)),
                              );
                            } catch (_) {
                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Could not create team.'),
                                ),
                              );
                            } finally {
                              if (mounted) setState(() => _isSaving = false);
                            }
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown(
    BuildContext context, {
    required String label,
    required List<String> items,
    required String? currentValue,
    required Color fieldColor,
    required Color? labelColor,
    required Color textColor,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      initialValue: currentValue,
      dropdownColor: fieldColor,
      style: TextStyle(
          color: textColor,
          fontFamily: 'SFPro',
          fontSize: ResponsiveSystem.bodyFontSize(context)),
      decoration: InputDecoration(
        filled: true,
        fillColor: fieldColor,
        labelText: label,
        labelStyle: TextStyle(
            color: labelColor,
            fontFamily: 'SFPro',
            fontSize: ResponsiveSystem.bodyFontSize(context)),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
      items: items
          .map(
            (item) => DropdownMenuItem<String>(
              value: item,
              child: Text(item, style: const TextStyle(fontFamily: 'SFPro')),
            ),
          )
          .toList(),
      onChanged: onChanged,
    );
  }
}
