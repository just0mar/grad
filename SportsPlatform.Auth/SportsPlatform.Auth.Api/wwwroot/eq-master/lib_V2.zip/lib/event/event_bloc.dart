import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../services/api_client.dart';
import '../services/event_service.dart';
import 'EventModel.dart';

abstract class EventEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadEvents extends EventEvent {
  final String? clubId;
  final String? teamId;

  LoadEvents({this.clubId, this.teamId});

  @override
  List<Object?> get props => [clubId, teamId];
}

class AddEvent extends EventEvent {
  final Event event;
  final String? clubId;
  final String? teamId;

  AddEvent(this.event, {this.clubId, this.teamId});

  @override
  List<Object?> get props => [event, clubId, teamId];
}

class SelectDay extends EventEvent {
  final DateTime selectedDay;
  final DateTime focusedDay;

  SelectDay(this.selectedDay, this.focusedDay);

  @override
  List<Object?> get props => [selectedDay, focusedDay];
}

class EventState extends Equatable {
  final List<Event> events;
  final DateTime selectedDay;
  final DateTime focusedDay;
  final Map<DateTime, List<Event>> eventsByDay;
  final bool isLoading;
  final String? error;

  EventState({
    this.events = const [],
    DateTime? selectedDay,
    DateTime? focusedDay,
    this.eventsByDay = const {},
    this.isLoading = false,
    this.error,
  })  : selectedDay = selectedDay ?? DateTime.now(),
        focusedDay = focusedDay ?? DateTime.now();

  EventState copyWith({
    List<Event>? events,
    DateTime? selectedDay,
    DateTime? focusedDay,
    Map<DateTime, List<Event>>? eventsByDay,
    bool? isLoading,
    String? error,
    bool clearError = false,
  }) {
    return EventState(
      events: events ?? this.events,
      selectedDay: selectedDay ?? this.selectedDay,
      focusedDay: focusedDay ?? this.focusedDay,
      eventsByDay: eventsByDay ?? this.eventsByDay,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : error ?? this.error,
    );
  }

  List<Event> get upcomingEvents {
    final DateTime now = DateTime.now();
    final List<Event> result = List<Event>.from(
      events.where((e) => e.date.isAfter(now.subtract(const Duration(days: 1)))),
    )..sort((a, b) => a.date.compareTo(b.date));
    return result.take(6).toList();
  }

  @override
  List<Object?> get props => [
        events,
        selectedDay,
        focusedDay,
        eventsByDay,
        isLoading,
        error,
      ];
}

class EventBloc extends Bloc<EventEvent, EventState> {
  final EventService _eventService = EventService();

  EventBloc() : super(EventState()) {
    on<LoadEvents>(_onLoadEvents);
    on<AddEvent>(_onAddEvent);
    on<SelectDay>(_onSelectDay);
  }

  Future<void> _onLoadEvents(
    LoadEvents event,
    Emitter<EventState> emit,
  ) async {
    if ((event.clubId ?? '').isEmpty || (event.teamId ?? '').isEmpty) {
      emit(state.copyWith(
        events: const [],
        eventsByDay: const {},
        isLoading: false,
        clearError: true,
      ));
      return;
    }

    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      final dtos = await _eventService.getTeamEvents(event.clubId!, event.teamId!);
      final events = dtos.map(Event.fromDto).toList()
        ..sort((a, b) => a.date.compareTo(b.date));
      emit(state.copyWith(
        events: events,
        eventsByDay: _rebuildEventsByDay(events),
        isLoading: false,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(
        isLoading: false,
        error: 'Could not load events.',
      ));
    }
  }

  Future<void> _onAddEvent(AddEvent event, Emitter<EventState> emit) async {
    if ((event.clubId ?? '').isEmpty || (event.teamId ?? '').isEmpty) {
      emit(state.copyWith(error: 'Select a team before creating an event.'));
      return;
    }

    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      final season =
          await _eventService.getCurrentTeamSeason(event.clubId!, event.teamId!);
      final startAt = DateTime(
        event.event.date.year,
        event.event.date.month,
        event.event.date.day,
        event.event.time.hour,
        event.event.time.minute,
      );
      final dto = await _eventService.createEvent(
        event.clubId!,
        event.teamId!,
        {
          'seasonId': season.seasonId,
          'title': event.event.description.isNotEmpty
              ? event.event.description
              : event.event.type,
          'eventType': event.event.type,
          'startAt': startAt.toIso8601String(),
          'endAt': startAt.add(const Duration(hours: 2)).toIso8601String(),
          'description': event.event.description,
          'timezone': DateTime.now().timeZoneName,
        },
      );
      final newEvents = List<Event>.from(state.events)..add(Event.fromDto(dto));
      newEvents.sort((a, b) => a.date.compareTo(b.date));
      emit(state.copyWith(
        events: newEvents,
        eventsByDay: _rebuildEventsByDay(newEvents),
        isLoading: false,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(isLoading: false, error: 'Could not create event.'));
    }
  }

  void _onSelectDay(SelectDay event, Emitter<EventState> emit) {
    emit(state.copyWith(
      selectedDay: event.selectedDay,
      focusedDay: event.focusedDay,
    ));
  }

  Map<DateTime, List<Event>> _rebuildEventsByDay(List<Event> events) {
    final map = <DateTime, List<Event>>{};
    for (final event in events) {
      final day = DateTime(event.date.year, event.date.month, event.date.day);
      map.putIfAbsent(day, () => []).add(event);
    }
    return map;
  }
}
