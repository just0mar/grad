class ChatMessage {
  final String messageId;
  final String text;
  final bool fromMe;
  final DateTime sentAt;

  ChatMessage({
    this.messageId = '',
    required this.text,
    required this.fromMe,
    DateTime? sentAt,
  }) : sentAt = sentAt ?? DateTime.now();
}
