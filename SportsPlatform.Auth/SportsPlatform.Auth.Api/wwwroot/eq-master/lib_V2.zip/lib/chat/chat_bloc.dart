import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../services/api_client.dart';
import '../services/messaging_service.dart';
import 'ChatModel.dart';

abstract class ChatEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadChatMessages extends ChatEvent {}

class SendMessage extends ChatEvent {
  final String text;

  SendMessage(this.text);

  @override
  List<Object?> get props => [text];
}

class ChatState extends Equatable {
  final List<ChatMessage> messages;
  final bool isLoading;
  final bool isSending;
  final String? error;

  const ChatState({
    this.messages = const [],
    this.isLoading = false,
    this.isSending = false,
    this.error,
  });

  ChatState copyWith({
    List<ChatMessage>? messages,
    bool? isLoading,
    bool? isSending,
    String? error,
    bool clearError = false,
  }) {
    return ChatState(
      messages: messages ?? this.messages,
      isLoading: isLoading ?? this.isLoading,
      isSending: isSending ?? this.isSending,
      error: clearError ? null : error ?? this.error,
    );
  }

  @override
  List<Object?> get props => [messages, isLoading, isSending, error];
}

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final MessagingService _messagingService = MessagingService();
  final String conversationId;
  final String currentUserId;

  ChatBloc({
    required this.conversationId,
    required this.currentUserId,
  }) : super(const ChatState()) {
    on<LoadChatMessages>(_onLoadChatMessages);
    on<SendMessage>(_onSendMessage);
  }

  Future<void> _onLoadChatMessages(
    LoadChatMessages event,
    Emitter<ChatState> emit,
  ) async {
    if (conversationId.isEmpty) {
      emit(state.copyWith(error: 'Conversation is missing.'));
      return;
    }
    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      final messages = await _messagingService.getMessages(conversationId);
      await _messagingService.markRead(conversationId);
      emit(state.copyWith(
        messages: messages
            .map(
              (message) => ChatMessage(
                messageId: message.messageId,
                text: message.content,
                fromMe: message.senderUserId == currentUserId,
                sentAt: message.sentAt,
              ),
            )
            .toList(),
        isLoading: false,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(isLoading: false, error: 'Could not load chat.'));
    }
  }

  Future<void> _onSendMessage(
    SendMessage event,
    Emitter<ChatState> emit,
  ) async {
    final text = event.text.trim();
    if (text.isEmpty || state.isSending) return;
    emit(state.copyWith(isSending: true, clearError: true));
    try {
      final sent = await _messagingService.sendMessage(conversationId, text);
      final updatedMessages = List<ChatMessage>.from(state.messages)
        ..add(
          ChatMessage(
            messageId: sent.messageId,
            text: sent.content,
            fromMe: true,
            sentAt: sent.sentAt,
          ),
        );
      emit(state.copyWith(messages: updatedMessages, isSending: false));
    } on ApiException catch (e) {
      emit(state.copyWith(isSending: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(isSending: false, error: 'Could not send message.'));
    }
  }
}
