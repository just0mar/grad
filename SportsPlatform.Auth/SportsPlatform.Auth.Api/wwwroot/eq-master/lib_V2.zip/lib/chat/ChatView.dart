import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../core/responsive_system.dart';
import 'ChatInputBar.dart';
import 'chat_bloc.dart';

class ChatView extends StatelessWidget {
  final String conversationId;
  final String personName;
  final String personImage;
  final String currentUserId;

  const ChatView({
    super.key,
    required this.conversationId,
    required this.personName,
    required this.personImage,
    required this.currentUserId,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return BlocProvider(
      create: (context) => ChatBloc(
        conversationId: conversationId,
        currentUserId: currentUserId,
      )..add(LoadChatMessages()),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: CustomAppBar(title: personName),
        body: SizedBox.expand(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: isDark
                    ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                    : [Colors.green, Colors.white],
              ),
              image: const DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
                opacity: 0.2,
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  Expanded(
                    child: BlocConsumer<ChatBloc, ChatState>(
                      listener: (context, state) {
                        if (state.error != null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(state.error!)),
                          );
                        }
                      },
                      builder: (context, state) {
                        if (state.isLoading) {
                          return const Center(child: CircularProgressIndicator());
                        }
                        if (state.messages.isEmpty) {
                          return Center(
                            child: Text(
                              'No messages yet.',
                              style: TextStyle(
                                color: isDark ? Colors.white70 : Colors.black54,
                                fontFamily: 'SFPro',
                              ),
                            ),
                          );
                        }
                        return ListView.builder(
                          padding: ResponsiveSystem.pagePadding(context),
                          itemCount: state.messages.length,
                          itemBuilder: (context, index) {
                            final message = state.messages[index];
                            return Row(
                              mainAxisAlignment: message.fromMe
                                  ? MainAxisAlignment.end
                                  : MainAxisAlignment.start,
                              children: [
                                if (!message.fromMe)
                                  const CircleAvatar(
                                    backgroundColor: Colors.grey,
                                    child: Icon(
                                      Icons.person,
                                      color: Colors.white,
                                    ),
                                  ),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Container(
                                    padding: const EdgeInsets.all(12),
                                    margin: const EdgeInsets.symmetric(
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: message.fromMe
                                          ? (isDark
                                                ? AppColors.primaryDark
                                                : AppColors.primaryLight)
                                          : isDark
                                          ? const Color(0xFF1B3A2D)
                                          : Colors.grey[200],
                                      borderRadius: BorderRadius.circular(30),
                                    ),
                                    child: Text(
                                      message.text,
                                      style: TextStyle(
                                        fontFamily: 'SFPro',
                                        color: message.fromMe
                                            ? (isDark
                                                  ? Colors.white
                                                  : Colors.black)
                                            : isDark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                if (message.fromMe)
                                  const CircleAvatar(
                                    backgroundColor: Colors.green,
                                    child: Icon(
                                      Icons.person,
                                      color: Colors.white,
                                    ),
                                  ),
                              ],
                            );
                          },
                        );
                      },
                    ),
                  ),
                  Builder(
                    builder: (context) {
                      return ChatInputBar(
                        onSend: (text) {
                          context.read<ChatBloc>().add(SendMessage(text));
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
