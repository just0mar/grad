import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../addteam/AddTeamModel.dart';
import '../announcement/AnnouncementModel.dart';
import '../services/announcement_service.dart';
import '../services/api_client.dart';
import '../services/team_service.dart';

abstract class HomeEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadHomeData extends HomeEvent {
  final String? clubId;
  final String? teamId;

  LoadHomeData({this.clubId, this.teamId});

  @override
  List<Object?> get props => [clubId, teamId];
}

class AddTeamEvent extends HomeEvent {
  final Team team;

  AddTeamEvent(this.team);

  @override
  List<Object?> get props => [team];
}

class AddAnnouncementEvent extends HomeEvent {
  final Announcement announcement;
  final String? clubId;
  final String? teamId;

  AddAnnouncementEvent(this.announcement, {this.clubId, this.teamId});

  @override
  List<Object?> get props => [announcement, clubId, teamId];
}

class HomeState extends Equatable {
  final List<Team?> teams;
  final List<Announcement> announcements;
  final bool isLoading;
  final String? error;

  const HomeState({
    this.teams = const [],
    this.announcements = const [],
    this.isLoading = false,
    this.error,
  });

  HomeState copyWith({
    List<Team?>? teams,
    List<Announcement>? announcements,
    bool? isLoading,
    String? error,
    bool clearError = false,
  }) {
    return HomeState(
      teams: teams ?? this.teams,
      announcements: announcements ?? this.announcements,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : error ?? this.error,
    );
  }

  @override
  List<Object?> get props => [teams, announcements, isLoading, error];
}

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final TeamService _teamService = TeamService();
  final AnnouncementService _announcementService = AnnouncementService();

  HomeBloc() : super(const HomeState()) {
    on<LoadHomeData>(_onLoadHomeData);
    on<AddTeamEvent>(_onAddTeam);
    on<AddAnnouncementEvent>(_onAddAnnouncement);
  }

  Future<void> _onLoadHomeData(
    LoadHomeData event,
    Emitter<HomeState> emit,
  ) async {
    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      final teamDtos = await _teamService.getMyTeams();
      final teams = teamDtos
          .map(
            (team) => Team(
              id: team.teamId,
              clubId: team.clubId,
              country: '',
              club: team.teamName,
              sport: 'Basketball',
              category: team.clubName ?? team.categoryName ?? '',
              memberRoles: {'self': team.myRole ?? ''},
            ),
          )
          .cast<Team?>()
          .toList();

      final announcements =
          (event.clubId ?? '').isEmpty || (event.teamId ?? '').isEmpty
              ? <Announcement>[]
              : (await _announcementService.getTeamAnnouncements(
                  event.clubId!,
                  event.teamId!,
                ))
                  .map(
                    (a) => Announcement(
                      authorName: a.creatorName.isNotEmpty
                          ? a.creatorName
                          : 'Team announcement',
                      authorRole: a.priority,
                      authorImage: 'assets/profile.png',
                      caption: a.content.isNotEmpty ? a.content : a.title,
                      isEmergency: a.priority.toLowerCase() == 'urgent' ||
                          a.priority.toLowerCase() == 'emergency',
                    ),
                  )
                  .toList();

      emit(state.copyWith(
        teams: teams,
        announcements: announcements,
        isLoading: false,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(isLoading: false, error: 'Could not load home data.'));
    }
  }

  void _onAddTeam(AddTeamEvent event, Emitter<HomeState> emit) {
    final newTeams = List<Team?>.from(state.teams)..add(event.team);
    emit(state.copyWith(teams: newTeams));
  }

  Future<void> _onAddAnnouncement(
    AddAnnouncementEvent event,
    Emitter<HomeState> emit,
  ) async {
    if ((event.clubId ?? '').isEmpty || (event.teamId ?? '').isEmpty) {
      emit(state.copyWith(error: 'Select a team before posting announcements.'));
      return;
    }
    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      final dto = await _announcementService.createAnnouncement(
        event.clubId!,
        event.teamId!,
        {
          'title': event.announcement.caption.split('\n').first,
          'content': event.announcement.caption,
          'priority': event.announcement.isEmergency ? 'Urgent' : 'Normal',
        },
      );
      final created = Announcement(
        authorName: dto.creatorName.isNotEmpty ? dto.creatorName : 'Me',
        authorRole: dto.priority,
        authorImage: 'assets/profile.png',
        caption: dto.content.isNotEmpty ? dto.content : dto.title,
        isEmergency: dto.priority.toLowerCase() == 'urgent' ||
            dto.priority.toLowerCase() == 'emergency',
      );
      final newAnnouncements = List<Announcement>.from(state.announcements)
        ..insert(0, created);
      emit(state.copyWith(
        announcements: newAnnouncements,
        isLoading: false,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, error: e.message));
    } catch (_) {
      emit(state.copyWith(
        isLoading: false,
        error: 'Could not post announcement.',
      ));
    }
  }
}
