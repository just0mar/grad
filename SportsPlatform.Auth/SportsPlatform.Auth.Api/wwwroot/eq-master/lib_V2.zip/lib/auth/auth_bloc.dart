import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/api_models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';

abstract class AuthEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoginRequested extends AuthEvent {
  final String email;
  final String password;

  LoginRequested({required this.email, required this.password, String? role});

  @override
  List<Object?> get props => [email, password];
}

class SignUpRequested extends AuthEvent {
  final String email;
  final String name;
  final String password;
  final String dob;
  final String? phone;

  SignUpRequested({
    required this.email,
    required this.name,
    required this.password,
    required this.dob,
    this.phone,
    String? role,
    String? age,
  });

  @override
  List<Object?> get props => [email, name, password, dob, phone];
}

class LogoutRequested extends AuthEvent {}

abstract class AuthState extends Equatable {
  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class Authenticated extends AuthState {
  final AuthResponse auth;
  final String role;
  final String userId;

  Authenticated({required this.auth})
      : role = auth.user?.email ?? '',
        userId = auth.user?.userId ?? '';

  @override
  List<Object?> get props => [auth, role, userId];
}

class AuthError extends AuthState {
  final String message;

  AuthError(this.message);

  @override
  List<Object?> get props => [message];
}

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthService _authService = AuthService();

  AuthBloc() : super(AuthInitial()) {
    on<LoginRequested>(_onLoginRequested);
    on<SignUpRequested>(_onSignUpRequested);
    on<LogoutRequested>((_, emit) => emit(AuthInitial()));
  }

  Future<void> _onLoginRequested(
    LoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final auth = await _authService.login(event.email, event.password);
      emit(Authenticated(auth: auth));
    } on ApiException catch (e) {
      emit(AuthError(_friendly(e)));
    } catch (_) {
      emit(AuthError('Network error. Check the backend and try again.'));
    }
  }

  Future<void> _onSignUpRequested(
    SignUpRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final auth = await _authService.register(
        name: event.name,
        email: event.email,
        password: event.password,
        dob: event.dob,
        phone: event.phone,
      );
      emit(Authenticated(auth: auth));
    } on ApiException catch (e) {
      emit(AuthError(_friendly(e)));
    } catch (_) {
      emit(AuthError('Network error. Check the backend and try again.'));
    }
  }

  String _friendly(ApiException e) {
    if (e.isUnauthorized) return 'Invalid email or password.';
    if (e.isForbidden) return 'You do not have permission for this action.';
    if (e.isNotFound) return 'The requested resource was not found.';
    return e.message;
  }
}
