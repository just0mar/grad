import '../models/api_models.dart';
import 'api_client.dart';

class MessagingService {
  final ApiClient _api = ApiClient.instance;

  Future<List<ConversationDto>> getConversations() async {
    final json = await _api.get('/messages/conversations');
    return (json as List)
        .map((e) =>
            ConversationDto.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<ConversationDto> createConversation({
    required List<String> participantIds,
    String? name,
    bool isGroup = false,
  }) async {
    final json = await _api.post('/messages/conversations', body: {
      'participantUserIds': participantIds,
      if (name != null && name.isNotEmpty) 'name': name,
      'isGroup': isGroup,
    });
    return ConversationDto.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<List<MessageDto>> getMessages(String conversationId) async {
    final json =
        await _api.get('/messages/conversations/$conversationId/messages');
    return (json as List)
        .map((e) => MessageDto.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<MessageDto> sendMessage(String conversationId, String content) async {
    final json = await _api.post(
      '/messages/conversations/$conversationId/messages',
      body: {'content': content},
    );
    return MessageDto.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<void> markRead(String conversationId) async {
    await _api.post('/messages/conversations/$conversationId/read');
  }
}
