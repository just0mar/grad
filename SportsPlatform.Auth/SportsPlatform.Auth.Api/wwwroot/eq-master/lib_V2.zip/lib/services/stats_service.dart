import 'api_client.dart';

class StatsService {
  final ApiClient _api = ApiClient.instance;

  Future<Map<String, dynamic>> getTeamAggregates(
      String clubId, String teamId) async {
    final json = await _api.get('/clubs/$clubId/teams/$teamId/stats');
    return Map<String, dynamic>.from(json as Map);
  }

  Future<List<dynamic>> getMatchHistory(String clubId, String teamId) async {
    final json = await _api.get('/clubs/$clubId/teams/$teamId/stats/matches');
    return json as List<dynamic>;
  }

  Future<dynamic> getPlayerAggregate(
      String clubId, String teamId, String playerId) {
    return _api.get('/clubs/$clubId/teams/$teamId/stats/players/$playerId');
  }

  Future<dynamic> createStats(
      String clubId, String teamId, Map<String, dynamic> body) {
    return _api.post('/clubs/$clubId/teams/$teamId/stats', body: body);
  }

  Future<dynamic> uploadStatsFile(
      String clubId, String teamId, String eventId, String filePath, String fileName) {
    return _api.uploadFile(
      '/clubs/$clubId/teams/$teamId/stats/upload',
      fileField: 'file',
      filePath: filePath,
      fileName: fileName,
      fields: {'eventId': eventId},
    );
  }
}
