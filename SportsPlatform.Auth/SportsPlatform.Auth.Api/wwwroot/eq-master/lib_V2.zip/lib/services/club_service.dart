import '../models/api_models.dart';
import 'api_client.dart';

class ClubService {
  final ApiClient _api = ApiClient.instance;

  Future<List<ClubDto>> getMyClubs() async {
    final json = await _api.get('/clubs/my');
    return (json as List)
        .map((e) => ClubDto.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<ClubDto> createClub(String name) async {
    final json = await _api.post('/clubs', body: {'name': name});
    return ClubDto.fromJson(Map<String, dynamic>.from(json as Map));
  }
}
