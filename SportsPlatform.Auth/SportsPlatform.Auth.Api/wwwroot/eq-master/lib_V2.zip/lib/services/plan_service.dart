import '../models/api_models.dart';
import 'api_client.dart';

class PlanService {
  final ApiClient _api = ApiClient.instance;

  Future<List<PlanDto>> getTeamPlans(String clubId, String teamId) async {
    final json = await _api.get('/clubs/$clubId/teams/$teamId/plans');
    return (json as List)
        .map((e) => PlanDto.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<PlanDto> createPlan(
      String clubId, String teamId, Map<String, dynamic> body) async {
    final json =
        await _api.post('/clubs/$clubId/teams/$teamId/plans', body: body);
    return PlanDto.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<void> deletePlan(String clubId, String teamId, String planId) async {
    await _api.delete('/clubs/$clubId/teams/$teamId/plans/$planId');
  }

  Future<List<LineupDto>> getLineups(String clubId, String teamId) async {
    final json = await _api.get('/clubs/$clubId/teams/$teamId/lineups');
    return (json as List)
        .map((e) => LineupDto.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<LineupDto> createLineup(
      String clubId, String teamId, Map<String, dynamic> body) async {
    final json =
        await _api.post('/clubs/$clubId/teams/$teamId/lineups', body: body);
    return LineupDto.fromJson(Map<String, dynamic>.from(json as Map));
  }
}
