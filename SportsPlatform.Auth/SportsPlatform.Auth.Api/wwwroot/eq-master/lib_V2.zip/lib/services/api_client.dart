import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';

class ApiClient {
  ApiClient._();
  static final ApiClient instance = ApiClient._();

  final http.Client _client = http.Client();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  bool _refreshing = false;
  final List<Completer<void>> _waiters = [];

  Future<String?> get accessToken =>
      _storage.read(key: AppConfig.accessTokenKey);

  Future<String?> getRefreshToken() =>
      _storage.read(key: AppConfig.refreshTokenKey);

  Future<String?> getUser() => _storage.read(key: AppConfig.userKey);

  Future<void> saveUser(String json) =>
      _storage.write(key: AppConfig.userKey, value: json);

  Future<void> saveTokens({
    required String accessToken,
    required String refreshToken,
  }) async {
    await _storage.write(key: AppConfig.accessTokenKey, value: accessToken);
    await _storage.write(key: AppConfig.refreshTokenKey, value: refreshToken);
  }

  Future<void> saveActiveTeam(String teamId) =>
      _storage.write(key: AppConfig.activeTeamKey, value: teamId);

  Future<String?> getActiveTeam() =>
      _storage.read(key: AppConfig.activeTeamKey);

  Future<void> saveActiveClub(String clubId) =>
      _storage.write(key: AppConfig.activeClubKey, value: clubId);

  Future<String?> getActiveClub() =>
      _storage.read(key: AppConfig.activeClubKey);

  Future<void> clearSession() async {
    await _storage.delete(key: AppConfig.accessTokenKey);
    await _storage.delete(key: AppConfig.refreshTokenKey);
    await _storage.delete(key: AppConfig.userKey);
    await _storage.delete(key: AppConfig.activeTeamKey);
    await _storage.delete(key: AppConfig.activeClubKey);
  }

  Future<dynamic> get(String path, {Map<String, String>? queryParams}) async {
    final uri = _uri(path, queryParams);
    var response = await _client.get(uri, headers: await _headers());
    if (response.statusCode == 401 && await _tryRefresh()) {
      response = await _client.get(uri, headers: await _headers());
    }
    return _handle(response);
  }

  Future<dynamic> post(String path, {Object? body}) async {
    final uri = _uri(path);
    final encoded = body == null ? null : jsonEncode(body);
    var response =
        await _client.post(uri, headers: await _headers(), body: encoded);
    if (response.statusCode == 401 && await _tryRefresh()) {
      response =
          await _client.post(uri, headers: await _headers(), body: encoded);
    }
    return _handle(response);
  }

  Future<dynamic> put(String path, {Object? body}) async {
    final uri = _uri(path);
    final encoded = body == null ? null : jsonEncode(body);
    var response =
        await _client.put(uri, headers: await _headers(), body: encoded);
    if (response.statusCode == 401 && await _tryRefresh()) {
      response =
          await _client.put(uri, headers: await _headers(), body: encoded);
    }
    return _handle(response);
  }

  Future<dynamic> patch(String path, {Object? body}) async {
    final uri = _uri(path);
    final encoded = body == null ? null : jsonEncode(body);
    var response =
        await _client.patch(uri, headers: await _headers(), body: encoded);
    if (response.statusCode == 401 && await _tryRefresh()) {
      response =
          await _client.patch(uri, headers: await _headers(), body: encoded);
    }
    return _handle(response);
  }

  Future<dynamic> delete(String path) async {
    final uri = _uri(path);
    var response = await _client.delete(uri, headers: await _headers());
    if (response.statusCode == 401 && await _tryRefresh()) {
      response = await _client.delete(uri, headers: await _headers());
    }
    return _handle(response);
  }

  Future<dynamic> uploadFile(
    String path, {
    required String fileField,
    required String filePath,
    required String fileName,
    Map<String, String>? fields,
  }) async {
    final request = http.MultipartRequest('POST', _uri(path));
    final token = await accessToken;
    if (token != null) request.headers['Authorization'] = 'Bearer $token';
    if (fields != null) request.fields.addAll(fields);
    request.files.add(
      await http.MultipartFile.fromPath(
        fileField,
        filePath,
        filename: fileName,
      ),
    );
    final streamed = await _client.send(request);
    return _handle(await http.Response.fromStream(streamed));
  }

  Future<Map<String, String>> _headers() async {
    final token = await accessToken;
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  Uri _uri(String path, [Map<String, String>? queryParams]) {
    final base = Uri.parse(AppConfig.baseUrl);
    return base.replace(
      path: path.startsWith('/') ? path : '/$path',
      queryParameters: queryParams,
    );
  }

  dynamic _handle(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.body.isEmpty) return null;
      return jsonDecode(response.body);
    }

    var message = 'Request failed with status ${response.statusCode}';
    try {
      final body = jsonDecode(response.body);
      if (body is Map<String, dynamic>) {
        message = (body['error'] ?? body['message'] ?? body['title'] ?? message)
            .toString();
      }
    } catch (_) {}
    throw ApiException(response.statusCode, message);
  }

  Future<bool> _tryRefresh() async {
    if (_refreshing) {
      final completer = Completer<void>();
      _waiters.add(completer);
      await completer.future;
      return (await accessToken) != null;
    }

    _refreshing = true;
    try {
      final refreshToken = await getRefreshToken();
      if (refreshToken == null || refreshToken.isEmpty) return false;
      final response = await _client.post(
        _uri('/auth/refresh'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'refreshToken': refreshToken}),
      );
      if (response.statusCode != 200) {
        await clearSession();
        return false;
      }
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      await saveTokens(
        accessToken: json['accessToken'].toString(),
        refreshToken: (json['refreshToken'] ?? refreshToken).toString(),
      );
      for (final waiter in _waiters) {
        waiter.complete();
      }
      return true;
    } catch (e) {
      debugPrint('Token refresh failed: $e');
      await clearSession();
      return false;
    } finally {
      for (final waiter in _waiters.where((w) => !w.isCompleted)) {
        waiter.complete();
      }
      _waiters.clear();
      _refreshing = false;
    }
  }
}

class ApiException implements Exception {
  final int statusCode;
  final String message;

  const ApiException(this.statusCode, this.message);

  bool get isUnauthorized => statusCode == 401;
  bool get isForbidden => statusCode == 403;
  bool get isNotFound => statusCode == 404;

  @override
  String toString() => 'ApiException($statusCode): $message';
}
