import '../models/api_models.dart';
import 'api_client.dart';

class AuthService {
  final ApiClient _api = ApiClient.instance;

  Future<AuthResponse> login(String email, String password) async {
    final json = await _api.post('/auth/login', body: {
      'email': email,
      'password': password,
    });
    return AuthResponse.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<AuthResponse> register({
    required String name,
    required String email,
    required String password,
    required String dob,
    String? phone,
    String? username,
  }) async {
    final json = await _api.post('/auth/register', body: {
      'name': name,
      'email': email,
      'password': password,
      'dob': dob,
      if (phone != null && phone.isNotEmpty) 'phone': phone,
      if (username != null && username.isNotEmpty) 'username': username,
    });
    return AuthResponse.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<void> logout(String refreshToken) async {
    await _api.post('/auth/logout', body: {'refreshToken': refreshToken});
  }
}
