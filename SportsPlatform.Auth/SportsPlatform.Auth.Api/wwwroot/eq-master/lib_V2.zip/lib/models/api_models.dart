class AuthResponse {
  final String? accessToken;
  final String? refreshToken;
  final UserInfo? user;

  const AuthResponse({this.accessToken, this.refreshToken, this.user});

  factory AuthResponse.fromJson(Map<String, dynamic> json) => AuthResponse(
        accessToken: json['accessToken']?.toString(),
        refreshToken: json['refreshToken']?.toString(),
        user: json['user'] is Map<String, dynamic>
            ? UserInfo.fromJson(json['user'] as Map<String, dynamic>)
            : null,
      );
}

class UserInfo {
  final String userId;
  final String name;
  final String email;
  final String? username;
  final String? phone;
  final String? dob;

  const UserInfo({
    required this.userId,
    required this.name,
    required this.email,
    this.username,
    this.phone,
    this.dob,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
        userId: (json['userId'] ?? json['id'] ?? '').toString(),
        name: (json['name'] ?? json['fullName'] ?? '').toString(),
        email: (json['email'] ?? '').toString(),
        username: json['username']?.toString(),
        phone: json['phone']?.toString(),
        dob: json['dob']?.toString(),
      );

  Map<String, dynamic> toJson() => {
        'userId': userId,
        'name': name,
        'email': email,
        if (username != null) 'username': username,
        if (phone != null) 'phone': phone,
        if (dob != null) 'dob': dob,
      };
}

class ClubDto {
  final String clubId;
  final String name;
  final String? myRole;

  const ClubDto({required this.clubId, required this.name, this.myRole});

  factory ClubDto.fromJson(Map<String, dynamic> json) => ClubDto(
        clubId: (json['clubId'] ?? json['id'] ?? '').toString(),
        name: (json['name'] ?? json['clubName'] ?? '').toString(),
        myRole: json['myRole']?.toString() ?? json['role']?.toString(),
      );
}

class TeamDto {
  final String teamId;
  final String? clubId;
  final String teamName;
  final String? clubName;
  final String? categoryId;
  final String? categoryName;
  final String? myRole;

  const TeamDto({
    required this.teamId,
    this.clubId,
    required this.teamName,
    this.clubName,
    this.categoryId,
    this.categoryName,
    this.myRole,
  });

  factory TeamDto.fromJson(Map<String, dynamic> json) => TeamDto(
        teamId: (json['teamId'] ?? json['id'] ?? '').toString(),
        clubId: json['clubId']?.toString(),
        teamName: (json['teamName'] ?? json['name'] ?? '').toString(),
        clubName: json['clubName']?.toString(),
        categoryId: json['categoryId']?.toString(),
        categoryName: json['categoryName']?.toString(),
        myRole: json['myRole']?.toString() ?? json['role']?.toString(),
      );
}

class TeamMemberDto {
  final String userId;
  final String name;
  final String email;
  final String role;

  const TeamMemberDto({
    required this.userId,
    required this.name,
    required this.email,
    required this.role,
  });

  factory TeamMemberDto.fromJson(Map<String, dynamic> json) => TeamMemberDto(
        userId: (json['userId'] ?? json['id'] ?? '').toString(),
        name: (json['name'] ?? json['fullName'] ?? '').toString(),
        email: (json['email'] ?? '').toString(),
        role: (json['role'] ?? '').toString(),
      );
}

class TeamCategoryDto {
  final String categoryId;
  final String name;

  const TeamCategoryDto({required this.categoryId, required this.name});

  factory TeamCategoryDto.fromJson(Map<String, dynamic> json) =>
      TeamCategoryDto(
        categoryId: (json['categoryId'] ?? json['id'] ?? '').toString(),
        name: (json['name'] ?? json['label'] ?? '').toString(),
      );
}

class SeasonDto {
  final String seasonId;
  final String label;

  const SeasonDto({required this.seasonId, required this.label});

  factory SeasonDto.fromJson(Map<String, dynamic> json) => SeasonDto(
        seasonId: (json['seasonId'] ?? json['id'] ?? '').toString(),
        label: (json['label'] ?? json['name'] ?? '').toString(),
      );
}

class EventDto {
  final String eventId;
  final String teamId;
  final String seasonId;
  final String title;
  final String eventType;
  final DateTime startAt;
  final DateTime? endAt;
  final String? location;
  final String? description;

  const EventDto({
    required this.eventId,
    required this.teamId,
    required this.seasonId,
    required this.title,
    required this.eventType,
    required this.startAt,
    this.endAt,
    this.location,
    this.description,
  });

  factory EventDto.fromJson(Map<String, dynamic> json) => EventDto(
        eventId: (json['eventId'] ?? json['id'] ?? '').toString(),
        teamId: (json['teamId'] ?? '').toString(),
        seasonId: (json['seasonId'] ?? '').toString(),
        title: (json['title'] ?? '').toString(),
        eventType: (json['eventType'] ?? json['type'] ?? '').toString(),
        startAt: DateTime.parse(
          (json['startAt'] ?? DateTime.now().toIso8601String()).toString(),
        ),
        endAt: json['endAt'] == null
            ? null
            : DateTime.tryParse(json['endAt'].toString()),
        location: json['location']?.toString(),
        description: json['description']?.toString(),
      );
}

class AnnouncementDto {
  final String announcementId;
  final String title;
  final String content;
  final String priority;
  final String creatorName;
  final DateTime createdAt;

  const AnnouncementDto({
    required this.announcementId,
    required this.title,
    required this.content,
    required this.priority,
    required this.creatorName,
    required this.createdAt,
  });

  factory AnnouncementDto.fromJson(Map<String, dynamic> json) =>
      AnnouncementDto(
        announcementId: (json['announcementId'] ?? json['id'] ?? '').toString(),
        title: (json['title'] ?? '').toString(),
        content: (json['content'] ?? '').toString(),
        priority: (json['priority'] ?? 'Normal').toString(),
        creatorName: (json['creatorName'] ?? '').toString(),
        createdAt: DateTime.tryParse('${json['createdAt']}') ?? DateTime.now(),
      );
}

class InvitationDto {
  final String invitationId;
  final String token;
  final String email;
  final String role;
  final String clubName;
  final String? teamName;
  final String inviterName;
  final String status;

  const InvitationDto({
    required this.invitationId,
    required this.token,
    required this.email,
    required this.role,
    required this.clubName,
    this.teamName,
    required this.inviterName,
    required this.status,
  });

  factory InvitationDto.fromJson(Map<String, dynamic> json) => InvitationDto(
        invitationId: (json['invitationId'] ?? json['id'] ?? '').toString(),
        token: (json['token'] ?? '').toString(),
        email: (json['email'] ?? '').toString(),
        role: (json['role'] ?? '').toString(),
        clubName: (json['clubName'] ?? '').toString(),
        teamName: json['teamName']?.toString(),
        inviterName: (json['inviterName'] ?? '').toString(),
        status: (json['status'] ?? '').toString(),
      );
}

class PlayerProfileDto {
  final String playerId;
  final String userId;
  final String name;
  final String email;
  final String? position;
  final int? jerseyNumber;
  final double? height;
  final double? weight;

  const PlayerProfileDto({
    required this.playerId,
    required this.userId,
    required this.name,
    required this.email,
    this.position,
    this.jerseyNumber,
    this.height,
    this.weight,
  });

  factory PlayerProfileDto.fromJson(Map<String, dynamic> json) =>
      PlayerProfileDto(
        playerId: (json['playerId'] ?? '').toString(),
        userId: (json['userId'] ?? '').toString(),
        name: (json['name'] ?? '').toString(),
        email: (json['email'] ?? '').toString(),
        position: json['position']?.toString(),
        jerseyNumber: json['jerseyNumber'] as int?,
        height: (json['height'] as num?)?.toDouble(),
        weight: (json['weight'] as num?)?.toDouble(),
      );
}

class FitnessRecordDto {
  final String recordId;
  final String playerUserId;
  final String playerName;
  final double? bmi;
  final double? bodyFatPct;
  final double? speedTestResult;
  final double? enduranceScore;
  final String? customTestName;
  final double? customTestResult;
  final DateTime recordedAt;

  const FitnessRecordDto({
    required this.recordId,
    required this.playerUserId,
    required this.playerName,
    this.bmi,
    this.bodyFatPct,
    this.speedTestResult,
    this.enduranceScore,
    this.customTestName,
    this.customTestResult,
    required this.recordedAt,
  });

  factory FitnessRecordDto.fromJson(Map<String, dynamic> json) =>
      FitnessRecordDto(
        recordId: (json['recordId'] ?? json['fitnessRecordId'] ?? '').toString(),
        playerUserId: (json['playerUserId'] ?? '').toString(),
        playerName: (json['playerName'] ?? '').toString(),
        bmi: (json['bmi'] as num?)?.toDouble(),
        bodyFatPct: (json['bodyFatPct'] as num?)?.toDouble(),
        speedTestResult: (json['speedTestResult'] as num?)?.toDouble(),
        enduranceScore: (json['enduranceScore'] as num?)?.toDouble(),
        customTestName: json['customTestName']?.toString(),
        customTestResult: (json['customTestResult'] as num?)?.toDouble(),
        recordedAt: DateTime.tryParse('${json['recordedAt']}') ?? DateTime.now(),
      );
}

class MedicalRecordDto {
  final String recordId;
  final String playerUserId;
  final String playerName;
  final String? injuryType;
  final String? diagnosis;
  final String? recoveryTips;
  final bool isClearedToPlay;
  final DateTime recordedAt;
  final List<MedicalDocumentRequestDto> documentRequests;

  const MedicalRecordDto({
    required this.recordId,
    required this.playerUserId,
    required this.playerName,
    this.injuryType,
    this.diagnosis,
    this.recoveryTips,
    this.isClearedToPlay = false,
    required this.recordedAt,
    this.documentRequests = const [],
  });

  factory MedicalRecordDto.fromJson(Map<String, dynamic> json) =>
      MedicalRecordDto(
        recordId: (json['recordId'] ?? json['medicalRecordId'] ?? '').toString(),
        playerUserId: (json['playerUserId'] ?? '').toString(),
        playerName: (json['playerName'] ?? '').toString(),
        injuryType: json['injuryType']?.toString(),
        diagnosis: json['diagnosis']?.toString(),
        recoveryTips: json['recoveryTips']?.toString(),
        isClearedToPlay:
            json['isCleared'] == true || json['isClearedToPlay'] == true,
        recordedAt: DateTime.tryParse(
              '${json['recordDate'] ?? json['recordedAt']}',
            ) ??
            DateTime.now(),
        documentRequests: (json['documentRequests'] as List<dynamic>? ?? [])
            .map((e) => MedicalDocumentRequestDto.fromJson(
                Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}

class MedicalDocumentRequestDto {
  final String requestId;
  final String documentName;
  final String status;
  final String? fileName;

  const MedicalDocumentRequestDto({
    required this.requestId,
    required this.documentName,
    required this.status,
    this.fileName,
  });

  factory MedicalDocumentRequestDto.fromJson(Map<String, dynamic> json) =>
      MedicalDocumentRequestDto(
        requestId: (json['requestId'] ?? json['id'] ?? '').toString(),
        documentName:
            (json['documentName'] ?? json['documentType'] ?? '').toString(),
        status: (json['status'] ?? '').toString(),
        fileName: json['fileName']?.toString() ??
            json['originalFileName']?.toString() ??
            json['downloadUrl']?.toString(),
      );
}

class PlanDto {
  final String planId;
  final String title;
  final String? description;
  final String? visibility;
  final String creatorName;

  const PlanDto({
    required this.planId,
    required this.title,
    this.description,
    this.visibility,
    required this.creatorName,
  });

  factory PlanDto.fromJson(Map<String, dynamic> json) => PlanDto(
        planId: (json['planId'] ?? json['id'] ?? '').toString(),
        title: (json['title'] ?? '').toString(),
        description: json['description']?.toString(),
        visibility: json['visibility']?.toString(),
        creatorName: (json['creatorName'] ?? '').toString(),
      );
}

class LineupDto {
  final String lineupId;
  final String name;
  final String creatorName;
  final List<LineupPlayerDto> players;

  const LineupDto({
    required this.lineupId,
    required this.name,
    required this.creatorName,
    this.players = const [],
  });

  factory LineupDto.fromJson(Map<String, dynamic> json) => LineupDto(
        lineupId: (json['lineupId'] ?? json['id'] ?? '').toString(),
        name: (json['name'] ?? json['title'] ?? '').toString(),
        creatorName: (json['creatorName'] ?? '').toString(),
        players: (json['players'] as List<dynamic>? ?? [])
            .map((e) =>
                LineupPlayerDto.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}

class LineupPlayerDto {
  final String userId;
  final String name;

  const LineupPlayerDto({required this.userId, required this.name});

  factory LineupPlayerDto.fromJson(Map<String, dynamic> json) =>
      LineupPlayerDto(
        userId: (json['userId'] ?? json['playerUserId'] ?? '').toString(),
        name: (json['name'] ?? json['playerName'] ?? '').toString(),
      );
}

class AttendanceDto {
  final String attendanceId;
  final String playerUserId;
  final String playerName;
  final String status;

  const AttendanceDto({
    required this.attendanceId,
    required this.playerUserId,
    required this.playerName,
    required this.status,
  });

  factory AttendanceDto.fromJson(Map<String, dynamic> json) => AttendanceDto(
        attendanceId: (json['attendanceId'] ?? json['id'] ?? '').toString(),
        playerUserId: (json['playerUserId'] ?? '').toString(),
        playerName: (json['playerName'] ?? '').toString(),
        status: (json['status'] ?? '').toString(),
      );
}

class ConversationDto {
  final String conversationId;
  final String? title;
  final String? lastMessage;
  final int unreadCount;
  final List<ConversationParticipantDto> participants;

  const ConversationDto({
    required this.conversationId,
    this.title,
    this.lastMessage,
    this.unreadCount = 0,
    this.participants = const [],
  });

  factory ConversationDto.fromJson(Map<String, dynamic> json) {
    final last = json['lastMessage'];
    return ConversationDto(
      conversationId: (json['conversationId'] ?? json['id'] ?? '').toString(),
      title: json['title']?.toString() ?? json['name']?.toString(),
      lastMessage: last is Map ? last['content']?.toString() : last?.toString(),
      unreadCount: json['unreadCount'] as int? ?? 0,
      participants: (json['participants'] as List<dynamic>? ?? [])
          .map((e) => ConversationParticipantDto.fromJson(
              Map<String, dynamic>.from(e as Map)))
          .toList(),
    );
  }
}

class ConversationParticipantDto {
  final String userId;
  final String name;

  const ConversationParticipantDto({required this.userId, required this.name});

  factory ConversationParticipantDto.fromJson(Map<String, dynamic> json) =>
      ConversationParticipantDto(
        userId: (json['userId'] ?? '').toString(),
        name: (json['name'] ?? '').toString(),
      );
}

class MessageDto {
  final String messageId;
  final String conversationId;
  final String senderUserId;
  final String senderName;
  final String content;
  final DateTime sentAt;

  const MessageDto({
    required this.messageId,
    required this.conversationId,
    required this.senderUserId,
    required this.senderName,
    required this.content,
    required this.sentAt,
  });

  factory MessageDto.fromJson(Map<String, dynamic> json) => MessageDto(
        messageId: (json['messageId'] ?? json['id'] ?? '').toString(),
        conversationId: (json['conversationId'] ?? '').toString(),
        senderUserId: (json['senderUserId'] ?? '').toString(),
        senderName: (json['senderName'] ?? '').toString(),
        content: (json['content'] ?? '').toString(),
        sentAt: DateTime.tryParse('${json['sentAt']}') ?? DateTime.now(),
      );
}
