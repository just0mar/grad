class AppConfig {
  const AppConfig._();

  static const bool useEmulator = false;
  static const String lanIp = '192.168.1.4';
  static const String emulatorHost = '10.0.2.2';
  static const int apiPort = 5122;

  static String get baseUrl =>
      'http://${useEmulator ? emulatorHost : lanIp}:$apiPort';

  static const String accessTokenKey = 'eq_access_token';
  static const String refreshTokenKey = 'eq_refresh_token';
  static const String userKey = 'eq_user';
  static const String activeTeamKey = 'eq_active_team';
  static const String activeClubKey = 'eq_active_club';
}
