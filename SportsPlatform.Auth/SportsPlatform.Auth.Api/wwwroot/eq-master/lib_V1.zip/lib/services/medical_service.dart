import '../models/api_models.dart';
import 'api_client.dart';

class MedicalService {
  final ApiClient _api = ApiClient.instance;

  Future<List<MedicalRecordDto>> getPlayerMedical(
      String clubId, String teamId, String playerId) async {
    final json =
        await _api.get('/clubs/$clubId/teams/$teamId/players/$playerId/medical');
    return (json as List)
        .map((e) =>
            MedicalRecordDto.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<MedicalRecordDto> createMedicalRecord(
      String clubId, String teamId, String playerId, Map<String, dynamic> body) async {
    final json = await _api.post(
      '/clubs/$clubId/teams/$teamId/players/$playerId/medical',
      body: body,
    );
    return MedicalRecordDto.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<MedicalRecordDto> updateMedicalRecord(
      String clubId, String teamId, String recordId, Map<String, dynamic> body) async {
    final json = await _api.put(
      '/clubs/$clubId/teams/$teamId/medical/$recordId',
      body: body,
    );
    return MedicalRecordDto.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<void> updateClearance(
      String clubId, String teamId, String recordId, bool cleared) async {
    await _api.patch(
      '/clubs/$clubId/teams/$teamId/medical/$recordId/clearance',
      body: {'isClearedToPlay': cleared},
    );
  }

  Future<MedicalDocumentRequestDto> requestDocument(
      String clubId, String teamId, String recordId, Map<String, dynamic> body) async {
    final json = await _api.post(
      '/clubs/$clubId/teams/$teamId/medical/$recordId/document-requests',
      body: body,
    );
    return MedicalDocumentRequestDto.fromJson(
      Map<String, dynamic>.from(json as Map),
    );
  }

  Future<dynamic> uploadDocument(
      String requestId, String filePath, String fileName) {
    return _api.uploadFile(
      '/players/me/medical/document-requests/$requestId/upload',
      fileField: 'file',
      filePath: filePath,
      fileName: fileName,
    );
  }
}
