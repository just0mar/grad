import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../models/api_models.dart';
import '../services/api_client.dart';
import '../services/fitness_service.dart';
import '../services/medical_service.dart';
import '../services/player_service.dart';
import '../services/stats_service.dart';
import '../team/team_bloc.dart';
import 'MemberModel.dart';

class MemberDetailView extends StatefulWidget {
  final Member member;
  final int memberIndex;

  const MemberDetailView({
    super.key,
    required this.member,
    required this.memberIndex,
  });

  @override
  State<MemberDetailView> createState() => _MemberDetailViewState();
}

class _MemberDetailViewState extends State<MemberDetailView> {
  final PlayerService _playerService = PlayerService();
  final FitnessService _fitnessService = FitnessService();
  final MedicalService _medicalService = MedicalService();
  final StatsService _statsService = StatsService();

  Future<_PlayerBundle>? _bundleFuture;
  String _bundleKey = '';

  void _ensureBundle(TeamState state, Member member) {
    final selectedTeams =
        state.availableTeams.where((t) => t.id == state.selectedTeamId).toList();
    final clubId = selectedTeams.isEmpty ? null : selectedTeams.first.clubId;
    final key = '${clubId ?? ''}:${state.selectedTeamId}:${member.userId}';
    if (key == _bundleKey) return;
    _bundleKey = key;
    if ((clubId ?? '').isEmpty ||
        state.selectedTeamId.isEmpty ||
        member.userId.isEmpty) {
      _bundleFuture = Future.value(const _PlayerBundle());
      return;
    }
    _bundleFuture = _loadBundle(clubId!, state.selectedTeamId, member.userId);
  }

  Future<_PlayerBundle> _loadBundle(
    String clubId,
    String teamId,
    String userId,
  ) async {
    final results = await Future.wait<dynamic>([
      _playerService.getPlayerProfile(clubId, teamId, userId).catchError((_) => null),
      _fitnessService.getPlayerFitness(clubId, teamId, userId).catchError((_) => <FitnessRecordDto>[]),
      _medicalService.getPlayerMedical(clubId, teamId, userId).catchError((_) => <MedicalRecordDto>[]),
      _statsService.getPlayerAggregate(clubId, teamId, userId).catchError((_) => <String, dynamic>{}),
    ]);
    return _PlayerBundle(
      profile: results[0] as PlayerProfileDto?,
      fitness: List<FitnessRecordDto>.from(results[1] as List),
      medical: List<MedicalRecordDto>.from(results[2] as List),
      stats: Map<String, dynamic>.from(results[3] as Map),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TeamBloc, TeamState>(
      builder: (context, state) {
        final currentMember = state.members.length > widget.memberIndex
            ? state.members[widget.memberIndex]
            : widget.member;
        _ensureBundle(state, currentMember);

        final isDark = Theme.of(context).brightness == Brightness.dark;
        final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
        final textColor = isDark ? Colors.white : Colors.black;
        final subTextColor = isDark ? Colors.white54 : Colors.black54;

        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: CustomAppBar(title: currentMember.name),
          body: SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                      : [Colors.green, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.2,
                ),
              ),
              child: RefreshIndicator(
                onRefresh: () async {
                  setState(() => _bundleKey = '');
                  _ensureBundle(state, currentMember);
                  await _bundleFuture;
                },
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.only(
                    top: kToolbarHeight + 48,
                    left: 16,
                    right: 16,
                    bottom: 16,
                  ),
                  child: FutureBuilder<_PlayerBundle>(
                    future: _bundleFuture,
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        final message = snapshot.error is ApiException
                            ? (snapshot.error as ApiException).message
                            : 'Could not load player details.';
                        return _buildError(message, textColor);
                      }
                      final bundle = snapshot.data;
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildProfileCard(
                            currentMember,
                            bundle?.profile,
                            cardBg,
                            textColor,
                            subTextColor,
                          ),
                          const SizedBox(height: 16),
                          if (snapshot.connectionState ==
                              ConnectionState.waiting)
                            const Center(
                              child: Padding(
                                padding: EdgeInsets.all(24),
                                child: CircularProgressIndicator(),
                              ),
                            )
                          else ...[
                            _buildMedicalStatusBanner(bundle?.medical ?? []),
                            const SizedBox(height: 16),
                            _buildStatsSection(
                              bundle?.stats ?? const {},
                              cardBg,
                              textColor,
                              subTextColor,
                            ),
                            const SizedBox(height: 16),
                            _buildFitnessSection(
                              bundle?.fitness ?? const [],
                              cardBg,
                              textColor,
                              subTextColor,
                            ),
                            const SizedBox(height: 16),
                            _buildMedicalSection(
                              bundle?.medical ?? const [],
                              cardBg,
                              textColor,
                              subTextColor,
                            ),
                          ],
                          const SizedBox(height: 32),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfileCard(
    Member member,
    PlayerProfileDto? profile,
    Color cardBg,
    Color textColor,
    Color subTextColor,
  ) {
    final details = <String>[
      if (profile?.position?.isNotEmpty == true) profile!.position!,
      if (profile?.jerseyNumber != null) '#${profile!.jerseyNumber}',
      if (profile?.height != null) '${profile!.height} cm',
      if (profile?.weight != null) '${profile!.weight} kg',
    ];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(backgroundImage: AssetImage(member.image), radius: 36),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  profile?.name.isNotEmpty == true ? profile!.name : member.name,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: textColor,
                  ),
                ),
                Text(member.role, style: TextStyle(color: subTextColor)),
                if (details.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(
                    details.join(' - '),
                    style: TextStyle(color: subTextColor, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMedicalStatusBanner(List<MedicalRecordDto> records) {
    final latest = records.isEmpty ? null : records.first;
    final cleared = latest?.isClearedToPlay ?? true;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cleared
            ? Colors.green.withValues(alpha: 0.1)
            : Colors.red.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        cleared
            ? 'Fit to play'
            : 'Not cleared: ${latest?.injuryType ?? 'medical review required'}',
        style: TextStyle(color: cleared ? Colors.green : Colors.red),
      ),
    );
  }

  Widget _buildStatsSection(
    Map<String, dynamic> stats,
    Color cardBg,
    Color textColor,
    Color subTextColor,
  ) {
    final entries = stats.entries
        .where((entry) => entry.value != null && entry.value is! Map && entry.value is! List)
        .take(8)
        .toList();
    return _section(
      title: 'PLAYER STATS',
      icon: Icons.bar_chart,
      color: AppColors.primary,
      textColor: textColor,
      child: entries.isEmpty
          ? _emptyCard('No player stats found.', cardBg, subTextColor)
          : Column(
              children: entries
                  .map(
                    (entry) => Card(
                      color: cardBg,
                      child: ListTile(
                        title: Text(entry.key, style: TextStyle(color: textColor)),
                        trailing: Text(
                          '${entry.value}',
                          style: TextStyle(color: textColor),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
    );
  }

  Widget _buildFitnessSection(
    List<FitnessRecordDto> records,
    Color cardBg,
    Color textColor,
    Color subTextColor,
  ) {
    return _section(
      title: 'PLAYER FITNESS RECORDS',
      icon: Icons.fitness_center,
      color: Colors.blue,
      textColor: textColor,
      child: records.isEmpty
          ? _emptyCard('No fitness records found.', cardBg, subTextColor)
          : Column(
              children: records.map((record) {
                final metrics = <String>[
                  if (record.bmi != null) 'BMI ${record.bmi}',
                  if (record.bodyFatPct != null) 'Body fat ${record.bodyFatPct}%',
                  if (record.speedTestResult != null) 'Speed ${record.speedTestResult}',
                  if (record.enduranceScore != null) 'Endurance ${record.enduranceScore}',
                  if (record.customTestName != null)
                    '${record.customTestName}: ${record.customTestResult ?? ''}',
                ];
                return Card(
                  color: cardBg,
                  child: ListTile(
                    title: Text(
                      record.recordedAt.toLocal().toString().split(' ').first,
                      style: TextStyle(color: textColor),
                    ),
                    subtitle: Text(
                      metrics.isEmpty ? 'Fitness record' : metrics.join(' - '),
                      style: TextStyle(color: subTextColor),
                    ),
                  ),
                );
              }).toList(),
            ),
    );
  }

  Widget _buildMedicalSection(
    List<MedicalRecordDto> records,
    Color cardBg,
    Color textColor,
    Color subTextColor,
  ) {
    return _section(
      title: 'PLAYER MEDICAL RECORDS',
      icon: Icons.healing,
      color: Colors.red,
      textColor: textColor,
      child: records.isEmpty
          ? _emptyCard('No medical records found.', cardBg, subTextColor)
          : Column(
              children: records
                  .map(
                    (record) => Card(
                      color: cardBg,
                      child: ListTile(
                        title: Text(
                          record.injuryType ?? 'Medical record',
                          style: TextStyle(color: textColor),
                        ),
                        subtitle: Text(
                          record.diagnosis ?? record.recoveryTips ?? 'No notes',
                          style: TextStyle(color: subTextColor),
                        ),
                        trailing: Icon(
                          record.isClearedToPlay
                              ? Icons.verified
                              : Icons.warning_amber,
                          color: record.isClearedToPlay
                              ? Colors.green
                              : Colors.orange,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
    );
  }

  Widget _section({
    required String title,
    required IconData icon,
    required Color color,
    required Color textColor,
    required Widget child,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(color: textColor, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 12),
        child,
      ],
    );
  }

  Widget _emptyCard(String text, Color cardBg, Color subTextColor) {
    return Card(
      color: cardBg,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Text(text, style: TextStyle(color: subTextColor)),
      ),
    );
  }

  Widget _buildError(String message, Color textColor) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Center(
        child: Text(message, style: TextStyle(color: textColor)),
      ),
    );
  }
}

class _PlayerBundle {
  final PlayerProfileDto? profile;
  final List<FitnessRecordDto> fitness;
  final List<MedicalRecordDto> medical;
  final Map<String, dynamic> stats;

  const _PlayerBundle({
    this.profile,
    this.fitness = const [],
    this.medical = const [],
    this.stats = const {},
  });
}
