import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import '../event/EventModel.dart';
import '../members/MemberModel.dart';
import '../team/team_bloc.dart';

class MatchDetailView extends StatelessWidget {
  final Event event;

  const MatchDetailView({
    super.key,
    required this.event,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    return BlocBuilder<TeamBloc, TeamState>(
      builder: (context, state) {
        final squad = state.members
            .where((m) => m.role == "Player" && m.isInSquad)
            .toList();

        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: const CustomAppBar(title: "Match Details"),
          body: Stack(
            children: [
              // Background
              Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isDark
                        ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                        : [Colors.green, Colors.white],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  image: const DecorationImage(
                    image: AssetImage("assets/background.png"),
                    fit: BoxFit.cover,
                    opacity: 0.2,
                  ),
                ),
              ),
              // Content
              SafeArea(
                top: false,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.only(
                    top: kToolbarHeight + 48,
                    left: 16,
                    right: 16,
                    bottom: 16,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildMatchCard(context),
                      const SizedBox(height: 20),
                      Text(
                        "GAME SQUAD",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          letterSpacing: 0.5,
                          color: textColor,
                        ),
                      ),
                      const SizedBox(height: 10),
                      squad.isEmpty
                          ? _buildEmptySquad(isDark, cardBg, textColor)
                          : Column(
                              children: squad
                                  .map((m) => _buildPlayerTile(
                                      m, isDark, cardBg, textColor))
                                  .toList(),
                            ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMatchCard(BuildContext context) {
    // Match card stays blue.shade900 — looks great in both modes
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade900,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.sports_soccer, color: Colors.white, size: 20),
              SizedBox(width: 8),
              Text(
                "MATCH",
                style: TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            "${event.date.day}/${event.date.month}/${event.date.year}  ${event.time.format(context)}",
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          if (event.description.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              event.description,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildPlayerTile(
      Member member, bool isDark, Color cardBg, Color textColor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundImage: AssetImage(member.image),
            radius: 22,
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                member.name,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: textColor,
                ),
              ),
              Text(
                member.role,
                style: TextStyle(
                    color: isDark ? Colors.white54 : Colors.black54,
                    fontSize: 13),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: isDark
                  ? Colors.green.shade900
                  : Colors.green.shade100,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              "In Squad",
              style: TextStyle(
                color: isDark
                    ? Colors.greenAccent
                    : Colors.green.shade800,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptySquad(bool isDark, Color cardBg, Color textColor) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: isDark ? Colors.white12 : Colors.grey.shade200),
      ),
      child: Column(
        children: [
          Icon(Icons.groups,
              size: 40,
              color: isDark ? Colors.white24 : Colors.grey.shade300),
          const SizedBox(height: 8),
          Text(
            "No squad selected yet.\nCoach can select players from Add GameSquad.",
            textAlign: TextAlign.center,
            style: TextStyle(
                color: isDark ? Colors.white38 : Colors.black38,
                fontSize: 14),
          ),
        ],
      ),
    );
  }
}