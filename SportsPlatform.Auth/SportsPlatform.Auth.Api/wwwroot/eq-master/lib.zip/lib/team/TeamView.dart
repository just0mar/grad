import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../members/MemberDetailView.dart';
import '../plans/PlansView.dart';
import '../teamstats/TeamStatsView.dart';
import 'team_bloc.dart';
import 'package:flutter/material.dart';

class TeamView extends StatelessWidget {
  final String sport;
  final String teamName;
  final String userRole;

  const TeamView({
    super.key,
    required this.sport,
    required this.teamName,
    required this.userRole,
  });

  @override
  Widget build(BuildContext context) {
    return _TeamViewContent(
      sport: sport,
      teamName: teamName,
      userRole: userRole,
    );
  }
}

class _TeamViewContent extends StatefulWidget {
  final String sport;
  final String teamName;
  final String userRole;

  const _TeamViewContent({
    required this.sport,
    required this.teamName,
    required this.userRole,
  });

  @override
  State<_TeamViewContent> createState() => _TeamViewContentState();
}

class _TeamViewContentState extends State<_TeamViewContent>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final tabBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final String activeRole = context.select((TeamBloc bloc) {
      if (bloc.state.userRoleInSelectedTeam.isNotEmpty) {
        return bloc.state.userRoleInSelectedTeam;
      }
      return widget.userRole;
    });

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: "Team", plans: []),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
            ),
            image: const DecorationImage(
              image: AssetImage("assets/background.png"),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.sm,
                    vertical: AppSpacing.xs,
                  ),
                  decoration: BoxDecoration(
                    color: tabBg,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: BlocBuilder<TeamBloc, TeamState>(
                    builder: (context, state) {
                      final teams = state.availableTeams;
                      if (teams.isEmpty) {
                        return Text(
                          'Team: ${widget.teamName}',
                          style: TextStyle(
                            color: textColor,
                            fontFamily: 'SFPro',
                          ),
                        );
                      }

                      return Row(
                        children: [
                          Expanded(
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: state.selectedTeamId,
                                dropdownColor: tabBg,
                                isExpanded: true,
                                style: TextStyle(
                                  color: textColor,
                                  fontFamily: 'SFPro',
                                ),
                                items: teams
                                    .map(
                                      (team) => DropdownMenuItem<String>(
                                        value: team.id,
                                        child: Text(
                                          '${team.club} ${team.category}',
                                        ),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    context.read<TeamBloc>().add(
                                      SwitchTeamContext(value),
                                    );
                                  }
                                },
                              ),
                            ),
                          ),
                          const SizedBox(width: AppSpacing.sm),
                          Text(
                            state.userRoleInSelectedTeam,
                            style: TextStyle(
                              color: AppColors.primary,
                              fontFamily: 'SFPro',
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: tabBg,
                    borderRadius: BorderRadius.circular(32),
                  ),
                  child: TabBar(
                    controller: _tabController,
                    labelColor: AppColors.primary,
                    unselectedLabelColor: isDark
                        ? Colors.white60
                        : Colors.black,
                    labelStyle: const TextStyle(
                      fontFamily: 'SFPro',
                      fontWeight: FontWeight.bold,
                    ),
                    unselectedLabelStyle: const TextStyle(fontFamily: 'SFPro'),
                    indicator: const BoxDecoration(),
                    tabs: const [
                      Tab(icon: Icon(Icons.group), text: "Members"),
                      Tab(icon: Icon(Icons.bar_chart), text: "Stats"),
                      Tab(icon: Icon(Icons.assignment), text: "Plans"),
                    ],
                  ),
                ),
                BlocBuilder<TeamBloc, TeamState>(
                  builder: (context, state) {
                    final int injuredCount = state.members
                        .where((m) => m.isInjured)
                        .length;
                    final int inSquadCount = state.members
                        .where((m) => m.isInSquad)
                        .length;
                    final bool canEditStates =
                        state.userRoleInSelectedTeam.trim() == 'Analyst';

                    return Container(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      padding: const EdgeInsets.all(AppSpacing.sm),
                      decoration: BoxDecoration(
                        color: tabBg,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              'States: $inSquadCount in squad, $injuredCount injured',
                              style: TextStyle(
                                color: textColor,
                                fontFamily: 'SFPro',
                              ),
                            ),
                          ),
                          Text(
                            canEditStates ? 'Editable' : 'Read only',
                            style: TextStyle(
                              color: canEditStates
                                  ? AppColors.primary
                                  : Colors.orange,
                              fontFamily: 'SFPro',
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildMembersGrid(context, isDark, textColor),
                      TeamStats(
                        sport: widget.sport,
                        teamName: widget.teamName,
                        userRole: activeRole,
                      ),
                      const PlansView(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMembersGrid(BuildContext context, bool isDark, Color textColor) {
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    const int memberColumns = 2;

    return BlocBuilder<TeamBloc, TeamState>(
      builder: (context, state) {
        if (state.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }
        if (state.members.isEmpty) {
          return Center(
            child: Text(
              "No members yet. Add members from the menu.",
              style: TextStyle(
                color: textColor,
                fontFamily: 'SFPro',
                fontSize: 16,
              ),
            ),
          );
        }

        return GridView.builder(
          padding: const EdgeInsets.all(AppSpacing.sm),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: memberColumns,
            crossAxisSpacing: AppSpacing.sm,
            mainAxisSpacing: AppSpacing.sm,
          ),
          itemCount: state.members.length,
          itemBuilder: (context, index) {
            final member = state.members[index];
            return GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      MemberDetailView(member: member, memberIndex: index),
                ),
              ),
              child: Card(
                color: cardBg,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 4,
                child: Stack(
                  children: [
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage: AssetImage(member.image),
                            radius: 30,
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Text(
                            member.name,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: textColor,
                              fontFamily: 'SFPro',
                            ),
                          ),
                          Text(
                            member.role,
                            style: TextStyle(
                              color: isDark ? Colors.white54 : Colors.grey,
                              fontFamily: 'SFPro',
                            ),
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Text(
                            member.isInSquad ? 'In Squad' : 'Out Squad',
                            style: TextStyle(
                              color: member.isInSquad
                                  ? Colors.green
                                  : (isDark ? Colors.white54 : Colors.black45),
                              fontFamily: 'SFPro',
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (member.isInjured)
                      Positioned(
                        top: 6,
                        right: 6,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text(
                            "Injured",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'SFPro',
                            ),
                          ),
                        ),
                      ),
                    if (state.userRoleInSelectedTeam.trim() == 'Analyst')
                      Positioned(
                        bottom: 6,
                        right: 6,
                        child: Icon(
                          Icons.edit,
                          size: 16,
                          color: isDark ? Colors.white24 : Colors.black26,
                        ),
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
