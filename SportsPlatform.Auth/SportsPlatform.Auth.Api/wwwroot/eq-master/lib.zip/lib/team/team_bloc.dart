import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../addteam/AddTeamModel.dart';
import '../members/MemberModel.dart';


abstract class TeamEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadTeamMembers extends TeamEvent {}

class ConfigureTeamAccess extends TeamEvent {
  final String userId;
  final String fallbackRole;

  ConfigureTeamAccess({required this.userId, required this.fallbackRole});

  @override
  List<Object?> get props => [userId, fallbackRole];
}

class RegisterTeam extends TeamEvent {
  final Team team;
  final String fallbackRole;

  RegisterTeam({required this.team, required this.fallbackRole});

  @override
  List<Object?> get props => [team, fallbackRole];
}

class SwitchTeamContext extends TeamEvent {
  final String teamId;

  SwitchTeamContext(this.teamId);

  @override
  List<Object?> get props => [teamId];
}

class ClearPermissionError extends TeamEvent {}

class UpdateMemberStatus extends TeamEvent {
  final int index;
  final bool isInSquad;
  UpdateMemberStatus(this.index, this.isInSquad);

  @override
  List<Object?> get props => [index, isInSquad];
}

class UpdateMemberData extends TeamEvent {
  final int index;
  final Member member;
  final bool requiresStateEditPermission;

  UpdateMemberData(
    this.index,
    this.member, {
    this.requiresStateEditPermission = false,
  });

  @override
  List<Object?> get props => [index, member, requiresStateEditPermission];
}

class AddTeamMember extends TeamEvent {
  final Member member;
  AddTeamMember(this.member);

  @override
  List<Object?> get props => [member];
}

// States
class TeamState extends Equatable {
  final List<Member> members;
  final Map<String, List<Member>> membersByTeamId;
  final List<Team> availableTeams;
  final String selectedTeamId;
  final String selectedTeamName;
  final String userRoleInSelectedTeam;
  final String currentUserId;
  final bool isLoading;
  final String? permissionError;

  const TeamState({
    this.members = const [],
    this.membersByTeamId = const {},
    this.availableTeams = const [],
    this.selectedTeamId = '',
    this.selectedTeamName = 'My Team',
    this.userRoleInSelectedTeam = '',
    this.currentUserId = '',
    this.isLoading = false,
    this.permissionError,
  });

  TeamState copyWith({
    List<Member>? members,
    Map<String, List<Member>>? membersByTeamId,
    List<Team>? availableTeams,
    String? selectedTeamId,
    String? selectedTeamName,
    String? userRoleInSelectedTeam,
    String? currentUserId,
    bool? isLoading,
    String? permissionError,
    bool clearPermissionError = false,
  }) {
    return TeamState(
      members: members ?? this.members,
      membersByTeamId: membersByTeamId ?? this.membersByTeamId,
      availableTeams: availableTeams ?? this.availableTeams,
      selectedTeamId: selectedTeamId ?? this.selectedTeamId,
      selectedTeamName: selectedTeamName ?? this.selectedTeamName,
      userRoleInSelectedTeam:
          userRoleInSelectedTeam ?? this.userRoleInSelectedTeam,
      currentUserId: currentUserId ?? this.currentUserId,
      isLoading: isLoading ?? this.isLoading,
      permissionError: clearPermissionError
          ? null
          : (permissionError ?? this.permissionError),
    );
  }

  @override
  List<Object?> get props => [
    members,
    membersByTeamId,
    availableTeams,
    selectedTeamId,
    selectedTeamName,
    userRoleInSelectedTeam,
    currentUserId,
    isLoading,
    permissionError,
  ];
}

// Bloc
class TeamBloc extends Bloc<TeamEvent, TeamState> {
  TeamBloc() : super(const TeamState()) {
    on<LoadTeamMembers>(_onLoadTeamMembers);
    on<ConfigureTeamAccess>(_onConfigureTeamAccess);
    on<RegisterTeam>(_onRegisterTeam);
    on<SwitchTeamContext>(_onSwitchTeamContext);
    on<ClearPermissionError>(_onClearPermissionError);
    on<UpdateMemberStatus>(_onUpdateMemberStatus);
    on<UpdateMemberData>(_onUpdateMemberData);
    on<AddTeamMember>(_onAddTeamMember);
  }

  void _onLoadTeamMembers(LoadTeamMembers event, Emitter<TeamState> emit) {
    emit(state.copyWith(isLoading: true));
    final List<Member> initialMembers = _buildInitialMembers();

    emit(
      state.copyWith(
        members: initialMembers,
        membersByTeamId: {
          if (state.selectedTeamId.isNotEmpty)
            state.selectedTeamId: initialMembers
          else
            'default-team': initialMembers,
        },
        selectedTeamId: state.selectedTeamId.isNotEmpty
            ? state.selectedTeamId
            : 'default-team',
        selectedTeamName: state.selectedTeamName == 'My Team'
            ? 'Smouha U16'
            : state.selectedTeamName,
        isLoading: false,
      ),
    );
  }

  void _onConfigureTeamAccess(
    ConfigureTeamAccess event,
    Emitter<TeamState> emit,
  ) {
    final seededTeams = _seedTeamsForUser(event.userId, event.fallbackRole);
    if (seededTeams.isEmpty) return;

    final selectedTeamId = state.selectedTeamId.isNotEmpty
        ? state.selectedTeamId
        : seededTeams.first.id;
    final selectedTeam = seededTeams.firstWhere(
      (team) => team.id == selectedTeamId,
      orElse: () => seededTeams.first,
    );

    final membersByTeamId = <String, List<Member>>{...state.membersByTeamId};

    for (final team in seededTeams) {
      membersByTeamId.putIfAbsent(team.id, () => _membersForTeam(team.id));
    }

    emit(
      state.copyWith(
        currentUserId: event.userId,
        availableTeams: seededTeams,
        selectedTeamId: selectedTeam.id,
        selectedTeamName: '${selectedTeam.club} ${selectedTeam.category}',
        userRoleInSelectedTeam:
            selectedTeam.memberRoles[event.userId] ?? event.fallbackRole,
        membersByTeamId: membersByTeamId,
        members: membersByTeamId[selectedTeam.id] ?? const [],
      ),
    );
  }

  void _onRegisterTeam(RegisterTeam event, Emitter<TeamState> emit) {
    final String userId = state.currentUserId;
    final String generatedId = event.team.id.isNotEmpty
        ? event.team.id
        : 'team-${DateTime.now().millisecondsSinceEpoch}';
    final team = event.team.copyWith(
      id: generatedId,
      memberRoles: {
        ...event.team.memberRoles,
        if (userId.isNotEmpty) userId: event.fallbackRole,
      },
    );

    final updatedTeams = List<Team>.from(state.availableTeams)..add(team);
    final updatedMembersByTeam = <String, List<Member>>{
      ...state.membersByTeamId,
      team.id: _membersForTeam(team.id),
    };

    emit(
      state.copyWith(
        availableTeams: updatedTeams,
        membersByTeamId: updatedMembersByTeam,
      ),
    );
  }

  void _onSwitchTeamContext(SwitchTeamContext event, Emitter<TeamState> emit) {
    final targetTeam = state.availableTeams.firstWhere(
      (team) => team.id == event.teamId,
      orElse: () => state.availableTeams.isNotEmpty
          ? state.availableTeams.first
          : Team(
              country: '',
              club: 'My Team',
              sport: 'Basketball',
              category: '',
            ),
    );
    if (targetTeam.id.isEmpty && state.availableTeams.isEmpty) {
      return;
    }

    final userRole =
        targetTeam.memberRoles[state.currentUserId] ??
        state.userRoleInSelectedTeam;

    emit(
      state.copyWith(
        selectedTeamId: targetTeam.id,
        selectedTeamName: '${targetTeam.club} ${targetTeam.category}'.trim(),
        userRoleInSelectedTeam: userRole,
        members: state.membersByTeamId[targetTeam.id] ?? const [],
        clearPermissionError: true,
      ),
    );
  }

  void _onClearPermissionError(
    ClearPermissionError event,
    Emitter<TeamState> emit,
  ) {
    emit(state.copyWith(clearPermissionError: true));
  }

  void _onUpdateMemberStatus(
    UpdateMemberStatus event,
    Emitter<TeamState> emit,
  ) {
    if (state.userRoleInSelectedTeam.trim() != 'Analyst') {
      emit(state.copyWith(permissionError: 'Only Analyst can edit states.', clearPermissionError: false));
      return;
    }

    final updatedMembers = List<Member>.from(state.members);
    final member = updatedMembers[event.index];
    updatedMembers[event.index] = Member(
      name: member.name,
      role: member.role,
      image: member.image,
      age: member.age,
      isInSquad: event.isInSquad,
      medicalPdfUrl: member.medicalPdfUrl,
      medicalPdfName: member.medicalPdfName,
      fitnessPdfUrl: member.fitnessPdfUrl,
      fitnessPdfName: member.fitnessPdfName,
      analysisPdfUrl: member.analysisPdfUrl,
      analysisPdfName: member.analysisPdfName,
      videoUrl: member.videoUrl,
      videoFileName: member.videoFileName,
      medicalNotes: member.medicalNotes,
      injuryType: member.injuryType,
      absencePeriod: member.absencePeriod,
    );

    final updatedMap = <String, List<Member>>{
      ...state.membersByTeamId,
      state.selectedTeamId: updatedMembers,
    };

    emit(
      state.copyWith(
        members: updatedMembers,
        membersByTeamId: updatedMap,
        clearPermissionError: true,
      ),
    );
  }

  void _onUpdateMemberData(UpdateMemberData event, Emitter<TeamState> emit) {
    if (event.requiresStateEditPermission &&
        state.userRoleInSelectedTeam.trim() != 'Analyst') {
      emit(state.copyWith(permissionError: 'Only Analyst can edit states.', clearPermissionError: false));
      return;
    }

    final updatedMembers = List<Member>.from(state.members);
    updatedMembers[event.index] = event.member;

    final updatedMap = <String, List<Member>>{
      ...state.membersByTeamId,
      state.selectedTeamId: updatedMembers,
    };

    emit(
      state.copyWith(
        members: updatedMembers,
        membersByTeamId: updatedMap,
        clearPermissionError: true,
      ),
    );
  }

  void _onAddTeamMember(AddTeamMember event, Emitter<TeamState> emit) {
    final updatedMembers = List<Member>.from(state.members)..add(event.member);
    final updatedMap = <String, List<Member>>{
      ...state.membersByTeamId,
      state.selectedTeamId: updatedMembers,
    };

    emit(state.copyWith(members: updatedMembers, membersByTeamId: updatedMap));
  }

  List<Member> _buildInitialMembers() {
    return [
      Member(name: 'Ahmed Mahmoud', role: 'Coach', age: 35),
      Member(name: 'Ali Omar', role: 'Team Manager', age: 40),
      Member(name: 'Sarah Ashraf', role: 'Doctor', age: 30),
      Member(name: 'Mahmoud Hamed', role: 'Analyst', age: 28),
      Member(name: 'Loay Barakat', role: 'Fitness Coach', age: 32),
      Member(
        name: 'Omar Salah',
        role: 'Player',
        age: 19,
        fitnessPdfUrl: 'https://firebase-placeholder/omar_fitness.pdf',
        fitnessPdfName: 'Omar Fitness Plan.pdf',
        analysisPdfUrl: 'https://firebase-placeholder/omar_analysis.pdf',
        analysisPdfName: 'Omar Performance Analysis.pdf',
      ),
      Member(
        name: 'Karim Mohamed',
        role: 'Player',
        age: 21,
        medicalPdfUrl: 'https://firebase-placeholder/karim_medical.pdf',
        medicalPdfName: 'Karim Medical Report.pdf',
        fitnessPdfUrl: 'https://firebase-placeholder/karim_fitness.pdf',
        fitnessPdfName: 'Karim Fitness Plan.pdf',
        analysisPdfUrl: 'https://firebase-placeholder/karim_analysis.pdf',
        analysisPdfName: 'Karim Performance Analysis.pdf',
        medicalNotes:
            'Player suffered a left knee ligament strain during training on 15/01/2026. '
            'MRI confirmed Grade 2 sprain. Recommended rest and physiotherapy for 2 weeks. '
            'Follow-up scheduled for 29/01/2026.',
        injuryType: 'Left Knee Ligament Strain',
        absencePeriod: '2 Weeks',
      ),
    ];
  }

  List<Team> _seedTeamsForUser(String userId, String fallbackRole) {
    return [
      Team(
        id: 'smouha-u16',
        country: 'Egypt',
        club: 'Smouha',
        sport: 'Basketball',
        category: 'U16',
        memberRoles: {userId: 'Player'},
      ),
      Team(
        id: 'ittihad-u18',
        country: 'Egypt',
        club: 'Al Ittihad',
        sport: 'Basketball',
        category: 'U18',
        memberRoles: {userId: 'Team Manager'},
      ),
      Team(
        id: 'ahly-pro',
        country: 'Egypt',
        club: 'Al Ahly',
        sport: 'Basketball',
        category: 'Pro',
        memberRoles: {userId: 'Analyst'},
      ),
      Team(
        id: 'fallback-team',
        country: 'Egypt',
        club: 'Equipex',
        sport: 'Basketball',
        category: 'Main',
        memberRoles: {userId: fallbackRole},
      ),
    ];
  }

  List<Member> _membersForTeam(String teamId) {
    final base = _buildInitialMembers();
    if (teamId == 'ahly-pro') {
      return base
          .map(
            (member) => Member(
              name: member.name,
              role: member.role,
              image: member.image,
              age: member.age,
              isInSquad: member.role == 'Player',
              medicalPdfUrl: member.medicalPdfUrl,
              medicalPdfName: member.medicalPdfName,
              fitnessPdfUrl: member.fitnessPdfUrl,
              fitnessPdfName: member.fitnessPdfName,
              analysisPdfUrl: member.analysisPdfUrl,
              analysisPdfName: member.analysisPdfName,
              videoUrl: member.videoUrl,
              videoFileName: member.videoFileName,
              medicalNotes: member.medicalNotes,
              injuryType: member.injuryType,
              absencePeriod: member.absencePeriod,
            ),
          )
          .toList();
    }
    return base;
  }
}
