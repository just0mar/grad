import 'package:flutter/material.dart'; // ✅ needed for TimeOfDay

class Event {
  final String type;
  final DateTime date;
  final TimeOfDay time;
  final String description;

  Event({
    required this.type,
    required this.date,
    required this.time,
    required this.description,
  });
}