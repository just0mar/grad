import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:table_calendar/table_calendar.dart';
import '../appbar/CustomAppBar.dart';
import '../match/MatchDetailView.dart';
import '../core/responsive_system.dart';
import 'EventModel.dart';
import 'event_bloc.dart';

class EventView extends StatelessWidget {
  const EventView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => EventBloc()..add(LoadEvents()),
      child: const _EventViewContent(),
    );
  }
}

class _EventViewContent extends StatelessWidget {
  const _EventViewContent();

  Color _getEventColor(String type) {
    switch (type.trim()) {
      case "Match": return Colors.blue.shade900;
      case "Training": return Colors.green.shade900;
      case "Meeting": return Colors.green.shade400;
      case "Test": return Colors.black;
      default: return Colors.grey;
    }
  }

  IconData _getEventIcon(String type) {
    switch (type.trim()) {
      case "Match": return Icons.sports_soccer;
      case "Training": return Icons.fitness_center;
      case "Meeting": return Icons.event_note;
      case "Test": return Icons.assignment;
      default: return Icons.event;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final padding = ResponsiveSystem.pagePadding(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: "EVENTS"),
      body: BlocBuilder<EventBloc, EventState>(
        builder: (context, state) {
          return SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                      : [Colors.green, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.15,
                ),
              ),
              child: SafeArea(
                child: SingleChildScrollView(
                  padding: padding,
                  child: Column(
                    children: [
                      _buildCalendarContainer(context, state, isDark),
                      const SizedBox(height: 16),
                      _buildLegend(context, isDark),
                      const SizedBox(height: 16),
                      _buildEventList(context, state, isDark),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCalendarContainer(BuildContext context, EventState state, bool isDark) {
    final calBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    return Container(
      decoration: BoxDecoration(
        color: calBg,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.15),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: TableCalendar<Event>(
        firstDay: DateTime.utc(2020, 1, 1),
        lastDay: DateTime.utc(2030, 12, 31),
        focusedDay: state.focusedDay,
        selectedDayPredicate: (day) => isSameDay(state.selectedDay, day),
        eventLoader: (day) => state.eventsByDay[DateTime(day.year, day.month, day.day)] ?? [],
        rowHeight: 60,
        calendarStyle: CalendarStyle(
          cellMargin: const EdgeInsets.all(4),
          defaultDecoration: BoxDecoration(shape: BoxShape.rectangle, borderRadius: BorderRadius.circular(10)),
          weekendDecoration: BoxDecoration(shape: BoxShape.rectangle, borderRadius: BorderRadius.circular(10)),
          todayDecoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.5), borderRadius: BorderRadius.circular(10)),
          selectedDecoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(10)),
          defaultTextStyle: TextStyle(color: textColor, fontFamily: 'SFPro'),
          weekendTextStyle: TextStyle(color: textColor, fontFamily: 'SFPro'),
          todayTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          selectedTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        headerStyle: HeaderStyle(
          formatButtonVisible: false,
          titleCentered: true,
          titleTextStyle: TextStyle(fontFamily: 'Facon', fontSize: 20, color: textColor),
          leftChevronIcon: Icon(Icons.chevron_left, color: textColor),
          rightChevronIcon: Icon(Icons.chevron_right, color: textColor),
        ),
        onDaySelected: (selected, focused) {
          context.read<EventBloc>().add(SelectDay(selected, focused));
        },
        calendarBuilders: CalendarBuilders(
          markerBuilder: (context, date, events) {
            if (events.isEmpty) return const SizedBox();
            return Positioned(
              bottom: 1,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: events.take(3).map((e) {
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 1),
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: _getEventColor(e.type),
                      shape: BoxShape.circle,
                    ),
                  );
                }).toList(),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildLegend(BuildContext context, bool isDark) {
    final textColor = isDark ? Colors.white : Colors.black;
    return Wrap(
      spacing: 16,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: [
        _legendItem("Match", Colors.blue.shade900, textColor),
        _legendItem("Training", Colors.green.shade900, textColor),
        _legendItem("Meeting", Colors.green.shade400, textColor),
        _legendItem("Test", isDark ? Colors.white : Colors.black, textColor),
      ],
    );
  }

  Widget _legendItem(String label, Color color, Color textColor) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(label, style: TextStyle(fontSize: 12, color: textColor)),
      ],
    );
  }

  Widget _buildEventList(BuildContext context, EventState state, bool isDark) {
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final eventsForDay = state.eventsByDay[DateTime(state.selectedDay.year, state.selectedDay.month, state.selectedDay.day)] ?? [];

    if (eventsForDay.isEmpty) {
      return Padding(
        padding: const EdgeInsets.only(top: 40),
        child: Text("No events for this day", style: TextStyle(color: textColor.withValues(alpha: 0.5))),
      );
    }

    return Column(
      children: eventsForDay.map((event) {
        final bool isMatch = event.type.trim() == "Match";
        return Card(
          color: cardBg,
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            leading: Icon(_getEventIcon(event.type), color: _getEventColor(event.type)),
            title: Text(event.type, style: TextStyle(fontWeight: FontWeight.bold, color: textColor)),
            subtitle: Text(
              "${event.time.format(context)} - ${event.description}",
              style: TextStyle(color: textColor.withValues(alpha: 0.7)),
            ),
            trailing: isMatch ? Icon(Icons.chevron_right, color: textColor.withValues(alpha: 0.5)) : null,
            onTap: isMatch ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => MatchDetailView(event: event))) : null,
          ),
        );
      }).toList(),
    );
  }
}
