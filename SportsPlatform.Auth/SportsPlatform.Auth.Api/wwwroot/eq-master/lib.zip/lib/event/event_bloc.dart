import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'EventModel.dart';

// Events
abstract class EventEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadEvents extends EventEvent {}

class AddEvent extends EventEvent {
  final Event event;
  AddEvent(this.event);
  @override
  List<Object?> get props => [event];
}

class SelectDay extends EventEvent {
  final DateTime selectedDay;
  final DateTime focusedDay;
  SelectDay(this.selectedDay, this.focusedDay);
  @override
  List<Object?> get props => [selectedDay, focusedDay];
}

// State
class EventState extends Equatable {
  final List<Event> events;
  final DateTime selectedDay;
  final DateTime focusedDay;
  final Map<DateTime, List<Event>> eventsByDay;

  EventState({
    this.events = const [],
    DateTime? selectedDay,
    DateTime? focusedDay,
    this.eventsByDay = const {},
  })  : selectedDay = selectedDay ?? DateTime.now(),
        focusedDay = focusedDay ?? DateTime.now();

  EventState copyWith({
    List<Event>? events,
    DateTime? selectedDay,
    DateTime? focusedDay,
    Map<DateTime, List<Event>>? eventsByDay,
  }) {
    return EventState(
      events: events ?? this.events,
      selectedDay: selectedDay ?? this.selectedDay,
      focusedDay: focusedDay ?? this.focusedDay,
      eventsByDay: eventsByDay ?? this.eventsByDay,
    );
  }

  List<Event> get upcomingEvents {
    final DateTime now = DateTime.now();
    const List<String> types = ["Match", "Training", "Meeting", "Test"];
    final List<Event> result = [];

    for (final String type in types) {
      final List<Event> upcoming = events
          .where((e) =>
              e.type.trim() == type &&
              e.date.isAfter(now.subtract(const Duration(days: 1))))
          .toList()
        ..sort((a, b) => a.date.compareTo(b.date));

      if (upcoming.isNotEmpty) {
        result.add(upcoming.first);
      }
    }
    return result;
  }

  @override
  List<Object?> get props => [events, selectedDay, focusedDay, eventsByDay];
}

// Bloc
class EventBloc extends Bloc<EventEvent, EventState> {
  EventBloc() : super(EventState()) {
    on<LoadEvents>(_onLoadEvents);
    on<AddEvent>(_onAddEvent);
    on<SelectDay>(_onSelectDay);
  }

  void _onLoadEvents(LoadEvents event, Emitter<EventState> emit) {
    // Initial load logic if any
  }

  void _onAddEvent(AddEvent event, Emitter<EventState> emit) {
    final newEvents = List<Event>.from(state.events)..add(event.event);
    final newEventsByDay = _rebuildEventsByDay(newEvents);
    emit(state.copyWith(events: newEvents, eventsByDay: newEventsByDay));
  }

  void _onSelectDay(SelectDay event, Emitter<EventState> emit) {
    emit(state.copyWith(selectedDay: event.selectedDay, focusedDay: event.focusedDay));
  }

  Map<DateTime, List<Event>> _rebuildEventsByDay(List<Event> events) {
    final map = <DateTime, List<Event>>{};
    for (final event in events) {
      final day = DateTime(event.date.year, event.date.month, event.date.day);
      map.putIfAbsent(day, () => []).add(event);
    }
    return map;
  }
}
