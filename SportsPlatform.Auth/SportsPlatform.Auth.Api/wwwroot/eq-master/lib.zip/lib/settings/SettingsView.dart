import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../auth/LoginView.dart';
import '../appbar/CustomAppBar.dart';
import '../core/app_bloc.dart';
import '../core/design_tokens.dart';
import '../core/responsive_widgets.dart';
import '../team/team_bloc.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  void _showLogoutDialog(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final dialogBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: dialogBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () => Navigator.pop(ctx),
                  child: Icon(Icons.close, color: textColor),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                "Are you sure you want\nto log out ?",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'SFPro',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
              const SizedBox(height: 24),
              ResponsivePrimaryButton(
                context: ctx,
                label: "Cancel",
                onPressed: () => Navigator.pop(ctx),
              ),
              const SizedBox(height: 16),
              ResponsivePrimaryButton(
                context: ctx,
                label: "Yes Log out",
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginView()),
                    (route) => false,
                  );
                },
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.red,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: "SETTINGS"),
      body: BlocBuilder<AppBloc, AppState>(
        builder: (context, state) {
          return SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF0D2B1E), const Color(0xFF050F0A)]
                      : [Colors.green, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.2,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.only(top: kToolbarHeight + 24),
                child: SafeArea(
                  top: false,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      // Language
                      Container(
                        decoration: BoxDecoration(
                          color: isDark
                              ? const Color(0xFF1B3A2D)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          title: Text(
                            "Language",
                            style: TextStyle(
                              fontFamily: 'SFPro',
                              color: isDark ? Colors.white : Colors.black,
                            ),
                          ),
                          trailing: DropdownButton<String>(
                            value: "English",
                            dropdownColor: isDark
                                ? const Color(0xFF1B3A2D)
                                : Colors.white,
                            style: TextStyle(
                              fontFamily: 'SFPro',
                              color: isDark ? Colors.white : Colors.black,
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: "English",
                                child: Text("English"),
                              ),
                              DropdownMenuItem(
                                value: "Arabic",
                                child: Text("Arabic"),
                              ),
                            ],
                            onChanged: (val) {},
                          ),
                        ),
                      ),
                      const SizedBox(height: AppSpacing.xs),

                      // Theme
                      Container(
                        decoration: BoxDecoration(
                          color: isDark
                              ? const Color(0xFF1B3A2D)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          title: Text(
                            "Theme",
                            style: TextStyle(
                              fontFamily: 'SFPro',
                              color: isDark ? Colors.white : Colors.black,
                            ),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(
                                  Icons.wb_sunny,
                                  color: state.themeMode == ThemeMode.light
                                      ? Colors.orange
                                      : Colors.grey,
                                ),
                                onPressed: () {
                                  context.read<AppBloc>().add(
                                    ThemeChanged(ThemeMode.light),
                                  );
                                },
                              ),
                              const SizedBox(width: 12),
                              IconButton(
                                icon: Icon(
                                  Icons.nightlight_round,
                                  color: state.themeMode == ThemeMode.dark
                                      ? Colors.blueGrey
                                      : Colors.grey,
                                ),
                                onPressed: () {
                                  context.read<AppBloc>().add(
                                    ThemeChanged(ThemeMode.dark),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: AppSpacing.sm),

                      Text(
                        "Switch Teams",
                        style: TextStyle(
                          fontFamily: 'SFPro',
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: isDark ? Colors.white : Colors.black,
                        ),
                      ),
                      const SizedBox(height: AppSpacing.xs),
                      BlocBuilder<TeamBloc, TeamState>(
                        builder: (context, teamState) {
                          if (teamState.availableTeams.isEmpty) {
                            return Container(
                              padding: const EdgeInsets.all(AppSpacing.sm),
                              margin: const EdgeInsets.only(
                                bottom: AppSpacing.xs,
                              ),
                              decoration: BoxDecoration(
                                color: isDark
                                    ? const Color(0xFF1B3A2D)
                                    : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.grey),
                              ),
                              child: Text(
                                'No teams available',
                                style: TextStyle(
                                  fontFamily: 'SFPro',
                                  color: isDark
                                      ? Colors.white70
                                      : Colors.black54,
                                ),
                              ),
                            );
                          }

                          return Column(
                            children: teamState.availableTeams.map((team) {
                              final bool selected =
                                  team.id == teamState.selectedTeamId;
                              return GestureDetector(
                                onTap: () {
                                  context.read<TeamBloc>().add(
                                    SwitchTeamContext(team.id),
                                  );
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(AppSpacing.sm),
                                  margin: const EdgeInsets.only(
                                    bottom: AppSpacing.xs,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isDark
                                        ? const Color(0xFF1B3A2D)
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: selected
                                          ? AppColors.primary
                                          : Colors.grey,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          '${team.club} ${team.category}',
                                          style: TextStyle(
                                            fontFamily: 'SFPro',
                                            color: isDark
                                                ? Colors.white
                                                : Colors.black,
                                          ),
                                        ),
                                      ),
                                      Text(
                                        team.memberRoles[teamState
                                                .currentUserId] ??
                                            teamState.userRoleInSelectedTeam,
                                        style: const TextStyle(
                                          fontFamily: 'SFPro',
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(width: AppSpacing.sm),
                                      Icon(
                                        selected
                                            ? Icons.check_circle
                                            : Icons.arrow_forward_ios,
                                        color: selected
                                            ? AppColors.primary
                                            : (isDark
                                                  ? Colors.white
                                                  : Colors.black),
                                        size: selected ? 20 : 16,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          );
                        },
                      ),

                      const SizedBox(height: AppSpacing.sm),
                      Container(
                        decoration: BoxDecoration(
                          color: isDark
                              ? const Color(0xFF1B3A2D)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          title: Text(
                            "Terms of privacy",
                            style: TextStyle(
                              fontFamily: 'SFPro',
                              color: isDark ? Colors.white : Colors.black,
                            ),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color: isDark ? Colors.white : Colors.black,
                          ),
                        ),
                      ),

                      const SizedBox(height: AppSpacing.sm),

                      // Log out
                      GestureDetector(
                        onTap: () => _showLogoutDialog(context),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: isDark
                                ? const Color(0xFF1B3A2D)
                                : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.red),
                          ),
                          child: const Center(
                            child: Text(
                              "Log out",
                              style: TextStyle(
                                fontFamily: 'SFPro',
                                color: Colors.red,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
