import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../appbar/CustomAppBar.dart';
import '../core/responsive_system.dart';
import '../core/responsive_widgets.dart';

class AddPlanScreen extends StatefulWidget {
  final void Function(Map<String, dynamic> plan) onPlanAdded;

  const AddPlanScreen({super.key, required this.onPlanAdded});

  @override
  State<AddPlanScreen> createState() => _AddPlanScreenState();
}

class _AddPlanScreenState extends State<AddPlanScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  
  String _selectedCategory = 'Offensive';
  String? _videoPath;
  String? _pdfPath;

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _pickFile(String type) async {
    final result = await FilePicker.platform.pickFiles(
      type: type == 'video' ? FileType.video : FileType.custom,
      allowedExtensions: type == 'pdf' ? ['pdf'] : null,
    );

    if (result != null && result.files.isNotEmpty) {
      final String? path = result.files.single.path;
      setState(() {
        if (type == 'video') {
          _videoPath = path;
        } else {
          _pdfPath = path;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final labelColor = isDark ? Colors.white70 : null;
    final textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(
        title: 'Add Plan',
        onBack: () => Navigator.pop(context),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDark
                ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                : [Colors.green, Colors.white],
          ),
          image: const DecorationImage(
            image: AssetImage('assets/background.png'),
            fit: BoxFit.cover,
            opacity: 0.2,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: kToolbarHeight + 20),
          child: SafeArea(
            top: false,
            child: ListView(
              padding: ResponsiveSystem.pagePadding(context),
              children: [
                TextField(
                  controller: _nameController,
                  style: TextStyle(color: textColor),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: 'Plan name',
                    labelStyle: TextStyle(color: labelColor),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    _categoryButton(
                      category: 'Offensive',
                      isDark: isDark,
                      textColor: textColor,
                    ),
                    _categoryButton(
                      category: 'Defensive',
                      isDark: isDark,
                      textColor: textColor,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  readOnly: true,
                  style: TextStyle(color: textColor),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: _videoPath == null
                        ? 'Upload plan video'
                        : 'Video: ${_videoPath!.split('/').last}',
                    labelStyle: TextStyle(color: labelColor),
                    prefixIcon: Icon(Icons.attach_file, color: labelColor),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onTap: () => _pickFile('video'),
                ),
                const SizedBox(height: 16),
                TextField(
                  readOnly: true,
                  style: TextStyle(color: textColor),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: _pdfPath == null
                        ? 'Upload plan pdf'
                        : 'PDF: ${_pdfPath!.split('/').last}',
                    labelStyle: TextStyle(color: labelColor),
                    prefixIcon: Icon(Icons.attach_file, color: labelColor),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onTap: () => _pickFile('pdf'),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _descriptionController,
                  maxLines: 4,
                  style: TextStyle(color: textColor),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: 'Plan Description',
                    labelStyle: TextStyle(color: labelColor),
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                ResponsivePrimaryButton(
                  context: context,
                  label: 'Add plan',
                  onPressed: () {
                    final plan = {
                      'category': _selectedCategory,
                      'name': _nameController.text.trim(),
                      'description': _descriptionController.text.trim(),
                      'pdfPath': _pdfPath ?? '',
                      'videoPath': _videoPath ?? '',
                      'image': 'assets/Plan1.png',
                    };
                    widget.onPlanAdded(plan);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Plan added successfully'),
                      ),
                    );
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _categoryButton({
    required String category,
    required bool isDark,
    required Color textColor,
  }) {
    final bool isSelected = _selectedCategory == category;

    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected
            ? Colors.green
            : (isDark ? const Color(0xFF1B3A2D) : Colors.grey.shade300),
        foregroundColor: isSelected ? Colors.white : textColor,
      ),
      onPressed: () {
        setState(() {
          _selectedCategory = category;
        });
      },
      child: Text(category),
    );
  }
}
