import 'package:flutter/material.dart';

class JoinTeamViewModel extends ChangeNotifier {
  final List<Map<String, dynamic>> _requests = [
    {"team": "Ittihad club U16 team boys A", "members": 5},
    {"team": "Smouha club U14 team Girls B", "members": 7},
  ];

  List<Map<String, dynamic>> get requests => List.unmodifiable(_requests);

  void rejectRequest(int index) {
    // Logic to reject request
    _requests.removeAt(index);
    notifyListeners();
  }

  void acceptRequest(int index) {
    // Logic to accept request
    _requests.removeAt(index);
    notifyListeners();
  }

  Future<bool> joinTeamById(String id) async {
    if (id.isEmpty) return false;
    // Logic to join team by ID
    return true;
  }
}
