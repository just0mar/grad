// import 'package:flutter/material.dart';
// import '../appbar/CustomAppBar.dart';
//
// class JoinTeamView extends StatelessWidget {
//   const JoinTeamView({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       extendBodyBehindAppBar: true,
//       appBar: const CustomAppBar(title: "Join Team"),
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//             colors: [Colors.green, Colors.white],
//           ),
//           image: DecorationImage(
//             image: AssetImage("assets/background.png"),
//             fit: BoxFit.cover,
//             opacity: 0.2,
//           ),
//         ),
//         child: DefaultTabController(
//           length: 2,
//           child: Column(
//             children: [
//               const SizedBox(height: kToolbarHeight + 20),
//               Container(
//                 margin: const EdgeInsets.symmetric(horizontal: 16),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(30),
//                 ),
//                 child: const TabBar(
//                   labelColor: Colors.green,
//                   unselectedLabelColor: Colors.black54,
//                   indicatorColor: AppColors.primary,
//                   tabs: [
//                     Tab(text: "Requests"),
//                     Tab(text: "Join by ID"),
//                   ],
//                 ),
//               ),
//               Expanded(
//                 child: TabBarView(
//                   children: [
//                     _RequestsTab(),
//                     _JoinByIdTab(),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class _RequestsTab extends StatelessWidget {
//   const _RequestsTab();
//
//   @override
//   Widget build(BuildContext context) {
//     final requests = [
//       {"team": "Ittihad club U16 team boys A", "members": 5},
//       {"team": "Smouha club U14 team Girls B", "members": 7},
//     ];
//
//     return ListView.builder(
//       padding: const EdgeInsets.all(16),
//       itemCount: requests.length,
//       itemBuilder: (context, index) {
//         final req = requests[index];
//         return Card(
//           margin: const EdgeInsets.only(bottom: 12),
//           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
//           child: ListTile(
//             title: Text("${req["team"]}!"),
//             subtitle: Text("${req["members"]} members"),
//             trailing: Row(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 // ❌ Reject in red circle
//                 CircleAvatar(
//                   backgroundColor: Colors.red,
//                   child: IconButton(
//                     icon: const Icon(Icons.close, color: Colors.white),
//                     onPressed: () {
//                       ScaffoldMessenger.of(context).showSnackBar(
//                         SnackBar(content: Text("Rejected ${req["team"]}")),
//                       );
//                     },
//                   ),
//                 ),
//                 const SizedBox(width: 8),
//                 // ✅ Accept in green circle
//                 CircleAvatar(
//                   backgroundColor: Colors.green,
//                   child: IconButton(
//                     icon: const Icon(Icons.check, color: Colors.white),
//                     onPressed: () {
//                       ScaffoldMessenger.of(context).showSnackBar(
//                         SnackBar(content: Text("Joined ${req["team"]} successfully")),
//                       );
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
//
// class _JoinByIdTab extends StatefulWidget {
//   @override
//   State<_JoinByIdTab> createState() => _JoinByIdTabState();
// }
//
// class _JoinByIdTabState extends State<_JoinByIdTab> {
//   final TextEditingController _idController = TextEditingController();
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         children: [
//           // ✅ Input field wrapped in white container with radius 30
//           Container(
//             decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.circular(30),
//             ),
//             child: TextField(
//               controller: _idController,
//               keyboardType: TextInputType.number,
//               decoration: const InputDecoration(
//                 labelText: "Team ID",
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.all(Radius.circular(30)),
//                   borderSide: BorderSide(color: AppColors.primary),
//                 ),
//               ),
//             ),
//           ),
//           const SizedBox(height: 20),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(
//               backgroundColor: Colors.green,
//               minimumSize: const Size(double.infinity, 50),
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(30),
//               ),
//             ),
//             onPressed: () {
//               final enteredId = _idController.text.trim();
//               if (enteredId.isNotEmpty) {
//                 showDialog(
//                   context: context,
//                   builder: (BuildContext context) {
//                     return Dialog(
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(30),
//                       ),
//                       child: Padding(
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../core/responsive_system.dart';
import '../core/responsive_widgets.dart';
import 'join_team_bloc.dart';

class JoinTeamView extends StatelessWidget {
  const JoinTeamView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => JoinTeamBloc(),
      child: const _JoinTeamContent(),
    );
  }
}

class _JoinTeamContent extends StatelessWidget {
  const _JoinTeamContent();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: "Join Team"),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
            ),
            image: const DecorationImage(
              image: AssetImage("assets/background.png"),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: DefaultTabController(
            length: 2,
            child: Column(
              children: [
                const SizedBox(height: kToolbarHeight + 48),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 24),
                  decoration: BoxDecoration(
                    color: isDark ? const Color(0xFF1B3A2D) : Colors.white,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: TabBar(
                    labelColor: Colors.green,
                    unselectedLabelColor: isDark
                        ? Colors.white60
                        : Colors.black54,
                    indicatorColor: AppColors.primary,
                    labelStyle: const TextStyle(
                      fontFamily: 'SFPro',
                      fontWeight: FontWeight.bold,
                    ),
                    unselectedLabelStyle: const TextStyle(fontFamily: 'SFPro'),
                    tabs: const [
                      Tab(text: "Requests"),
                      Tab(text: "Join by ID"),
                    ],
                  ),
                ),
                const Expanded(
                  child: TabBarView(children: [_RequestsTab(), _JoinByIdTab()]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RequestsTab extends StatelessWidget {
  const _RequestsTab();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    return BlocBuilder<JoinTeamBloc, JoinTeamState>(
      builder: (context, state) {
        final requests = state.requests;

        if (requests.isEmpty) {
          return Center(
            child: Text(
              "No pending requests",
              style: TextStyle(
                fontFamily: 'SFPro',
                color: isDark ? Colors.white70 : Colors.black54,
              ),
            ),
          );
        }

        return ListView.builder(
          padding: ResponsiveSystem.pagePadding(context),
          itemCount: requests.length,
          itemBuilder: (context, index) {
            final req = requests[index];
            return Card(
              color: cardBg,
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              child: ListTile(
                title: Text(
                  "${req["team"]}!",
                  style: TextStyle(
                    color: textColor,
                    fontFamily: 'SFPro',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  "${req["members"]} members",
                  style: TextStyle(
                    color: isDark ? Colors.white54 : Colors.black54,
                    fontFamily: 'SFPro',
                  ),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.red,
                      radius: 18,
                      child: IconButton(
                        iconSize: 18,
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () {
                          final teamName = req["team"];
                          context.read<JoinTeamBloc>().add(
                            RejectRequest(index),
                          );
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text("Rejected $teamName")),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    CircleAvatar(
                      backgroundColor: Colors.green,
                      radius: 18,
                      child: IconButton(
                        iconSize: 18,
                        icon: const Icon(Icons.check, color: Colors.white),
                        onPressed: () {
                          final teamName = req["team"];
                          context.read<JoinTeamBloc>().add(
                            AcceptRequest(index),
                          );
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text("Joined $teamName successfully"),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _JoinByIdTab extends StatefulWidget {
  const _JoinByIdTab();

  @override
  State<_JoinByIdTab> createState() => _JoinByIdTabState();
}

class _JoinByIdTabState extends State<_JoinByIdTab> {
  final TextEditingController _idController = TextEditingController();

  @override
  void dispose() {
    _idController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        children: [
          TextField(
            controller: _idController,
            keyboardType: TextInputType.number,
            style: TextStyle(color: textColor, fontFamily: 'SFPro'),
            decoration: InputDecoration(
              filled: true,
              fillColor: fieldColor,
              labelText: "Team ID",
              labelStyle: TextStyle(
                color: isDark ? Colors.white70 : Colors.black54,
                fontFamily: 'SFPro',
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: AppColors.primary),
              ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: isDark ? Colors.white24 : AppColors.primary,
                ),
                borderRadius: BorderRadius.circular(30),
              ),
            ),
          ),
          const SizedBox(height: 24),
          ResponsivePrimaryButton(
            context: context,
            label: "Join",
            onPressed: () async {
              final enteredId = _idController.text.trim();
              if (enteredId.isNotEmpty) {
                final bloc = context.read<JoinTeamBloc>();
                final success = await bloc.joinTeamById(enteredId);
                if (!context.mounted) return;
                if (success) {
                  showDialog(
                    context: context,
                    builder: (ctx) => Dialog(
                      backgroundColor: fieldColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Align(
                              alignment: Alignment.topRight,
                              child: IconButton(
                                icon: Icon(Icons.close, color: textColor),
                                onPressed: () => Navigator.pop(ctx),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              "Joined team with ID $enteredId successfully!",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: textColor,
                                fontFamily: 'SFPro',
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 20),
                            ResponsivePrimaryButton(
                              context: ctx,
                              label: "Ok",
                              onPressed: () => Navigator.pop(ctx),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }
              }
            },
          ),
        ],
      ),
    );
  }
}
