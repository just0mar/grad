import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

// Events
abstract class JoinTeamEvent extends Equatable {
  const JoinTeamEvent();
  @override
  List<Object?> get props => [];
}

class AcceptRequest extends JoinTeamEvent {
  final int index;
  const AcceptRequest(this.index);
  @override
  List<Object?> get props => [index];
}

class RejectRequest extends JoinTeamEvent {
  final int index;
  const RejectRequest(this.index);
  @override
  List<Object?> get props => [index];
}

// State
class JoinTeamState extends Equatable {
  final List<Map<String, dynamic>> requests;

  const JoinTeamState({required this.requests});

  JoinTeamState copyWith({
    List<Map<String, dynamic>>? requests,
  }) {
    return JoinTeamState(
      requests: requests ?? this.requests,
    );
  }

  @override
  List<Object?> get props => [requests];
}

// Bloc
class JoinTeamBloc extends Bloc<JoinTeamEvent, JoinTeamState> {
  JoinTeamBloc() : super(const JoinTeamState(requests: [
    {"team": "Ittihad club U16 team boys A", "members": 5},
    {"team": "Smouha club U14 team Girls B", "members": 7},
  ])) {
    on<AcceptRequest>((event, emit) {
      final updated = List<Map<String, dynamic>>.from(state.requests);
      updated.removeAt(event.index);
      emit(state.copyWith(requests: updated));
    });

    on<RejectRequest>((event, emit) {
      final updated = List<Map<String, dynamic>>.from(state.requests);
      updated.removeAt(event.index);
      emit(state.copyWith(requests: updated));
    });
  }

  Future<bool> joinTeamById(String id) async {
    if (id.isEmpty) return false;
    // Logic to join team by ID
    await Future.delayed(const Duration(milliseconds: 500));
    return true;
  }
}
