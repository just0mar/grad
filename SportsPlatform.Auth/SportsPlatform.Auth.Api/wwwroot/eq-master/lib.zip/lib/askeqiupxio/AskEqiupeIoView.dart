import 'package:flutter/material.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';

class AskEquipoView extends StatefulWidget {
  const AskEquipoView({super.key});

  @override
  State<AskEquipoView> createState() => _AskEquipoViewState();
}

class _AskEquipoViewState extends State<AskEquipoView> {
  final List<Map<String, dynamic>> _messages = [
    {"text": "Welcome to Ask Equipo! 🚀", "fromMe": false},
    {
      "text": "Here you'll chat with the AI assistant once integrated.",
      "fromMe": false,
    },
  ];
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  void _sendMessage() {
    final text = _controller.text.trim();
    if (text.isNotEmpty) {
      setState(() => _messages.add({"text": text, "fromMe": true}));
      _controller.clear();

      Future.delayed(const Duration(milliseconds: 100), () {
        if (_scrollController.hasClients) {
          _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
        }
      });

      Future.delayed(const Duration(seconds: 1), () {
        setState(
          () => _messages.add({
            "text": "AI response coming soon...",
            "fromMe": false,
          }),
        );
        if (_scrollController.hasClients) {
          _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: "Ask Equipo"),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
            ),
            image: const DecorationImage(
              image: AssetImage('assets/background.png'),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: Column(
            children: [
              const SizedBox(height: kToolbarHeight + 48),
              Expanded(
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(12),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) {
                    final message = _messages[index];
                    final fromMe = message["fromMe"] as bool;
                    return Row(
                      mainAxisAlignment: fromMe
                          ? MainAxisAlignment.end
                          : MainAxisAlignment.start,
                      children: [
                        if (!fromMe)
                          const CircleAvatar(
                            backgroundColor: Colors.grey,
                            child: Icon(Icons.smart_toy, color: Colors.white),
                          ),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            decoration: BoxDecoration(
                              color: fromMe
                                  ? Colors.green
                                  : isDark
                                  ? const Color(0xFF1B3A2D)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.1),
                                  blurRadius: 4,
                                  offset: const Offset(2, 2),
                                ),
                              ],
                            ),
                            child: Text(
                              message["text"],
                              style: TextStyle(
                                fontFamily: 'SFPro',
                                color: fromMe
                                    ? Colors.white
                                    : isDark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (fromMe)
                          const CircleAvatar(
                            backgroundColor: Colors.green,
                            child: Icon(Icons.person, color: Colors.white),
                          ),
                      ],
                    );
                  },
                ),
              ),
              _MessageInput(controller: _controller, onSend: _sendMessage),
            ],
          ),
        ),
      ),
    );
  }
}

class _MessageInput extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;

  const _MessageInput({required this.controller, required this.onSend});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: TextField(
        controller: controller,
        style: TextStyle(
          fontFamily: 'SFPro',
          color: isDark ? Colors.white : Colors.black,
        ),
        decoration: InputDecoration(
          filled: true,
          fillColor: isDark ? const Color(0xFF1B3A2D) : Colors.white,
          labelText: "Type your message...",
          labelStyle: TextStyle(
            fontFamily: 'SFPro',
            color: isDark ? Colors.white60 : Colors.black54,
          ),
          hintStyle: const TextStyle(fontFamily: 'SFPro'),
          border: const OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.primary),
            borderRadius: BorderRadius.all(Radius.circular(30)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: isDark ? Colors.white24 : AppColors.primary,
            ),
            borderRadius: const BorderRadius.all(Radius.circular(30)),
          ),
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.primary, width: 2),
            borderRadius: BorderRadius.all(Radius.circular(30)),
          ),
          suffixIcon: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.attach_file, color: AppColors.primary),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("File attachment coming soon..."),
                    ),
                  );
                },
              ),
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: CircleAvatar(
                  backgroundColor: Colors.green,
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white),
                    onPressed: onSend,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
