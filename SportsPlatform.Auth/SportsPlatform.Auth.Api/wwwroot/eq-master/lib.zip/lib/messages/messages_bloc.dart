import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'MessagesModel.dart';

// Events
abstract class MessagesEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadMessages extends MessagesEvent {}

class SearchMembers extends MessagesEvent {
  final String query;
  SearchMembers(this.query);

  @override
  List<Object?> get props => [query];
}

// States
class MessagesState extends Equatable {
  final List<TeamMember> members;
  final List<TeamMember> filteredMembers;
  final bool isLoading;

  const MessagesState({
    this.members = const [],
    this.filteredMembers = const [],
    this.isLoading = false,
  });

  MessagesState copyWith({
    List<TeamMember>? members,
    List<TeamMember>? filteredMembers,
    bool? isLoading,
  }) {
    return MessagesState(
      members: members ?? this.members,
      filteredMembers: filteredMembers ?? this.filteredMembers,
      isLoading: isLoading ?? this.isLoading,
    );
  }

  @override
  List<Object?> get props => [members, filteredMembers, isLoading];
}

// Bloc
class MessagesBloc extends Bloc<MessagesEvent, MessagesState> {
  MessagesBloc() : super(const MessagesState()) {
    on<LoadMessages>(_onLoadMessages);
    on<SearchMembers>(_onSearchMembers);
  }

  void _onLoadMessages(LoadMessages event, Emitter<MessagesState> emit) {
    emit(state.copyWith(isLoading: true));
    
    final initialMembers = [
      TeamMember(name: "Ahmed Ali", role: "Coach", image: "assets/profile.png"),
      TeamMember(name: "Ali Omar", role: "Team manager", image: "assets/profile.png"),
      TeamMember(name: "Sara Ashraf", role: "Doctor", image: "assets/profile.png"),
      TeamMember(name: "Mahmoud Hamed", role: "Performance analyst", image: "assets/profile.png"),
      TeamMember(name: "Loay Barakat", role: "Fitness coach", image: "assets/profile.png"),
      TeamMember(name: "Karim Mohamed", role: "Player", image: "assets/profile.png"),
      TeamMember(name: "Khaled Mostafa", role: "Player", image: "assets/profile.png"),
    ];

    emit(state.copyWith(
      members: initialMembers,
      filteredMembers: initialMembers,
      isLoading: false,
    ));
  }

  void _onSearchMembers(SearchMembers event, Emitter<MessagesState> emit) {
    if (event.query.isEmpty) {
      emit(state.copyWith(filteredMembers: state.members));
    } else {
      final filtered = state.members
          .where((m) => m.name.toLowerCase().contains(event.query.toLowerCase()))
          .toList();
      emit(state.copyWith(filteredMembers: filtered));
    }
  }
}
