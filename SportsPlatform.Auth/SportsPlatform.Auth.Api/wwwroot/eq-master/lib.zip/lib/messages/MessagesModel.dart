class TeamMember {
  final String name;
  final String role;
  final String image;

  TeamMember({
    required this.name,
    required this.role,
    required this.image,
  });
}
