import 'package:eqq/messages/MessagesView.dart';
import 'package:eqq/profile/ProfileView.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../addevent/AddEventView.dart';
import '../addmembers/AddMembersView.dart';
import '../addteam/AddTeamModel.dart';
import '../addteam/AddTeamView.dart';
import '../announcement/AddAnnouncementView.dart';
import '../announcement/AnnouncementModel.dart';
import '../askeqiupxio/AskEqiupeIoView.dart';
import '../event/EventModel.dart';
import '../event/EventView.dart';
import '../event/event_bloc.dart';
import '../home/HomeView.dart';
import '../home/home_bloc.dart';
import '../jointeam/JoinTeamView.dart';
import '../members/GameSquadView.dart';
import '../members/PlayerSelectionView.dart';
import '../notifications/notification_bloc.dart';
import '../settings/SettingsView.dart';
import '../team/TeamView.dart';
import '../team/team_bloc.dart';
import '../core/design_tokens.dart';

class MainNavigation extends StatefulWidget {
  final String userRole;
  final String userId;

  const MainNavigation({
    super.key,
    required this.userRole,
    required this.userId,
  });

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;
  bool _fabExpanded = false;

  final List<int> _tabHistory = [0];

  final List<Map<String, dynamic>> _plans = [];

  String _currentSport = 'Basketball';
  String _currentTeamName = 'My Team';

  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _buildPages();
    context.read<TeamBloc>().add(
      ConfigureTeamAccess(userId: widget.userId, fallbackRole: widget.userRole),
    );
  }

  void _buildPages() {
    _pages = [
      const HomeView(),
      const EventView(),
      TeamView(
        sport: _currentSport,
        teamName: _currentTeamName,
        userRole: widget.userRole,
      ),
      ProfileView(plans: _plans),
      MessagesView(plans: _plans),
    ];
  }

  void _onTabTapped(int index) {
    if (index == _selectedIndex) return;
    setState(() {
      _tabHistory.add(index);
      _selectedIndex = index;
    });
  }

  bool _onBackPressed() {
    if (_tabHistory.length > 1) {
      setState(() {
        _tabHistory.removeLast();
        _selectedIndex = _tabHistory.last;
      });
      return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<TeamBloc, TeamState>(
      listenWhen: (previous, current) =>
          previous.selectedTeamId != current.selectedTeamId,
      listener: (context, state) {
        setState(() {
          _currentTeamName = state.selectedTeamName;
          final selectedTeam = state.availableTeams.firstWhere(
            (team) => team.id == state.selectedTeamId,
            orElse: () => Team(
              country: '',
              club: _currentTeamName,
              sport: _currentSport,
              category: '',
            ),
          );
          _currentSport = selectedTeam.sport;
          _buildPages();
        });
      },
      child: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) {
            _onBackPressed();
          }
        },
        child: Scaffold(
          body: IndexedStack(index: _selectedIndex, children: _pages),
          bottomNavigationBar: _buildBottomNav(),
          floatingActionButton: _buildFabMenu(),
          floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1B3A2D) : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navItem(icon: Icons.home, label: 'Home', index: 0),
          _navItem(icon: Icons.event, label: 'Events', index: 1),
          _navItem(icon: Icons.group, label: 'Team', index: 2),
          _navItem(icon: Icons.person, label: 'Profile', index: 3),
          _navItem(icon: Icons.message, label: 'Messages', index: 4),
        ],
      ),
    );
  }

  Widget _navItem({
    required IconData icon,
    required String label,
    required int index,
  }) {
    final bool selected = _selectedIndex == index;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color unselectedColor = isDark ? Colors.white60 : Colors.grey;
    final Color labelColor = isDark ? Colors.white : Colors.black;

    if (selected) {
      return GestureDetector(
        onTap: () => _onTabTapped(index),
        child: Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: const BoxDecoration(
            color: Colors.green,
            shape: BoxShape.circle,
          ),
          padding: const EdgeInsets.all(16),
          child: Icon(icon, color: Colors.white),
        ),
      );
    }

    return GestureDetector(
      onTap: () => _onTabTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: unselectedColor),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: labelColor,
              fontWeight: FontWeight.bold,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFabMenu() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 88, right: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (_fabExpanded) ..._buildRoleActions(),
          const SizedBox(height: 16),
          SizedBox(
            width: 56,
            height: 56,
            child: FloatingActionButton(
              backgroundColor: AppColors.primaryDark,
              shape: const CircleBorder(),
              onPressed: () => setState(() => _fabExpanded = !_fabExpanded),
              child: Icon(
                _fabExpanded ? Icons.close : Icons.sports_basketball,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildRoleActions() {
    final String activeRole = context.select((TeamBloc bloc) {
      if (bloc.state.userRoleInSelectedTeam.isNotEmpty) {
        return bloc.state.userRoleInSelectedTeam;
      }
      return widget.userRole;
    });
    final List<Map<String, dynamic>> actions;

    switch (activeRole.trim()) {
      case 'Team Manager':
        actions = [
          {'icon': Icons.group, 'label': 'Add Team', 'type': 'addTeam'},
          {'icon': Icons.event, 'label': 'Add Event', 'type': 'addEvent'},
          {
            'icon': Icons.announcement,
            'label': 'Add Announcements',
            'type': 'addAnnouncement',
          },
          {
            'icon': Icons.group_add,
            'label': 'Join Team',
            'type': 'navigate',
            'route': const JoinTeamView(),
          },
          {
            'icon': Icons.person_add,
            'label': 'Add Members',
            'type': 'addMembers',
          },
          {
            'icon': Icons.settings,
            'label': 'Settings',
            'type': 'navigate',
            'route': const SettingsView(),
          },
        ];
        break;
      case 'Coach':
        actions = [
          {'icon': Icons.event, 'label': 'Add Event', 'type': 'addEvent'},
          {
            'icon': Icons.announcement,
            'label': 'Add Announcements',
            'type': 'addAnnouncement',
          },
          {
            'icon': Icons.group_add,
            'label': 'Join Team',
            'type': 'navigate',
            'route': const JoinTeamView(),
          },
          {
            'icon': Icons.link,
            'label': 'Ask Equipo',
            'type': 'navigate',
            'route': const AskEquipoView(),
          },
          {'icon': Icons.groups, 'label': 'Add GameSquad', 'type': 'gameSquad'},
          {
            'icon': Icons.settings,
            'label': 'Settings',
            'type': 'navigate',
            'route': const SettingsView(),
          },
        ];
        break;
      case 'Fitness Coach':
        actions = [
          {
            'icon': Icons.upload_file,
            'label': 'Upload Fitness PDF',
            'type': 'selectPlayer',
            'actionType': 'fitness',
          },
          {
            'icon': Icons.group_add,
            'label': 'Join Team',
            'type': 'navigate',
            'route': const JoinTeamView(),
          },
          {
            'icon': Icons.settings,
            'label': 'Settings',
            'type': 'navigate',
            'route': const SettingsView(),
          },
        ];
        break;
      case 'Doctor':
        actions = [
          {
            'icon': Icons.medical_services,
            'label': 'Edit Medical Record',
            'type': 'selectPlayer',
            'actionType': 'medical',
          },
          {
            'icon': Icons.group_add,
            'label': 'Join Team',
            'type': 'navigate',
            'route': const JoinTeamView(),
          },
          {
            'icon': Icons.settings,
            'label': 'Settings',
            'type': 'navigate',
            'route': const SettingsView(),
          },
        ];
        break;
      case 'Player':
        actions = [
          {
            'icon': Icons.upload_file,
            'label': 'Upload Medical PDF',
            'type': 'selectPlayer',
            'actionType': 'medical',
          },
          {
            'icon': Icons.group_add,
            'label': 'Join Team',
            'type': 'navigate',
            'route': const JoinTeamView(),
          },
          {
            'icon': Icons.settings,
            'label': 'Settings',
            'type': 'navigate',
            'route': const SettingsView(),
          },
        ];
        break;
      case 'Analyst':
        actions = [
          {
            'icon': Icons.upload_file,
            'label': 'Upload Analysis PDF',
            'type': 'selectPlayer',
            'actionType': 'analysis',
          },
          {
            'icon': Icons.videocam,
            'label': 'Upload Analysis Video',
            'type': 'selectPlayer',
            'actionType': 'video',
          },
          {
            'icon': Icons.group_add,
            'label': 'Join Team',
            'type': 'navigate',
            'route': const JoinTeamView(),
          },
          {
            'icon': Icons.settings,
            'label': 'Settings',
            'type': 'navigate',
            'route': const SettingsView(),
          },
        ];
        break;
      default:
        actions = [
          {
            'icon': Icons.group_add,
            'label': 'Join Team',
            'type': 'navigate',
            'route': const JoinTeamView(),
          },
          {
            'icon': Icons.settings,
            'label': 'Settings',
            'type': 'navigate',
            'route': const SettingsView(),
          },
        ];
    }

    return actions
        .map(
          (action) => _FabActionButton(
            action: action,
            onPressed: () async {
              setState(() => _fabExpanded = false);
              final notifBloc = context.read<NotificationBloc>();

              switch (action['type']) {
                case 'addTeam':
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddTeamView()),
                  );
                  if (!mounted) return;
                  if (result != null && result is Team) {
                    final Team teamWithId = result.copyWith(
                      id: result.id.isNotEmpty
                          ? result.id
                          : 'team-${DateTime.now().millisecondsSinceEpoch}',
                      memberRoles: {
                        ...result.memberRoles,
                        widget.userId: activeRole,
                      },
                    );
                    context.read<HomeBloc>().add(AddTeamEvent(result));
                    context.read<TeamBloc>().add(
                      RegisterTeam(team: teamWithId, fallbackRole: activeRole),
                    );
                    context.read<TeamBloc>().add(
                      SwitchTeamContext(teamWithId.id),
                    );
                    setState(() {
                      _currentSport = teamWithId.sport;
                      _currentTeamName =
                          '${teamWithId.club} ${teamWithId.category}';
                      _buildPages();
                    });
                    notifBloc.add(
                      NotifyTeamAdded(
                        '${teamWithId.club} ${teamWithId.category}',
                      ),
                    );
                  }
                  break;

                case 'addEvent':
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddEventView()),
                  );
                  if (!mounted) return;
                  if (result != null && result is Event) {
                    context.read<EventBloc>().add(AddEvent(result));
                    _onTabTapped(1);
                    notifBloc.add(
                      NotifyEventAdded(
                        result.description.isNotEmpty
                            ? result.description
                            : result.type,
                        widget.userRole,
                      ),
                    );
                  }
                  break;

                case 'addAnnouncement':
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddAnnouncementView(
                        authorName: 'Ahmed Mahmoud',
                        authorRole: widget.userRole,
                        authorImage: 'assets/profile.png',
                      ),
                    ),
                  );
                  if (!mounted) return;
                  if (result != null && result is Announcement) {
                    context.read<HomeBloc>().add(AddAnnouncementEvent(result));
                    _onTabTapped(0);
                    notifBloc.add(
                      NotifyAnnouncementAdded('Ahmed Mahmoud', widget.userRole),
                    );
                  }
                  break;

                case 'addMembers':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddMembersView()),
                  );
                  if (!mounted) return;
                  // Since TeamBloc is now global, notifications can be handled
                  // via BlocListener in UI or simply here if we still want
                  // to peek into the state. For now, let's keep it simple.
                  break;

                case 'selectPlayer':
                  final actionType = action['actionType'] as String;
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PlayerSelectionView(
                        userRole: widget.userRole,
                        actionType: actionType,
                      ),
                    ),
                  );
                  if (!mounted) return;

                  final teamBloc = context.read<TeamBloc>();
                  for (final m in teamBloc.state.members) {
                    if (actionType == 'fitness' && m.fitnessPdfUrl != null) {
                      notifBloc.add(NotifyFitnessPdfUploaded(m.name));
                      break;
                    }
                    if (actionType == 'analysis' && m.analysisPdfUrl != null) {
                      notifBloc.add(NotifyAnalysisPdfUploaded(m.name));
                      break;
                    }
                    if (actionType == 'medical' && m.medicalPdfUrl != null) {
                      if (activeRole == 'Player') {
                        notifBloc.add(NotifyMedicalPdfUploaded(m.name));
                      } else if (activeRole == 'Doctor') {
                        notifBloc.add(NotifyMedicalRecordUpdated(m.name));
                      }
                      break;
                    }
                    if (actionType == 'video' && m.videoUrl != null) {
                      notifBloc.add(NotifyAnalysisPdfUploaded(m.name));
                      break;
                    }
                  }
                  break;

                case 'gameSquad':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const GameSquadView()),
                  );
                  if (!context.mounted) return;
                  notifBloc.add(NotifyGameSquadSelected());
                  break;

                case 'navigate':
                default:
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => action['route']),
                  );
                  if (!context.mounted) return;
              }
            },
          ),
        )
        .toList();
  }
}

class _FabActionButton extends StatefulWidget {
  final Map<String, dynamic> action;
  final VoidCallback onPressed;

  const _FabActionButton({required this.action, required this.onPressed});

  @override
  State<_FabActionButton> createState() => _FabActionButtonState();
}

class _FabActionButtonState extends State<_FabActionButton> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: MouseRegion(
        onEnter: (_) => setState(() => _hovered = true),
        onExit: (_) => setState(() => _hovered = false),
        child: GestureDetector(
          onTapDown: (_) => setState(() => _hovered = true),
          onTapUp: (_) => setState(() => _hovered = false),
          onTapCancel: () => setState(() => _hovered = false),
          onTap: widget.onPressed,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: _hovered
                  ? AppColors.primary.withValues(alpha: 0.15)
                  : Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: _hovered ? AppColors.primary : Colors.transparent,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(widget.action['icon'], color: Colors.green),
                const SizedBox(width: 8),
                Text(
                  widget.action['label'],
                  style: const TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
