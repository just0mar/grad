import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appbar/CustomAppBar.dart';
import '../core/responsive_system.dart';
import '../core/responsive_widgets.dart';
import 'AddTeamModel.dart';
import 'add_team_bloc.dart';

class AddTeamView extends StatelessWidget {
  const AddTeamView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AddTeamBloc(),
      child: const _AddTeamContent(),
    );
  }
}

class _AddTeamContent extends StatelessWidget {
  const _AddTeamContent();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final labelColor = isDark ? Colors.white70 : null;
    final textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: 'ADD TEAM'),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            image: const DecorationImage(
              image: AssetImage('assets/background.png'),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(top: kToolbarHeight + 48),
            child: SafeArea(
              top: false,
              child: BlocBuilder<AddTeamBloc, AddTeamState>(
                builder: (context, state) {
                  return SingleChildScrollView(
                    padding: ResponsiveSystem.pagePadding(context),
                    child: Column(
                      children: [
                        _buildDropdown(
                          context,
                          label: 'Country',
                          items: state.countries,
                          currentValue: state.selectedCountry,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(CountryChanged(val)),
                        ),
                        const SizedBox(height: 16),
                        _buildDropdown(
                          context,
                          label: 'Club',
                          items: state.clubs,
                          currentValue: state.selectedClub,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(ClubChanged(val)),
                        ),
                        const SizedBox(height: 16),
                        _buildDropdown(
                          context,
                          label: 'Sport',
                          items: state.sports,
                          currentValue: state.selectedSport,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(SportChanged(val)),
                        ),
                        const SizedBox(height: 16),
                        _buildDropdown(
                          context,
                          label: 'Team Category',
                          items: state.categories,
                          currentValue: state.selectedCategory,
                          fieldColor: fieldColor,
                          labelColor: labelColor,
                          textColor: textColor,
                          onChanged: (val) => context.read<AddTeamBloc>().add(CategoryChanged(val)),
                        ),
                        const SizedBox(height: 24),
                        ResponsivePrimaryButton.icon(
                          context: context,
                          backgroundColor: fieldColor,
                          foregroundColor: isDark ? Colors.white : Colors.green,
                          icon: Icons.location_on,
                          label: 'Allow Location',
                          onPressed: () {},
                        ),
                        const SizedBox(height: 24),
                        ResponsivePrimaryButton(
                          context: context,
                          label: 'Add Team',
                          onPressed: () {
                            final Team team = state.buildTeam();
                            Navigator.pop(context, team);
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown(
    BuildContext context, {
    required String label,
    required List<String> items,
    required String? currentValue,
    required Color fieldColor,
    required Color? labelColor,
    required Color textColor,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      initialValue: currentValue,
      dropdownColor: fieldColor,
      style: TextStyle(
          color: textColor,
          fontFamily: 'SFPro',
          fontSize: ResponsiveSystem.bodyFontSize(context)),
      decoration: InputDecoration(
        filled: true,
        fillColor: fieldColor,
        labelText: label,
        labelStyle: TextStyle(
            color: labelColor,
            fontFamily: 'SFPro',
            fontSize: ResponsiveSystem.bodyFontSize(context)),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
      items: items
          .map(
            (item) => DropdownMenuItem<String>(
              value: item,
              child: Text(item, style: const TextStyle(fontFamily: 'SFPro')),
            ),
          )
          .toList(),
      onChanged: onChanged,
    );
  }
}
