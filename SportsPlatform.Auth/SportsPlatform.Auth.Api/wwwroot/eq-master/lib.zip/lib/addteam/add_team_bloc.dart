import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'AddTeamModel.dart';

// Events
abstract class AddTeamEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class CountryChanged extends AddTeamEvent {
  final String? country;
  CountryChanged(this.country);
  @override
  List<Object?> get props => [country];
}

class ClubChanged extends AddTeamEvent {
  final String? club;
  ClubChanged(this.club);
  @override
  List<Object?> get props => [club];
}

class SportChanged extends AddTeamEvent {
  final String? sport;
  SportChanged(this.sport);
  @override
  List<Object?> get props => [sport];
}

class CategoryChanged extends AddTeamEvent {
  final String? category;
  CategoryChanged(this.category);
  @override
  List<Object?> get props => [category];
}

// State
class AddTeamState extends Equatable {
  final String? selectedCountry;
  final String? selectedClub;
  final String? selectedSport;
  final String? selectedCategory;

  final List<String> countries = const ['Egypt', 'USA', 'Spain'];
  final List<String> clubs = const ['Ittihad', 'Ahly', 'Zamalek'];
  final List<String> sports = const ['Basketball', 'Football', 'Volleyball'];
  final List<String> categories = const ['U16 Boys', 'U18 Girls', 'Senior'];

  const AddTeamState({
    this.selectedCountry,
    this.selectedClub,
    this.selectedSport,
    this.selectedCategory,
  });

  AddTeamState copyWith({
    String? selectedCountry,
    String? selectedClub,
    String? selectedSport,
    String? selectedCategory,
  }) {
    return AddTeamState(
      selectedCountry: selectedCountry ?? this.selectedCountry,
      selectedClub: selectedClub ?? this.selectedClub,
      selectedSport: selectedSport ?? this.selectedSport,
      selectedCategory: selectedCategory ?? this.selectedCategory,
    );
  }

  Team buildTeam() {
    return Team(
      country: selectedCountry ?? 'Unknown',
      club: selectedClub ?? 'Unknown',
      sport: selectedSport ?? 'Unknown',
      category: selectedCategory ?? 'Unknown',
    );
  }

  @override
  List<Object?> get props => [selectedCountry, selectedClub, selectedSport, selectedCategory];
}

// Bloc
class AddTeamBloc extends Bloc<AddTeamEvent, AddTeamState> {
  AddTeamBloc() : super(const AddTeamState()) {
    on<CountryChanged>((event, emit) => emit(state.copyWith(selectedCountry: event.country)));
    on<ClubChanged>((event, emit) => emit(state.copyWith(selectedClub: event.club)));
    on<SportChanged>((event, emit) => emit(state.copyWith(selectedSport: event.sport)));
    on<CategoryChanged>((event, emit) => emit(state.copyWith(selectedCategory: event.category)));
  }
}
