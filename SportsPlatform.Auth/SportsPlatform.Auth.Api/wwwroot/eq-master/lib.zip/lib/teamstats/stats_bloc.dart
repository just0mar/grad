import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '../gamehistory/GameHistoryModel.dart';

// Events
abstract class StatsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadStats extends StatsEvent {
  final String sport;
  LoadStats(this.sport);
  @override
  List<Object?> get props => [sport];
}

class UpdateTableStats extends StatsEvent {
  final List<Map<String, dynamic>> tableRows;
  UpdateTableStats(this.tableRows);
  @override
  List<Object?> get props => [tableRows];
}

// States
class StatsState extends Equatable {
  final List<Map<String, dynamic>> tableRows;
  final List<Map<String, dynamic>> chartLines;
  final List<GameHistory> gameHistory;
  final bool isLoading;

  const StatsState({
    this.tableRows = const [],
    this.chartLines = const [],
    this.gameHistory = const [],
    this.isLoading = false,
  });

  StatsState copyWith({
    List<Map<String, dynamic>>? tableRows,
    List<Map<String, dynamic>>? chartLines,
    List<GameHistory>? gameHistory,
    bool? isLoading,
  }) {
    return StatsState(
      tableRows: tableRows ?? this.tableRows,
      chartLines: chartLines ?? this.chartLines,
      gameHistory: gameHistory ?? this.gameHistory,
      isLoading: isLoading ?? this.isLoading,
    );
  }

  @override
  List<Object?> get props => [tableRows, chartLines, gameHistory, isLoading];
}

// Bloc
class StatsBloc extends Bloc<StatsEvent, StatsState> {
  StatsBloc() : super(const StatsState()) {
    on<LoadStats>(_onLoadStats);
    on<UpdateTableStats>(_onUpdateTableStats);
  }

  void _onLoadStats(LoadStats event, Emitter<StatsState> emit) {
    emit(state.copyWith(isLoading: true));
    
    List<Map<String, dynamic>> tableRows;
    List<Map<String, dynamic>> chartLines;

    switch (event.sport) {
      case "Basketball":
        tableRows = [
          {"title": "Total points", "lastGame": "68", "cumulative": "280"},
          {"title": "2 points", "lastGame": "25/30", "cumulative": "90/120"},
          {"title": "3 points", "lastGame": "4/10", "cumulative": "20/55"},
          {"title": "Free throws", "lastGame": "15/30", "cumulative": "60/100"},
          {"title": "Rebounds", "lastGame": "30", "cumulative": "125"},
          {"title": "Assists", "lastGame": "18", "cumulative": "75"},
          {"title": "Blocks", "lastGame": "5", "cumulative": "22"},
        ];
        chartLines = [
          {
            "label": "3 points",
            "color": Colors.blue.shade700,
            "spots": [2.0, 4.0, 3.0, 5.0, 4.0, 6.0, 4.0],
          },
          {
            "label": "Rebounds",
            "color": Colors.green.shade400,
            "spots": [25.0, 28.0, 32.0, 29.0, 31.0, 27.0, 30.0],
          },
          {
            "label": "Blocks",
            "color": Colors.orange,
            "spots": [4.0, 6.0, 5.0, 7.0, 3.0, 8.0, 5.0],
          },
        ];
        break;
      case "Football":
        tableRows = [
          {"title": "Goals", "lastGame": "2", "cumulative": "12"},
          {"title": "Assists", "lastGame": "1", "cumulative": "8"},
          {"title": "Shots on target", "lastGame": "5/8", "cumulative": "25/40"},
          {"title": "Possession", "lastGame": "55%", "cumulative": "52%"},
          {"title": "Passes", "lastGame": "450", "cumulative": "1800"},
          {"title": "Tackles", "lastGame": "12", "cumulative": "50"},
        ];
        chartLines = [
          {
            "label": "Goals",
            "color": Colors.blue.shade700,
            "spots": [1.0, 2.0, 0.0, 3.0, 1.0, 2.0, 2.0],
          },
          {
            "label": "Assists",
            "color": Colors.green.shade400,
            "spots": [1.0, 1.0, 0.0, 2.0, 1.0, 3.0, 1.0],
          },
          {
            "label": "Shots",
            "color": Colors.orange,
            "spots": [4.0, 6.0, 3.0, 8.0, 5.0, 7.0, 5.0],
          },
        ];
        break;
      default:
        tableRows = [
          {"title": "Total points", "lastGame": "0", "cumulative": "0"},
        ];
        chartLines = [
          {
            "label": "Score",
            "color": Colors.blue.shade700,
            "spots": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
          },
        ];
    }

    final gameHistory = [
      GameHistory(
        opponent: "Smouha A",
        date: "Monday 29/12/2025",
        ourScore: 68,
        theirScore: 59,
        stats: [
          {"title": "Total points", "value": "64"},
          {"title": "2 points", "value": "25/30"},
          {"title": "3 points", "value": "4/10"},
          {"title": "Free throws", "value": "15/30"},
          {"title": "O Rebounds", "value": "10/34"},
          {"title": "D Rebounds", "value": "20/30"},
          {"title": "Assists", "value": "18"},
          {"title": "Blocks", "value": "5"},
        ],
        pdfFiles: ["Smouha A Box score.pdf", "Smouha A rotations.pdf"],
        videos: [
          {"title": "Offensive transition", "thumbnail": "assets/background.png"},
          {"title": "Defensive sets", "thumbnail": "assets/background.png"},
        ],
      ),
      GameHistory(
        opponent: "Sporting B",
        date: "Thursday 25/12/2025",
        ourScore: 80,
        theirScore: 49,
        stats: [
          {"title": "Total points", "value": "80"},
          {"title": "2 points", "value": "28/35"},
          {"title": "3 points", "value": "6/12"},
          {"title": "Free throws", "value": "12/15"},
          {"title": "O Rebounds", "value": "12/30"},
          {"title": "D Rebounds", "value": "22/28"},
          {"title": "Assists", "value": "22"},
          {"title": "Blocks", "value": "8"},
        ],
        pdfFiles: ["Sporting B Box score.pdf", "Sporting B rotations.pdf"],
        videos: [
          {"title": "Highlight reel", "thumbnail": "assets/background.png"},
        ],
      ),
    ];

    emit(state.copyWith(
      tableRows: tableRows,
      chartLines: chartLines,
      gameHistory: gameHistory,
      isLoading: false,
    ));
  }

  void _onUpdateTableStats(UpdateTableStats event, Emitter<StatsState> emit) {
    emit(state.copyWith(tableRows: event.tableRows));
  }
}
