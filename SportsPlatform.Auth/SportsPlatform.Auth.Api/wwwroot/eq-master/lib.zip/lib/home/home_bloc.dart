import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../addteam/AddTeamModel.dart';
import '../announcement/AnnouncementModel.dart';

// Events
abstract class HomeEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadHomeData extends HomeEvent {}

class AddTeamEvent extends HomeEvent {
  final Team team;
  AddTeamEvent(this.team);
  @override
  List<Object?> get props => [team];
}

class AddAnnouncementEvent extends HomeEvent {
  final Announcement announcement;
  AddAnnouncementEvent(this.announcement);
  @override
  List<Object?> get props => [announcement];
}

// State
class HomeState extends Equatable {
  final List<Team?> teams;
  final List<Announcement> announcements;
  final bool isLoading;

  const HomeState({
    this.teams = const [],
    this.announcements = const [],
    this.isLoading = false,
  });

  HomeState copyWith({
    List<Team?>? teams,
    List<Announcement>? announcements,
    bool? isLoading,
  }) {
    return HomeState(
      teams: teams ?? this.teams,
      announcements: announcements ?? this.announcements,
      isLoading: isLoading ?? this.isLoading,
    );
  }

  @override
  List<Object?> get props => [teams, announcements, isLoading];
}

// Bloc
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc() : super(const HomeState(teams: [null, null, null, null])) {
    on<LoadHomeData>(_onLoadHomeData);
    on<AddTeamEvent>(_onAddTeam);
    on<AddAnnouncementEvent>(_onAddAnnouncement);
  }

  void _onLoadHomeData(LoadHomeData event, Emitter<HomeState> emit) {
    emit(state.copyWith(isLoading: true));
    // Simulate loading data
    emit(state.copyWith(isLoading: false));
  }

  void _onAddTeam(AddTeamEvent event, Emitter<HomeState> emit) {
    final newTeams = List<Team?>.from(state.teams);
    final int emptyIndex = newTeams.indexWhere((t) => t == null);
    if (emptyIndex != -1) {
      newTeams[emptyIndex] = event.team;
      emit(state.copyWith(teams: newTeams));
    }
  }

  void _onAddAnnouncement(AddAnnouncementEvent event, Emitter<HomeState> emit) {
    final newAnnouncements = List<Announcement>.from(state.announcements)
      ..add(event.announcement);
    emit(state.copyWith(announcements: newAnnouncements));
  }
}
