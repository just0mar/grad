import 'package:flutter_bloc/flutter_bloc.dart';
import '../core/responsive_system.dart';
import '../event/EventModel.dart';
import '../event/event_bloc.dart';
import 'package:flutter/material.dart';
import '../addteam/AddTeamModel.dart';
import '../announcement/AnnouncementModel.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import 'home_bloc.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final subtitleColor = isDark ? Colors.white54 : Colors.grey;
    const int teamColumns = 2;

    return BlocProvider(
      create: (context) => HomeBloc()..add(LoadHomeData()),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: const CustomAppBar(title: "Home", showBackButton: false),
        body: BlocBuilder<HomeBloc, HomeState>(
          builder: (context, state) {
            final List<Team?> teams = state.teams;
            final List<Announcement> announcements = state.announcements;

            return SizedBox.expand(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: isDark
                        ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                        : [Colors.green, Colors.white],
                  ),
                  image: const DecorationImage(
                    image: AssetImage("assets/background.png"),
                    fit: BoxFit.cover,
                    opacity: 0.15,
                  ),
                ),
                child: SafeArea(
                  child: SingleChildScrollView(
                    padding: ResponsiveSystem.pagePadding(context),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: AppSpacing.md),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: teamColumns,
                            mainAxisSpacing: 16,
                            crossAxisSpacing: 16,
                            childAspectRatio: 1.1,
                          ),
                          itemCount: teams.length,
                          itemBuilder: (context, index) {
                            final team = teams[index];
                            return _buildTeamCard(
                              team,
                              cardBg,
                              textColor,
                              subtitleColor,
                              isDark,
                            );
                          },
                        ),

                        BlocBuilder<EventBloc, EventState>(
                          builder: (context, eventState) {
                            final List<Event> upcoming =
                                eventState.upcomingEvents;
                            if (upcoming.isEmpty) return const SizedBox();
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 32),
                                const Text(
                                  "UPCOMING",
                                  style: TextStyle(
                                    fontFamily: 'Facon',
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.2,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                SizedBox(
                                  height:
                                      ResponsiveSystem.height(context) * 0.25,
                                  child: ListView.separated(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: upcoming.length,
                                    separatorBuilder: (_, __) =>
                                        const SizedBox(width: 16),
                                    itemBuilder: (context, index) {
                                      final event = upcoming[index];
                                      return _buildEventCard(
                                        context,
                                        event,
                                        isDark,
                                      );
                                    },
                                  ),
                                ),
                              ],
                            );
                          },
                        ),

                        if (announcements.isNotEmpty) ...[
                          const SizedBox(height: 32),
                          Text(
                            "ANNOUNCEMENTS",
                            style: TextStyle(
                              fontFamily: 'Facon',
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                              color: textColor,
                            ),
                          ),
                          const SizedBox(height: 16),
                          ...announcements.map(
                            (a) => _buildAnnouncementCard(a, isDark, textColor),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildTeamCard(
    Team? team,
    Color bg,
    Color textColor,
    Color subtitleColor,
    bool isDark,
  ) {
    return Card(
      color: bg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: team == null ? null : () {},
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.sm),
          child: Center(
            child: team == null
                ? Icon(
                    Icons.add_circle_outline,
                    size: 40,
                    color: isDark ? Colors.white30 : Colors.grey[400],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        team.club,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: textColor,
                          fontFamily: 'SFPro',
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: AppSpacing.xs),
                      Text(
                        team.sport,
                        style: TextStyle(
                          fontSize: 14,
                          color: textColor.withValues(alpha: 0.8),
                          fontFamily: 'SFPro',
                        ),
                        maxLines: 1,
                      ),
                      const SizedBox(height: AppSpacing.xs),
                      Text(
                        team.category,
                        style: TextStyle(
                          fontSize: 12,
                          color: subtitleColor,
                          fontFamily: 'SFPro',
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  String _eventImage(String type) {
    switch (type.trim()) {
      case "Match":
        return "assets/ball.jpg";
      case "Training":
        return "assets/Dumbell.jpg";
      case "Meeting":
        return "assets/event.jpg";
      case "Test":
        return "assets/test.jpg";
      default:
        return "assets/background.png";
    }
  }

  Widget _buildEventCard(BuildContext context, Event event, bool isDark) {
    final colorDark = _eventColor(event.type);
    final colorLight = _eventColorLight(event.type);
    final dateStr =
        "${event.date.day} ${_months[event.date.month - 1]} ${event.date.year}";
    final timeStr = event.time.format(context);

    return Container(
      width: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: colorDark.withValues(alpha: 0.4),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(_eventImage(event.type), fit: BoxFit.cover),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    colorDark.withValues(alpha: 0.9),
                    colorLight.withValues(alpha: 0.5),
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AppSpacing.sm),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      event.type,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Icon(_eventIcon(event.type), color: Colors.white, size: 24),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        dateStr,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        timeStr,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _eventColor(String type) {
    switch (type.trim()) {
      case "Match":
        return Colors.blue.shade900;
      case "Training":
        return Colors.green.shade900;
      case "Meeting":
        return Colors.green.shade400;
      case "Test":
        return Colors.black;
      default:
        return Colors.grey;
    }
  }

  Color _eventColorLight(String type) {
    switch (type.trim()) {
      case "Match":
        return Colors.blue.shade700;
      case "Training":
        return Colors.green.shade800;
      case "Meeting":
        return Colors.green.shade500;
      case "Test":
        return Colors.grey.shade800;
      default:
        return Colors.grey;
    }
  }

  IconData _eventIcon(String type) {
    switch (type.trim()) {
      case "Match":
        return Icons.sports_soccer;
      case "Training":
        return Icons.fitness_center;
      case "Meeting":
        return Icons.event_note;
      case "Test":
        return Icons.assignment;
      default:
        return Icons.event;
    }
  }

  static const List<String> _months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  Widget _buildAnnouncementCard(Announcement a, bool isDark, Color textColor) {
    final bg = a.isEmergency
        ? (isDark ? Colors.red.shade900 : Colors.red.shade50)
        : (isDark ? const Color(0xFF1B3A2D) : Colors.white);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundImage: AssetImage(a.authorImage),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      a.authorName,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: textColor,
                      ),
                    ),
                    Text(
                      a.authorRole,
                      style: TextStyle(
                        color: isDark ? Colors.white54 : Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              if (a.isEmergency)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text(
                    "Emergency",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Text(a.caption, style: TextStyle(fontSize: 14, color: textColor)),
        ],
      ),
    );
  }
}
