import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appbar/CustomAppBar.dart';
import '../members/MemberModel.dart';
import '../members/MemberDetailView.dart';
import '../team/team_bloc.dart';
import 'search_bloc.dart';

class SearchView extends StatelessWidget {
  final List<Map<String, dynamic>> plans;

  const SearchView({
    super.key,
    required this.plans,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TeamBloc, TeamState>(
      builder: (context, state) {
        return BlocProvider(
          create: (_) => SearchBloc(members: state.members, plans: plans),
          child: const _SearchViewContent(),
        );
      },
    );
  }
}

class _SearchViewContent extends StatefulWidget {
  const _SearchViewContent();

  @override
  State<_SearchViewContent> createState() => _SearchViewContentState();
}

class _SearchViewContentState extends State<_SearchViewContent> {
  final TextEditingController _searchController = TextEditingController();
  final List<String> _tabs = ["Members", "Files", "Plans"];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    return BlocBuilder<SearchBloc, SearchState>(
      builder: (context, state) {
        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: const CustomAppBar(title: "Search"),
          body: SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: isDark
                      ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                      : [Colors.green, Colors.white],
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.2,
                ),
              ),
              child: SafeArea(
                child: Column(
                  children: [
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Container(
                        decoration: BoxDecoration(
                          color: fieldColor,
                          borderRadius: BorderRadius.circular(30),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.05),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                        child: TextField(
                          controller: _searchController,
                          style: TextStyle(fontFamily: 'SFPro', color: textColor),
                          onChanged: (val) => context.read<SearchBloc>().add(UpdateQuery(val)),
                          decoration: InputDecoration(
                            hintText: "Search members, files, or plans...",
                            hintStyle: TextStyle(
                              fontFamily: 'SFPro',
                              color: isDark ? Colors.white38 : Colors.black38,
                            ),
                            prefixIcon: Icon(
                              Icons.search,
                              color: isDark ? Colors.white54 : Colors.black45,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide: BorderSide.none,
                            ),
                            filled: true,
                            fillColor: fieldColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children:
                            _tabs.map((tab) {
                              final bool selected = state.selectedTab == tab;
                              return GestureDetector(
                                onTap: () => context.read<SearchBloc>().add(UpdateTab(tab)),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 28,
                                    vertical: 8,
                                  ),
                                  decoration: BoxDecoration(
                                    color:
                                        selected
                                            ? Colors.green
                                            : isDark
                                            ? const Color(0xFF1B3A2D)
                                            : Colors.white,
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color:
                                          selected
                                              ? Colors.green
                                              : isDark
                                              ? Colors.white24
                                              : Colors.grey.shade300,
                                    ),
                                  ),
                                  child: Text(
                                    tab,
                                    style: TextStyle(
                                      fontFamily: 'SFPro',
                                      color: selected ? Colors.white : textColor,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Expanded(
                      child: _buildResults(
                        context,
                        state,
                        isDark,
                        fieldColor,
                        textColor,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResults(
    BuildContext context,
    SearchState state,
    bool isDark,
    Color fieldColor,
    Color textColor,
  ) {
    switch (state.selectedTab) {
      case "Members":
        return _buildMembersList(
          context,
          state,
          isDark,
          fieldColor,
          textColor,
        );
      case "Files":
        return _buildFilesList(
          context,
          state,
          isDark,
          fieldColor,
          textColor,
        );
      case "Plans":
        return _buildPlansList(state, isDark, fieldColor, textColor);
      default:
        return const SizedBox();
    }
  }

  Widget _buildMembersList(
    BuildContext context,
    SearchState state,
    bool isDark,
    Color fieldColor,
    Color textColor,
  ) {
    final members = state.filteredMembers;
    if (members.isEmpty) return _buildEmpty("No members found", isDark);
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: members.length,
      itemBuilder: (_, i) {
        final m = members[i];
        final memberIndex = state.members.indexOf(m);
        return GestureDetector(
          onTap:
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (_) => MemberDetailView(
                        member: m,
                        memberIndex: memberIndex,
                      ),
                ),
              ),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: fieldColor,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                CircleAvatar(backgroundImage: AssetImage(m.image), radius: 26),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      m.name,
                      style: TextStyle(
                        fontFamily: 'SFPro',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: textColor,
                      ),
                    ),
                    Text(
                      m.role,
                      style: TextStyle(
                        fontFamily: 'SFPro',
                        color: isDark ? Colors.white54 : Colors.black54,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Icon(
                  Icons.chevron_right,
                  color: isDark ? Colors.white38 : Colors.black38,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildFilesList(
    BuildContext context,
    SearchState state,
    bool isDark,
    Color fieldColor,
    Color textColor,
  ) {
    final files = state.filteredFiles;
    if (files.isEmpty) return _buildEmpty("No files found", isDark);
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: files.length,
      itemBuilder: (_, i) {
        final f = files[i];
        final member = f["member"] as Member;
        final memberIndex = state.members.indexOf(member);
        return GestureDetector(
          onTap:
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (_) => MemberDetailView(
                        member: member,
                        memberIndex: memberIndex,
                      ),
                ),
              ),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: fieldColor,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: (f["color"] as Color).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    f["icon"] as IconData,
                    color: f["color"] as Color,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        f["name"],
                        style: TextStyle(
                          fontFamily: 'SFPro',
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: textColor,
                        ),
                      ),
                      Text(
                        "${f["type"]} • ${f["owner"]}",
                        style: TextStyle(
                          fontFamily: 'SFPro',
                          color: isDark ? Colors.white54 : Colors.black54,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.chevron_right,
                  color: isDark ? Colors.white38 : Colors.black38,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPlansList(
    SearchState state,
    bool isDark,
    Color fieldColor,
    Color textColor,
  ) {
    final plans = state.filteredPlans;
    if (plans.isEmpty) return _buildEmpty("No plans found", isDark);
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: plans.length,
      itemBuilder: (_, i) {
        final p = plans[i];
        final isOffensive = p["category"] == "Offensive";
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: fieldColor,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.green.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.sports, color: Colors.green, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p["title"],
                      style: TextStyle(
                        fontFamily: 'SFPro',
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: textColor,
                      ),
                    ),
                    Text(
                      p["category"],
                      style: TextStyle(
                        fontFamily: 'SFPro',
                        color: isDark ? Colors.white54 : Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color:
                      isOffensive
                          ? (isDark
                              ? Colors.green.shade900
                              : Colors.green.shade100)
                          : (isDark
                              ? Colors.blue.shade900
                              : Colors.blue.shade100),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  p["category"],
                  style: TextStyle(
                    fontFamily: 'SFPro',
                    color:
                        isOffensive
                            ? (isDark
                                ? Colors.greenAccent
                                : Colors.green.shade800)
                            : (isDark
                                ? Colors.lightBlueAccent
                                : Colors.blue.shade800),
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmpty(String message, bool isDark) {
    return Center(
      child: Text(
        message,
        style: TextStyle(
          fontFamily: 'SFPro',
          color: isDark ? Colors.white38 : Colors.black45,
          fontSize: 15,
        ),
      ),
    );
  }
}
