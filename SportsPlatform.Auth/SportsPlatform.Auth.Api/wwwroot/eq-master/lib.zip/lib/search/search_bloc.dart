import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '../core/design_tokens.dart';
import '../members/MemberModel.dart';

// Events
abstract class SearchEvent extends Equatable {
  const SearchEvent();
  @override
  List<Object?> get props => [];
}

class UpdateQuery extends SearchEvent {
  final String query;
  const UpdateQuery(this.query);
  @override
  List<Object?> get props => [query];
}

class UpdateTab extends SearchEvent {
  final String tab;
  const UpdateTab(this.tab);
  @override
  List<Object?> get props => [tab];
}

// State
class SearchState extends Equatable {
  final String selectedTab;
  final String query;
  final List<Member> members;
  final List<Map<String, dynamic>> plans;

  const SearchState({
    this.selectedTab = "Members",
    this.query = "",
    required this.members,
    required this.plans,
  });

  SearchState copyWith({
    String? selectedTab,
    String? query,
    List<Member>? members,
    List<Map<String, dynamic>>? plans,
  }) {
    return SearchState(
      selectedTab: selectedTab ?? this.selectedTab,
      query: query ?? this.query,
      members: members ?? this.members,
      plans: plans ?? this.plans,
    );
  }

  List<Member> get filteredMembers {
    if (query.isEmpty) return members;
    return members
        .where(
          (m) =>
              m.name.toLowerCase().contains(query.toLowerCase()) ||
              m.role.toLowerCase().contains(query.toLowerCase()),
        )
        .toList();
  }

  List<Map<String, dynamic>> get filteredFiles {
    final files = <Map<String, dynamic>>[];
    for (final m in members) {
      if (m.medicalPdfUrl != null) {
        files.add({
          "name": m.medicalPdfName ?? "Medical PDF",
          "owner": m.name,
          "type": "Medical",
          "icon": Icons.medical_services,
          "color": Colors.red,
          "member": m,
        });
      }
      if (m.fitnessPdfUrl != null) {
        files.add({
          "name": m.fitnessPdfName ?? "Fitness PDF",
          "owner": m.name,
          "type": "Fitness",
          "icon": Icons.fitness_center,
          "color": Colors.blue,
          "member": m,
        });
      }
      if (m.analysisPdfUrl != null) {
        files.add({
          "name": m.analysisPdfName ?? "Analysis PDF",
          "owner": m.name,
          "type": "Analysis",
          "icon": Icons.bar_chart,
          "color": AppColors.primary,
          "member": m,
        });
      }
    }
    if (query.isEmpty) return files;
    return files
        .where(
          (f) =>
              f["name"].toLowerCase().contains(query.toLowerCase()) ||
              f["owner"].toLowerCase().contains(query.toLowerCase()) ||
              f["type"].toLowerCase().contains(query.toLowerCase()),
        )
        .toList();
  }

  List<Map<String, dynamic>> get filteredPlans {
    if (query.isEmpty) return plans;
    return plans
        .where(
          (p) =>
              p["title"].toLowerCase().contains(query.toLowerCase()) ||
              p["category"].toLowerCase().contains(query.toLowerCase()) ||
              (p["description"] ?? "").toLowerCase().contains(
                query.toLowerCase(),
              ),
        )
        .toList();
  }

  @override
  List<Object?> get props => [selectedTab, query, members, plans];
}

// Bloc
class SearchBloc extends Bloc<SearchEvent, SearchState> {
  SearchBloc({
    required List<Member> members,
    required List<Map<String, dynamic>> plans,
  }) : super(SearchState(members: members, plans: plans)) {
    on<UpdateQuery>((event, emit) {
      emit(state.copyWith(query: event.query));
    });

    on<UpdateTab>((event, emit) {
      emit(state.copyWith(selectedTab: event.tab));
    });
  }
}
