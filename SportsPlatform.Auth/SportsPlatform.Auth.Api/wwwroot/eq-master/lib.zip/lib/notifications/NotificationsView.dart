import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import 'notification_bloc.dart';

class NotificationsView extends StatelessWidget {
  final String userRole;

  const NotificationsView({super.key, required this.userRole});

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inSeconds < 60) return "Just now";
    if (diff.inMinutes < 60) return "${diff.inMinutes}m ago";
    if (diff.inHours < 24) return "${diff.inHours}h ago";
    return "${diff.inDays}d ago";
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) {
        context.read<NotificationBloc>().add(MarkAllRead(userRole));
      }
    });

    return BlocBuilder<NotificationBloc, NotificationState>(
      builder: (context, state) {
        final notifications = state.notificationsForRole(userRole);

        return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: "Notifications"),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
            ),
            image: const DecorationImage(
              image: AssetImage("assets/background.png"),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: notifications.isEmpty
              ? Center(
                  child: Text(
                    "No notifications yet.",
                    style: TextStyle(
                      fontFamily: 'SFPro',
                      color: isDark ? Colors.white54 : Colors.black45,
                      fontSize: 15,
                    ),
                  ),
                )
              : ListView.builder(
                  padding: EdgeInsets.only(
                    top: kToolbarHeight + 48,
                    left: 24,
                    right: 24,
                    bottom: 24,
                  ),
                  itemCount: notifications.length,
                  itemBuilder: (context, index) {
                    final n = notifications[index];
                    return _NotificationCard(
                      notification: n,
                      timeAgo: _timeAgo(n.timestamp),
                    );
                  },
                ),
        ),
      ),
    );
      },
    );
  }
}

class _NotificationCard extends StatefulWidget {
  final AppNotification notification;
  final String timeAgo;

  const _NotificationCard({
    required this.notification,
    required this.timeAgo,
  });

  @override
  State<_NotificationCard> createState() => _NotificationCardState();
}

class _NotificationCardState extends State<_NotificationCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final subtitleColor = isDark ? Colors.white60 : Colors.black54;

    final n = widget.notification;
    final hasMessage = n.message.isNotEmpty;

    return GestureDetector(
      onTap: hasMessage ? () => setState(() => _expanded = !_expanded) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: n.isRead
              ? cardBg
              : (isDark ? const Color(0xFF1F4535) : Colors.green.shade50),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.06),
              blurRadius: 4,
            )
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    backgroundColor: n.color.withValues(alpha: 0.2),
                    radius: 22,
                    child: Icon(n.icon, color: n.color, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                n.title,
                                style: TextStyle(
                                  fontFamily: 'SFPro',
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                  color: textColor,
                                ),
                              ),
                            ),
                            Text(
                              widget.timeAgo,
                              style: TextStyle(
                                fontFamily: 'SFPro',
                                fontSize: 11,
                                color: subtitleColor,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          n.subtitle,
                          style: TextStyle(
                            fontFamily: 'SFPro',
                            fontSize: 13,
                            color: subtitleColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (!n.isRead)
                    Container(
                      width: 10,
                      height: 10,
                      margin: const EdgeInsets.only(top: 4),
                      decoration: const BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                      ),
                    )
                  else if (hasMessage)
                    Icon(
                      _expanded
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,
                      size: 18,
                      color: subtitleColor,
                    ),
                ],
              ),
              if (_expanded && hasMessage) ...[
                const SizedBox(height: 10),
                Divider(
                  height: 1,
                  color: isDark ? Colors.white12 : Colors.grey.shade200,
                ),
                const SizedBox(height: 10),
                Text(
                  n.message,
                  style: TextStyle(
                    fontFamily: 'SFPro',
                    fontSize: 13,
                    color: subtitleColor,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
