import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '../core/design_tokens.dart';

// ─────────────────────────────────────────────
// Notification Model
// ─────────────────────────────────────────────

class AppNotification extends Equatable {
  final String id;
  final String title;
  final String subtitle;
  final String message;
  final IconData icon;
  final Color color;
  final DateTime timestamp;
  final List<String> visibleToRoles;
  final bool isRead;

  AppNotification({
    required this.id,
    required this.title,
    required this.subtitle,
    this.message = "",
    required this.icon,
    required this.color,
    required this.visibleToRoles,
    this.isRead = false,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  AppNotification copyWith({bool? isRead}) {
    return AppNotification(
      id: id,
      title: title,
      subtitle: subtitle,
      message: message,
      icon: icon,
      color: color,
      timestamp: timestamp,
      visibleToRoles: visibleToRoles,
      isRead: isRead ?? this.isRead,
    );
  }

  @override
  List<Object?> get props => [
    id,
    title,
    subtitle,
    message,
    icon,
    color,
    timestamp,
    visibleToRoles,
    isRead,
  ];
}

// ─────────────────────────────────────────────
// Events
// ─────────────────────────────────────────────

abstract class NotificationEvent extends Equatable {
  const NotificationEvent();
  @override
  List<Object?> get props => [];
}

class AddNotification extends NotificationEvent {
  final AppNotification notification;
  const AddNotification(this.notification);
  @override
  List<Object?> get props => [notification];
}

class MarkAllRead extends NotificationEvent {
  final String role;
  const MarkAllRead(this.role);
  @override
  List<Object?> get props => [role];
}

class MarkRead extends NotificationEvent {
  final String id;
  const MarkRead(this.id);
  @override
  List<Object?> get props => [id];
}

// Factory Events

class NotifyEventAdded extends NotificationEvent {
  final String eventTitle;
  final String authorRole;
  const NotifyEventAdded(this.eventTitle, this.authorRole);
  @override
  List<Object?> get props => [eventTitle, authorRole];
}

class NotifyAnnouncementAdded extends NotificationEvent {
  final String authorName;
  final String authorRole;
  const NotifyAnnouncementAdded(this.authorName, this.authorRole);
  @override
  List<Object?> get props => [authorName, authorRole];
}

class NotifyTeamAdded extends NotificationEvent {
  final String teamName;
  const NotifyTeamAdded(this.teamName);
  @override
  List<Object?> get props => [teamName];
}

class NotifyGameSquadSelected extends NotificationEvent {}

class NotifyFitnessPdfUploaded extends NotificationEvent {
  final String playerName;
  const NotifyFitnessPdfUploaded(this.playerName);
  @override
  List<Object?> get props => [playerName];
}

class NotifyAnalysisPdfUploaded extends NotificationEvent {
  final String playerName;
  const NotifyAnalysisPdfUploaded(this.playerName);
  @override
  List<Object?> get props => [playerName];
}

class NotifyMedicalRecordUpdated extends NotificationEvent {
  final String playerName;
  const NotifyMedicalRecordUpdated(this.playerName);
  @override
  List<Object?> get props => [playerName];
}

class NotifyMedicalPdfUploaded extends NotificationEvent {
  final String playerName;
  const NotifyMedicalPdfUploaded(this.playerName);
  @override
  List<Object?> get props => [playerName];
}

class NotifyMemberAdded extends NotificationEvent {
  final String memberName;
  final String memberRole;
  const NotifyMemberAdded(this.memberName, this.memberRole);
  @override
  List<Object?> get props => [memberName, memberRole];
}

// ─────────────────────────────────────────────
// State
// ─────────────────────────────────────────────

class NotificationState extends Equatable {
  final List<AppNotification> notifications;

  const NotificationState({this.notifications = const []});

  NotificationState copyWith({List<AppNotification>? notifications}) {
    return NotificationState(
      notifications: notifications ?? this.notifications,
    );
  }

  List<AppNotification> notificationsForRole(String role) {
    return notifications
        .where(
          (n) =>
              n.visibleToRoles.contains(role) ||
              n.visibleToRoles.contains("All"),
        )
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  int unreadCountForRole(String role) {
    return notifications
        .where(
          (n) =>
              !n.isRead &&
              (n.visibleToRoles.contains(role) ||
                  n.visibleToRoles.contains("All")),
        )
        .length;
  }

  @override
  List<Object?> get props => [notifications];
}

// ─────────────────────────────────────────────
// BLoC
// ─────────────────────────────────────────────

class NotificationBloc extends Bloc<NotificationEvent, NotificationState> {
  NotificationBloc() : super(const NotificationState()) {
    on<AddNotification>((event, emit) {
      final updated = List<AppNotification>.from(state.notifications)
        ..insert(0, event.notification);
      emit(state.copyWith(notifications: updated));
    });

    on<MarkAllRead>((event, emit) {
      final updated = state.notifications.map((n) {
        if (n.visibleToRoles.contains(event.role) ||
            n.visibleToRoles.contains("All")) {
          return n.copyWith(isRead: true);
        }
        return n;
      }).toList();
      emit(state.copyWith(notifications: updated));
    });

    on<MarkRead>((event, emit) {
      final updated = state.notifications.map((n) {
        if (n.id == event.id) {
          return n.copyWith(isRead: true);
        }
        return n;
      }).toList();
      emit(state.copyWith(notifications: updated));
    });

    // Factory Helpers
    on<NotifyEventAdded>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "New Event Added",
            subtitle: event.eventTitle,
            message: "Added by ${event.authorRole}",
            icon: Icons.event,
            color: AppColors.primary,
            visibleToRoles: const ["All"],
          ),
        ),
      );
    });

    on<NotifyAnnouncementAdded>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "New Announcement",
            subtitle: "By ${event.authorName} (${event.authorRole})",
            message: "Check the home screen for details.",
            icon: Icons.announcement,
            color: Colors.orange,
            visibleToRoles: const ["All"],
          ),
        ),
      );
    });

    on<NotifyTeamAdded>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "New Team Created",
            subtitle: event.teamName,
            message: "A new team has been set up.",
            icon: Icons.group,
            color: Colors.blue,
            visibleToRoles: const ["All"],
          ),
        ),
      );
    });

    on<NotifyGameSquadSelected>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "Game Squad Selected",
            subtitle: "Coach selected the squad for the next match.",
            icon: Icons.groups,
            color: Colors.green,
            visibleToRoles: const ["Player", "Team Manager"],
          ),
        ),
      );
    });

    on<NotifyFitnessPdfUploaded>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "Fitness PDF Uploaded",
            subtitle: "For ${event.playerName}",
            message: "Uploaded by Fitness Coach. Please review.",
            icon: Icons.fitness_center,
            color: Colors.blue,
            visibleToRoles: const ["Coach", "Team Manager"],
          ),
        ),
      );
    });

    on<NotifyAnalysisPdfUploaded>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "Analysis PDF Uploaded",
            subtitle: "For ${event.playerName}",
            message: "Uploaded by Analyst. Please review.",
            icon: Icons.analytics,
            color: Colors.green,
            visibleToRoles: const ["Coach", "Team Manager"],
          ),
        ),
      );
    });

    on<NotifyMedicalRecordUpdated>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "Medical Record Updated",
            subtitle: "For ${event.playerName}",
            message: "Updated by Doctor.",
            icon: Icons.medical_services,
            color: Colors.red,
            visibleToRoles: const ["Coach", "Team Manager"],
          ),
        ),
      );
    });

    on<NotifyMedicalPdfUploaded>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "Medical PDF Uploaded",
            subtitle: "By ${event.playerName}",
            message: "Player uploaded their medical PDF. Please review.",
            icon: Icons.upload_file,
            color: Colors.red,
            visibleToRoles: const ["Doctor", "Coach", "Team Manager"],
          ),
        ),
      );
    });

    on<NotifyMemberAdded>((event, emit) {
      add(
        AddNotification(
          AppNotification(
            id: UniqueKey().toString(),
            title: "New Member Added",
            subtitle: "${event.memberName} — ${event.memberRole}",
            message: "Added by Team Manager.",
            icon: Icons.person_add,
            color: Colors.teal,
            visibleToRoles: const ["Coach", "Team Manager"],
          ),
        ),
      );
    });
  }
}
