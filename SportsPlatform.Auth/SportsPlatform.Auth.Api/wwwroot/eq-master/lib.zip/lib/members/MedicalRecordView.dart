import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import '../core/responsive_system.dart';
import '../team/team_bloc.dart';
import 'MemberModel.dart';

class MedicalRecordView extends StatefulWidget {
  final Member member;
  final int memberIndex;

  const MedicalRecordView({
    super.key,
    required this.member,
    required this.memberIndex,
  });

  @override
  State<MedicalRecordView> createState() => _MedicalRecordViewState();
}

class _MedicalRecordViewState extends State<MedicalRecordView> {
  late TextEditingController _recordController;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _recordController = TextEditingController(text: widget.member.medicalNotes);
  }

  @override
  void dispose() {
    _recordController.dispose();
    super.dispose();
  }

  void _saveRecord() {
    final updatedMember = Member(
      name: widget.member.name,
      role: widget.member.role,
      image: widget.member.image,
      age: widget.member.age,
      isInSquad: widget.member.isInSquad,
      fitnessPdfUrl: widget.member.fitnessPdfUrl,
      fitnessPdfName: widget.member.fitnessPdfName,
      analysisPdfUrl: widget.member.analysisPdfUrl,
      analysisPdfName: widget.member.analysisPdfName,
      medicalPdfUrl: widget.member.medicalPdfUrl,
      medicalPdfName: widget.member.medicalPdfName,
      videoUrl: widget.member.videoUrl,
      videoFileName: widget.member.videoFileName,
      medicalNotes: _recordController.text.trim(),
      injuryType: widget.member.injuryType,
      absencePeriod: widget.member.absencePeriod,
    );

    context.read<TeamBloc>().add(
      UpdateMemberData(
        widget.memberIndex,
        updatedMember,
        requiresStateEditPermission: true,
      ),
    );

    setState(() => _isEditing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Medical record saved successfully!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final subTextColor = isDark ? Colors.white54 : Colors.black54;

    return BlocConsumer<TeamBloc, TeamState>(
      listener: (context, state) {
        if (state.permissionError != null &&
            state.permissionError!.isNotEmpty) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.permissionError!)));
          context.read<TeamBloc>().add(ClearPermissionError());
        }
      },
      builder: (context, state) {
        final currentMember =
            (widget.memberIndex >= 0 &&
                widget.memberIndex < state.members.length)
            ? state.members[widget.memberIndex]
            : widget.member;

        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: const CustomAppBar(title: "Medical Record"),
          body: SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                      : [Colors.green, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.2,
                ),
              ),
              child: SingleChildScrollView(
                padding: ResponsiveSystem.pagePadding(context),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: MediaQuery.of(context).size.height,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: kToolbarHeight + 8),
                      // Member info card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: cardBg,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.05),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundImage: AssetImage(currentMember.image),
                              radius: 28,
                            ),
                            const SizedBox(width: 16),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  currentMember.name,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize:
                                        ResponsiveSystem.bodyFontSize(context) +
                                        2,
                                    color: textColor,
                                  ),
                                ),
                                Text(
                                  currentMember.role,
                                  style: TextStyle(
                                    fontSize: ResponsiveSystem.bodyFontSize(
                                      context,
                                    ),
                                    color: subTextColor,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: ResponsiveSystem.verticalGap(context)),

                      // Medical PDF
                      if (currentMember.medicalPdfUrl != null) ...[
                        Text(
                          "Medical PDF",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize:
                                ResponsiveSystem.bodyFontSize(context) + 1,
                            color: textColor,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.05),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.picture_as_pdf,
                                color: Colors.red,
                                size: 32,
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Text(
                                  currentMember.medicalPdfName ?? "Medical PDF",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: textColor,
                                  ),
                                ),
                              ),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  minimumSize: const Size(60, 32),
                                ),
                                onPressed: () {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        "Opening PDF... (Firebase not connected yet)",
                                      ),
                                    ),
                                  );
                                },
                                child: const Text(
                                  "open",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: ResponsiveSystem.verticalGap(context)),
                      ],

                      // Medical Notes header
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Medical Notes",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize:
                                  ResponsiveSystem.bodyFontSize(context) + 1,
                              color: textColor,
                            ),
                          ),
                          TextButton.icon(
                            onPressed: () =>
                                setState(() => _isEditing = !_isEditing),
                            icon: Icon(
                              _isEditing ? Icons.close : Icons.edit,
                              size: 16,
                              color: Colors.green,
                            ),
                            label: Text(
                              _isEditing ? "Cancel" : "Edit",
                              style: const TextStyle(color: Colors.green),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),

                      // Medical Notes card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: cardBg,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.05),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                        child: _isEditing
                            ? TextField(
                                controller: _recordController,
                                maxLines: 8,
                                style: TextStyle(
                                  color: textColor,
                                  fontSize: ResponsiveSystem.bodyFontSize(
                                    context,
                                  ),
                                ),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: "Enter medical notes here...",
                                  hintStyle: TextStyle(color: subTextColor),
                                ),
                              )
                            : Text(
                                _recordController.text.isEmpty
                                    ? "No medical notes yet."
                                    : _recordController.text,
                                style: TextStyle(
                                  fontSize: ResponsiveSystem.bodyFontSize(
                                    context,
                                  ),
                                  color: _recordController.text.isEmpty
                                      ? (isDark
                                            ? Colors.white24
                                            : Colors.black38)
                                      : (isDark
                                            ? Colors.white70
                                            : Colors.black87),
                                ),
                              ),
                      ),
                      SizedBox(height: ResponsiveSystem.verticalGap(context)),

                      // Save button
                      if (_isEditing)
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            minimumSize: Size(
                              double.infinity,
                              ResponsiveSystem.buttonHeight(context),
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: _saveRecord,
                          child: const Text(
                            "Save Record",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
