class Member {
  final String name;
  final String role;
  final String image;
  final int age;

  String? fitnessPdfUrl;
  String? fitnessPdfName;
  String? analysisPdfUrl;
  String? analysisPdfName;
  String? medicalPdfUrl;
  String? medicalPdfName;
  String? videoUrl;
  String? videoFileName;

  String medicalNotes;
  String injuryType;
  String absencePeriod;

  bool isInSquad;

  Member({
    required this.name,
    required this.role,
    this.image = 'assets/profile.png',
    this.age = 0,
    this.fitnessPdfUrl,
    this.fitnessPdfName,
    this.analysisPdfUrl,
    this.analysisPdfName,
    this.medicalPdfUrl,
    this.medicalPdfName,
    this.videoUrl,
    this.videoFileName,
    this.medicalNotes = '',
    this.injuryType = '',
    this.absencePeriod = '',
    this.isInSquad = false,
  });

  bool get isInjured =>
      medicalPdfUrl != null &&
      medicalPdfUrl!.isNotEmpty &&
      injuryType.isNotEmpty;
}
