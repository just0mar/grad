import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fl_chart/fl_chart.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../team/team_bloc.dart';
import 'MemberDetailModel.dart';
import 'MemberModel.dart';

class MemberDetailView extends StatelessWidget {
  final Member member;
  final int memberIndex;

  const MemberDetailView({
    super.key,
    required this.member,
    required this.memberIndex,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TeamBloc, TeamState>(
      builder: (context, state) {
        // Use the member from state to ensure it's reactive
        final currentMember = state.members.length > memberIndex
            ? state.members[memberIndex]
            : member;

        final isDark = Theme.of(context).brightness == Brightness.dark;
        final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
        final textColor = isDark ? Colors.white : Colors.black;
        final subTextColor = isDark ? Colors.white54 : Colors.black54;

        final List<FlSpot> threePointsData = const [
          FlSpot(0, 10),
          FlSpot(1, 15),
          FlSpot(2, 8),
          FlSpot(3, 20),
          FlSpot(4, 18),
          FlSpot(5, 25),
        ];
        final List<FlSpot> reboundsData = const [
          FlSpot(0, 5),
          FlSpot(1, 12),
          FlSpot(2, 10),
          FlSpot(3, 15),
          FlSpot(4, 22),
          FlSpot(5, 18),
        ];
        final List<FlSpot> blocksData = const [
          FlSpot(0, 2),
          FlSpot(1, 4),
          FlSpot(2, 3),
          FlSpot(3, 7),
          FlSpot(4, 5),
          FlSpot(5, 9),
        ];

        final List<PlayerStat> playerStats = [
          PlayerStat(title: "Points", lastGame: "24", cumulative: "18.5"),
          PlayerStat(title: "Rebounds", lastGame: "8", cumulative: "6.2"),
          PlayerStat(title: "Assists", lastGame: "12", cumulative: "9.1"),
          PlayerStat(title: "Steals", lastGame: "3", cumulative: "2.4"),
          PlayerStat(title: "Blocks", lastGame: "2", cumulative: "1.8"),
        ];

        final List<FitnessRecord> fitnessRecords = [
          FitnessRecord(label: "Speed (30m)", value: "3.92s"),
          FitnessRecord(label: "Vertical Jump", value: "72cm"),
          FitnessRecord(label: "Body Fat", value: "9.2%"),
          FitnessRecord(label: "Heart Rate (Rest)", value: "54 bpm"),
        ];

        final List<MedicalRecord> medicalRecords = [
          MedicalRecord(
            title: "Knee Ligament Strain",
            status: "Resolved",
            startDate: "2025-01-15",
            endDate: "2025-01-29",
          ),
          MedicalRecord(
            title: "Ankle Sprain",
            status: "Resolved",
            startDate: "2024-11-02",
            endDate: "2024-11-10",
          ),
        ];

        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: CustomAppBar(title: currentMember.name),
          body: SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                      : [Colors.green, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.2,
                ),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.only(
                  top: kToolbarHeight + 48,
                  left: 16,
                  right: 16,
                  bottom: 16,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildProfileCard(
                      currentMember,
                      cardBg,
                      textColor,
                      subTextColor,
                    ),
                    const SizedBox(height: 16),
                    if (currentMember.role.trim() == "Player") ...[
                      _buildMedicalStatusBanner(currentMember, isDark),
                      const SizedBox(height: 16),
                      _buildSection(
                        title: "Medical PDF",
                        icon: Icons.medical_services,
                        iconColor: Colors.red,
                        textColor: textColor,
                        child: currentMember.medicalPdfUrl != null
                            ? _buildPdfCard(
                                context,
                                currentMember.medicalPdfName ?? "Medical PDF",
                                cardBg,
                                textColor,
                              )
                            : _buildEmptyState(
                                "No medical PDF uploaded yet",
                                isDark,
                                cardBg,
                              ),
                      ),
                      const SizedBox(height: 16),
                      if (currentMember.medicalNotes.isNotEmpty) ...[
                        _buildSection(
                          title: "Medical Notes",
                          icon: Icons.notes,
                          iconColor: Colors.orange,
                          textColor: textColor,
                          child: _buildInfoCard(
                            currentMember.medicalNotes,
                            cardBg,
                            textColor,
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                      _buildSection(
                        title: "Fitness Plan PDF",
                        icon: Icons.fitness_center,
                        iconColor: Colors.blue,
                        textColor: textColor,
                        child: currentMember.fitnessPdfUrl != null
                            ? _buildPdfCard(
                                context,
                                currentMember.fitnessPdfName ?? "Fitness PDF",
                                cardBg,
                                textColor,
                              )
                            : _buildEmptyState(
                                "No fitness PDF uploaded yet",
                                isDark,
                                cardBg,
                              ),
                      ),
                      const SizedBox(height: 16),
                      _buildSection(
                        title: "Performance Analysis PDF",
                        icon: Icons.bar_chart,
                        iconColor: AppColors.primary,
                        textColor: textColor,
                        child: currentMember.analysisPdfUrl != null
                            ? _buildPdfCard(
                                context,
                                currentMember.analysisPdfName ?? "Analysis PDF",
                                cardBg,
                                textColor,
                              )
                            : _buildEmptyState(
                                "No analysis PDF uploaded yet",
                                isDark,
                                cardBg,
                              ),
                      ),
                      const SizedBox(height: 24),
                      _buildSectionHeader(
                        "PLAYER ANALYSIS",
                        Icons.bar_chart,
                        AppColors.primary,
                        textColor,
                      ),
                      const SizedBox(height: 12),
                      _buildAnalysisChart(
                        context,
                        isDark,
                        cardBg,
                        textColor,
                        subTextColor,
                        threePointsData,
                        reboundsData,
                        blocksData,
                      ),
                      const SizedBox(height: 16),
                      _buildAnalysisStatsTable(
                        isDark,
                        cardBg,
                        textColor,
                        subTextColor,
                        playerStats,
                      ),
                      const SizedBox(height: 24),
                      _buildSectionHeader(
                        "PLAYER FITNESS RECORDS",
                        Icons.fitness_center,
                        Colors.blue,
                        textColor,
                      ),
                      const SizedBox(height: 12),
                      _buildFitnessTable(
                        isDark,
                        cardBg,
                        textColor,
                        fitnessRecords,
                      ),
                      const SizedBox(height: 24),
                      _buildSectionHeader(
                        "PLAYER MEDICAL RECORDS",
                        Icons.healing,
                        Colors.red,
                        textColor,
                      ),
                      const SizedBox(height: 12),
                      _buildMedicalRecordsList(
                        isDark,
                        cardBg,
                        textColor,
                        subTextColor,
                        medicalRecords,
                      ),
                    ],
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAnalysisChart(
    BuildContext context,
    bool isDark,
    Color cardBg,
    Color textColor,
    Color subTextColor,
    List<FlSpot> d1,
    List<FlSpot> d2,
    List<FlSpot> d3,
  ) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 20, 20, 12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.25,
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: 35,
                gridData: const FlGridData(show: true, drawVerticalLine: false),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: d1,
                    isCurved: true,
                    color: Colors.blue,
                    barWidth: 2,
                    dotData: const FlDotData(show: false),
                  ),
                  LineChartBarData(
                    spots: d2,
                    isCurved: true,
                    color: Colors.green,
                    barWidth: 2,
                    dotData: const FlDotData(show: false),
                  ),
                  LineChartBarData(
                    spots: d3,
                    isCurved: true,
                    color: Colors.lime,
                    barWidth: 2,
                    dotData: const FlDotData(show: false),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnalysisStatsTable(
    bool isDark,
    Color cardBg,
    Color textColor,
    Color subTextColor,
    List<PlayerStat> stats,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: stats
            .map(
              (s) => ListTile(
                title: Text(s.title, style: TextStyle(color: textColor)),
                trailing: Text(
                  s.cumulative,
                  style: TextStyle(color: textColor),
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _buildFitnessTable(
    bool isDark,
    Color cardBg,
    Color textColor,
    List<FitnessRecord> records,
  ) {
    return Column(
      children: records
          .map(
            (r) => Card(
              color: cardBg,
              child: ListTile(
                title: Text(r.label, style: TextStyle(color: textColor)),
                trailing: Text(r.value, style: TextStyle(color: textColor)),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildMedicalRecordsList(
    bool isDark,
    Color cardBg,
    Color textColor,
    Color subTextColor,
    List<MedicalRecord> records,
  ) {
    return Column(
      children: records
          .map(
            (r) => Card(
              color: cardBg,
              child: ListTile(
                title: Text(r.title, style: TextStyle(color: textColor)),
                subtitle: Text(r.status, style: TextStyle(color: subTextColor)),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildProfileCard(
    Member member,
    Color cardBg,
    Color textColor,
    Color subTextColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(backgroundImage: AssetImage(member.image), radius: 36),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                member.name,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: textColor,
                ),
              ),
              Text(member.role, style: TextStyle(color: subTextColor)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMedicalStatusBanner(Member member, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: member.isInjured
            ? Colors.red.withValues(alpha: 0.1)
            : Colors.green.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        member.isInjured ? "Injured: ${member.injuryType}" : "Fit to play",
        style: TextStyle(color: member.isInjured ? Colors.red : Colors.green),
      ),
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required Color iconColor,
    required Color textColor,
    required Widget child,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: iconColor, size: 20),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(color: textColor, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 8),
        child,
      ],
    );
  }

  Widget _buildSectionHeader(
    String title,
    IconData icon,
    Color color,
    Color textColor,
  ) {
    return Row(
      children: [
        Icon(icon, color: color),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(color: textColor, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _buildPdfCard(
    BuildContext context,
    String name,
    Color cardBg,
    Color textColor,
  ) {
    return Card(
      color: cardBg,
      child: ListTile(
        leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
        title: Text(name, style: TextStyle(color: textColor)),
      ),
    );
  }

  Widget _buildInfoCard(String text, Color cardBg, Color textColor) {
    return Card(
      color: cardBg,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text(text, style: TextStyle(color: textColor)),
      ),
    );
  }

  Widget _buildEmptyState(String msg, bool isDark, Color cardBg) {
    return Text(msg, style: const TextStyle(color: Colors.grey));
  }
}
