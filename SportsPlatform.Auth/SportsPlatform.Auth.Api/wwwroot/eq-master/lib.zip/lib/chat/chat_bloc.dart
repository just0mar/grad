import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'ChatModel.dart';

// Events
abstract class ChatEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class SendMessage extends ChatEvent {
  final String text;
  SendMessage(this.text);

  @override
  List<Object?> get props => [text];
}

class ReceiveMessage extends ChatEvent {
  final String text;
  ReceiveMessage(this.text);

  @override
  List<Object?> get props => [text];
}

class DeleteMessage extends ChatEvent {
  final int index;
  DeleteMessage(this.index);

  @override
  List<Object?> get props => [index];
}

class EditMessage extends ChatEvent {
  final int index;
  final String newText;
  EditMessage(this.index, this.newText);

  @override
  List<Object?> get props => [index, newText];
}

class ClearMessages extends ChatEvent {}

// States
class ChatState extends Equatable {
  final List<ChatMessage> messages;
  final bool isLoading;

  const ChatState({
    this.messages = const [],
    this.isLoading = false,
  });

  ChatState copyWith({
    List<ChatMessage>? messages,
    bool? isLoading,
  }) {
    return ChatState(
      messages: messages ?? this.messages,
      isLoading: isLoading ?? this.isLoading,
    );
  }

  @override
  List<Object?> get props => [messages, isLoading];
}

// Bloc
class ChatBloc extends Bloc<ChatEvent, ChatState> {
  ChatBloc() : super(const ChatState()) {
    on<SendMessage>(_onSendMessage);
    on<ReceiveMessage>(_onReceiveMessage);
    on<DeleteMessage>(_onDeleteMessage);
    on<EditMessage>(_onEditMessage);
    on<ClearMessages>(_onClearMessages);
  }

  void _onSendMessage(SendMessage event, Emitter<ChatState> emit) {
    final text = event.text.trim();
    if (text.isEmpty) return;

    final updatedMessages = List<ChatMessage>.from(state.messages)
      ..add(ChatMessage(text: text, fromMe: true));
    
    emit(state.copyWith(messages: updatedMessages));

    // Simulate reply logic
    add(ReceiveMessage("Got it!"));
  }

  Future<void> _onReceiveMessage(ReceiveMessage event, Emitter<ChatState> emit) async {
    await Future.delayed(const Duration(seconds: 2));
    final updatedMessages = List<ChatMessage>.from(state.messages)
      ..add(ChatMessage(text: event.text, fromMe: false));
    emit(state.copyWith(messages: updatedMessages));
  }

  void _onDeleteMessage(DeleteMessage event, Emitter<ChatState> emit) {
    if (event.index < 0 || event.index >= state.messages.length) return;
    
    final updatedMessages = List<ChatMessage>.from(state.messages)
      ..removeAt(event.index);
    emit(state.copyWith(messages: updatedMessages));
  }

  void _onEditMessage(EditMessage event, Emitter<ChatState> emit) {
    if (event.index < 0 || event.index >= state.messages.length) return;

    final updatedMessages = List<ChatMessage>.from(state.messages);
    updatedMessages[event.index] = ChatMessage(
      text: event.newText.trim(),
      fromMe: updatedMessages[event.index].fromMe,
    );
    emit(state.copyWith(messages: updatedMessages));
  }

  void _onClearMessages(ClearMessages event, Emitter<ChatState> emit) {
    emit(state.copyWith(messages: []));
  }
}
