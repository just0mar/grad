class GameHistory {
  final String opponent;
  final String date;
  final int ourScore;
  final int theirScore;
  final List<Map<String, String>> stats;
  final List<String> pdfFiles;
  final List<Map<String, String>> videos; // {title, url}

  GameHistory({
    required this.opponent,
    required this.date,
    required this.ourScore,
    required this.theirScore,
    required this.stats,
    required this.pdfFiles,
    required this.videos,
  });
}