// import 'package:flutter/material.dart';
// import 'GameHistoryModel.dart';
//
// class GameDetailView extends StatelessWidget {
//   final GameHistory game;
//
//   const GameDetailView({super.key, required this.game});
//
//   @override
//   Widget build(BuildContext context) {
//     final bool won = game.ourScore > game.theirScore;
//
//     return Scaffold(
//       extendBodyBehindAppBar: true,
//       appBar: AppBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         scrolledUnderElevation: 0,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.black),
//           onPressed: () => Navigator.pop(context),
//         ),
//         title: Text(
//           "VS ${game.opponent.toUpperCase()}",
//           style: const TextStyle(
//             color: Colors.black,
//             fontWeight: FontWeight.bold,
//             fontSize: 18,
//             letterSpacing: 1.2,
//           ),
//         ),
//       ),
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Colors.green, Colors.white],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//           image: DecorationImage(
//             image: AssetImage("assets/background.png"),
//             fit: BoxFit.cover,
//             opacity: 0.2,
//           ),
//         ),
//         child: SafeArea(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(16),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const SizedBox(height: 8),
//
//                 // ✅ Score box — matches screenshot 2
//                 _buildScoreCard(won),
//                 const SizedBox(height: 24),
//
//                 // ✅ Game stats table
//                 _buildSectionTitle("GAME STATS"),
//                 const SizedBox(height: 10),
//                 _buildStatsTable(),
//                 const SizedBox(height: 24),
//
//                 // ✅ PDF files section
//                 _buildSectionTitle("GAME FILES"),
//                 const SizedBox(height: 10),
//                 _buildPdfSection(),
//                 const SizedBox(height: 24),
//
//                 // ✅ Game videos section
//                 _buildSectionTitle("GAME VIDEOS"),
//                 const SizedBox(height: 10),
//                 _buildVideosSection(),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildScoreCard(bool won) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         // Our score
//         Container(
//           width: 90,
//           height: 90,
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(16),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black.withValues(alpha: 0.08),
//                 blurRadius: 6,
//                 offset: const Offset(0, 3),
//               ),
//             ],
//           ),
//           child: Center(
//             child: Text(
//               "${game.ourScore}",
//               style: const TextStyle(
//                 fontSize: 36,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black,
//               ),
//             ),
//           ),
//         ),
//         const SizedBox(width: 16),
//         // Arrow icon
//         Icon(
//           won ? Icons.arrow_forward : Icons.arrow_back,
//           color: Colors.green,
//           size: 28,
//         ),
//         const SizedBox(width: 16),
//         // Their score
//         Container(
//           width: 90,
//           height: 90,
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(16),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black.withValues(alpha: 0.08),
//                 blurRadius: 6,
//                 offset: const Offset(0, 3),
//               ),
//             ],
//           ),
//           child: Center(
//             child: Text(
//               "${game.theirScore}",
//               style: const TextStyle(
//                 fontSize: 36,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black,
//               ),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget _buildSectionTitle(String title) {
//     return Text(
//       title,
//       style: const TextStyle(
//         fontWeight: FontWeight.bold,
//         fontSize: 16,
//         letterSpacing: 0.5,
//       ),
//     );
//   }
//
//   Widget _buildStatsTable() {
//     return Column(
//       children: game.stats.map((stat) {
//         return Container(
//           margin: const EdgeInsets.only(bottom: 8),
//           padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black.withValues(alpha: 0.05),
//                 blurRadius: 4,
//                 offset: const Offset(0, 2),
//               ),
//             ],
//           ),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(
//                 stat["title"] ?? "",
//                 style: const TextStyle(
//                   fontWeight: FontWeight.bold,
//                   fontSize: 14,
//                 ),
//               ),
//               Text(
//                 stat["value"] ?? "",
//                 style: const TextStyle(fontSize: 14),
//               ),
//             ],
//           ),
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildPdfSection() {
//     return Column(
//       children: game.pdfFiles.map((fileName) {
//         return Container(
//           margin: const EdgeInsets.only(bottom: 10),
//           padding: const EdgeInsets.all(12),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black.withValues(alpha: 0.05),
//                 blurRadius: 4,
//                 offset: const Offset(0, 2),
//               ),
//             ],
//           ),
//           child: Row(
//             children: [
//               const Icon(Icons.picture_as_pdf, color: Colors.red, size: 32),
//               const SizedBox(width: 12),
//               Expanded(
//                 child: Text(
//                   fileName,
//                   style: const TextStyle(
//                     fontWeight: FontWeight.w500,
//                     fontSize: 14,
//                   ),
//                 ),
//               ),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.green,
//                   minimumSize: const Size(60, 32),
//                   padding: const EdgeInsets.symmetric(horizontal: 12),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(20),
//                   ),
//                 ),
//                 onPressed: () {
//                   // TODO: open PDF
//                 },
//                 child: const Text("open", style: TextStyle(fontSize: 13)),
//               ),
//               const SizedBox(width: 8),
//               IconButton(
//                 icon: const Icon(Icons.download, color: Colors.black54),
//                 onPressed: () {
//                   // TODO: download PDF
//                 },
//               ),
//             ],
//           ),
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildVideosSection() {
//     return Column(
//       children: game.videos.map((video) {
//         return Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               video["title"] ?? "",
//               style: const TextStyle(
//                 fontSize: 15,
//                 fontWeight: FontWeight.w500,
//               ),
//             ),
//             const SizedBox(height: 8),
//             // ✅ Video thumbnail placeholder
//             Container(
//               height: 180,
//               decoration: BoxDecoration(
//                 color: Colors.black87,
//                 borderRadius: BorderRadius.circular(12),
//                 image: video["thumbnail"] != null
//                     ? DecorationImage(
//                   image: AssetImage(video["thumbnail"]!),
//                   fit: BoxFit.cover,
//                   opacity: 0.7,
//                 )
//                     : null,
//               ),
//               child: Center(
//                 child: Container(
//                   width: 52,
//                   height: 52,
//                   decoration: const BoxDecoration(
//                     color: Colors.white,
//                     shape: BoxShape.circle,
//                   ),
//                   child: const Icon(
//                     Icons.play_arrow,
//                     color: Colors.black,
//                     size: 32,
//                   ),
//                 ),
//               ),
//             ),
//             const SizedBox(height: 16),
//           ],
//         );
//       }).toList(),
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'GameHistoryModel.dart';
//
// class GameDetailHistoryView extends StatefulWidget {
//   final GameHistory game;
//   final String userRole; // ✅ passed from TeamStats
//
//   const GameDetailHistoryView({
//     super.key,
//     required this.game,
//     required this.userRole,
//   });
//
//   @override
//   State<GameDetailHistoryView> createState() => _GameDetailViewState();
// }
//
// class _GameDetailViewState extends State<GameDetailHistoryView> {
//   // ✅ Coach notes stored locally per game view session
//   final List<Map<String, String>> _notes = [];
//   final TextEditingController _noteController = TextEditingController();
//
//   @override
//   void dispose() {
//     _noteController.dispose();
//     super.dispose();
//   }
//
//   void _addNote() {
//     final text = _noteController.text.trim();
//     if (text.isEmpty) return;
//     setState(() {
//       _notes.add({
//         "name": "Ahmed Mahmoud", // TODO: replace with logged-in user name
//         "role": "Coach",
//         "text": text,
//       });
//       _noteController.clear();
//     });
//   }
//
//   void _openPdf(String fileName) {
//     // TODO: when Firebase is ready, fetch download URL and open with url_launcher:
//     // final url = await FirebaseStorage.instance.ref(fileName).getDownloadURL();
//     // await launchUrl(Uri.parse(url));
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text("Opening $fileName... (Firebase not connected yet)")),
//     );
//   }
//
//   void _downloadPdf(String fileName) {
//     // TODO: when Firebase is ready, download file to device:
//     // final url = await FirebaseStorage.instance.ref(fileName).getDownloadURL();
//     // download via http + path_provider
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text("Downloading $fileName... (Firebase not connected yet)")),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final bool won = widget.game.ourScore > widget.game.theirScore;
//     final bool isCoach = widget.userRole.trim() == "Coach";
//
//     return Scaffold(
//       extendBodyBehindAppBar: true,
//       appBar: AppBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         scrolledUnderElevation: 0,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.black),
//           onPressed: () => Navigator.pop(context),
//         ),
//         title: Text(
//           "VS ${widget.game.opponent.toUpperCase()}",
//           style: const TextStyle(
//             color: Colors.black,
//             fontWeight: FontWeight.bold,
//             fontSize: 18,
//             letterSpacing: 1.2,
//           ),
//         ),
//       ),
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Colors.green, Colors.white],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//           image: DecorationImage(
//             image: AssetImage("assets/background.png"),
//             fit: BoxFit.cover,
//             opacity: 0.2,
//           ),
//         ),
//         child: SafeArea(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(16),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const SizedBox(height: 8),
//                 _buildScoreCard(won),
//                 const SizedBox(height: 24),
//                 _buildSectionTitle("GAME STATS"),
//                 const SizedBox(height: 10),
//                 _buildStatsTable(),
//                 const SizedBox(height: 24),
//                 _buildSectionTitle("GAME FILES"),
//                 const SizedBox(height: 10),
//                 _buildPdfSection(),
//                 const SizedBox(height: 24),
//                 _buildSectionTitle("GAME VIDEOS"),
//                 const SizedBox(height: 10),
//                 _buildVideosSection(),
//                 const SizedBox(height: 24),
//
//                 // ✅ Coach notes section — visible to all, editable only by Coach
//                 _buildSectionTitle("COACH NOTES"),
//                 const SizedBox(height: 10),
//                 _buildCoachNotes(isCoach),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildScoreCard(bool won) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         _scoreBox("${widget.game.ourScore}"),
//         const SizedBox(width: 16),
//         Icon(
//           won ? Icons.arrow_forward : Icons.arrow_back,
//           color: Colors.green,
//           size: 28,
//         ),
//         const SizedBox(width: 16),
//         _scoreBox("${widget.game.theirScore}"),
//       ],
//     );
//   }
//
//   Widget _scoreBox(String score) {
//     return Container(
//       width: 90,
//       height: 90,
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [
//           BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 6, offset: const Offset(0, 3)),
//         ],
//       ),
//       child: Center(
//         child: Text(
//           score,
//           style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.black),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildSectionTitle(String title) {
//     return Text(
//       title,
//       style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 0.5),
//     );
//   }
//
//   Widget _buildStatsTable() {
//     return Column(
//       children: widget.game.stats.map((stat) {
//         return Container(
//           margin: const EdgeInsets.only(bottom: 8),
//           padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2))],
//           ),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(stat["title"] ?? "", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
//               Text(stat["value"] ?? "", style: const TextStyle(fontSize: 14)),
//             ],
//           ),
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildPdfSection() {
//     return Column(
//       children: widget.game.pdfFiles.map((fileName) {
//         return Container(
//           margin: const EdgeInsets.only(bottom: 10),
//           padding: const EdgeInsets.all(12),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2))],
//           ),
//           child: Row(
//             children: [
//               const Icon(Icons.picture_as_pdf, color: Colors.red, size: 32),
//               const SizedBox(width: 12),
//               Expanded(
//                 child: Text(fileName, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
//               ),
//               // ✅ Open button — will use Firebase URL when connected
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.green,
//                   minimumSize: const Size(60, 32),
//                   padding: const EdgeInsets.symmetric(horizontal: 12),
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//                 ),
//                 onPressed: () => _openPdf(fileName),
//                 child: const Text("open", style: TextStyle(fontSize: 13)),
//               ),
//               const SizedBox(width: 4),
//               // ✅ Download button — will use Firebase URL when connected
//               IconButton(
//                 icon: const Icon(Icons.download, color: Colors.black54),
//                 onPressed: () => _downloadPdf(fileName),
//               ),
//             ],
//           ),
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildVideosSection() {
//     return Column(
//       children: widget.game.videos.map((video) {
//         return Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(video["title"] ?? "", style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
//             const SizedBox(height: 8),
//             Container(
//               height: 180,
//               decoration: BoxDecoration(
//                 color: Colors.black87,
//                 borderRadius: BorderRadius.circular(12),
//                 image: video["thumbnail"] != null
//                     ? DecorationImage(
//                   image: AssetImage(video["thumbnail"]!),
//                   fit: BoxFit.cover,
//                   opacity: 0.7,
//                 )
//                     : null,
//               ),
//               child: Center(
//                 child: Container(
//                   width: 52,
//                   height: 52,
//                   decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
//                   child: const Icon(Icons.play_arrow, color: Colors.black, size: 32),
//                 ),
//               ),
//             ),
//             const SizedBox(height: 16),
//           ],
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildCoachNotes(bool isCoach) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         // ✅ Existing notes
//         if (_notes.isEmpty && !isCoach)
//           const Text("No coach notes yet.", style: TextStyle(color: Colors.black45)),
//
//         ..._notes.map((note) => Container(
//           margin: const EdgeInsets.only(bottom: 10),
//           padding: const EdgeInsets.all(14),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2))],
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               // ✅ Coach avatar + name row matching screenshot
//               Row(
//                 children: [
//                   const CircleAvatar(
//                     radius: 22,
//                     backgroundImage: AssetImage("assets/profile.png"),
//                   ),
//                   const SizedBox(width: 10),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(note["name"] ?? "",
//                           style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
//                       Text(note["role"] ?? "",
//                           style: const TextStyle(color: Colors.black54, fontSize: 13)),
//                     ],
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 10),
//               Text(note["text"] ?? "", style: const TextStyle(fontSize: 14)),
//             ],
//           ),
//         )),
//
//         // ✅ Add note input — only visible to Coach role
//         if (isCoach) ...[
//           const SizedBox(height: 8),
//           TextField(
//             controller: _noteController,
//             maxLines: 3,
//             decoration: InputDecoration(
//               filled: true,
//               fillColor: Colors.white,
//               hintText: "Write a note...",
//               border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
//             ),
//           ),
//           const SizedBox(height: 8),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: Colors.green,
//                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                 minimumSize: const Size(double.infinity, 48),
//               ),
//               onPressed: _addNote,
//               child: const Text("Save Note"),
//             ),
//           ),
//         ],
//       ],
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import '../appbar/CustomAppBar.dart';
// import 'GameHistoryModel.dart';
//
// class GameDetailHistoryView extends StatefulWidget {
//   final GameHistory game;
//   final String userRole;
//
//   const GameDetailHistoryView({
//     super.key,
//     required this.game,
//     required this.userRole,
//   });
//
//   @override
//   State<GameDetailHistoryView> createState() => _GameDetailViewState();
// }
//
// class _GameDetailViewState extends State<GameDetailHistoryView> {
//   final List<Map<String, String>> _notes = [];
//   final TextEditingController _noteController = TextEditingController();
//
//   @override
//   void dispose() {
//     _noteController.dispose();
//     super.dispose();
//   }
//
//   void _addNote() {
//     final text = _noteController.text.trim();
//     if (text.isEmpty) return;
//     setState(() {
//       _notes.add({
//         "name": "Ahmed Mahmoud",
//         "role": "Coach",
//         "text": text,
//       });
//       _noteController.clear();
//     });
//   }
//
//   void _openPdf(String fileName) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text("Opening $fileName... (Firebase not connected yet)")),
//     );
//   }
//
//   void _downloadPdf(String fileName) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text("Downloading $fileName... (Firebase not connected yet)")),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final bool won = widget.game.ourScore > widget.game.theirScore;
//     final bool isCoach = widget.userRole.trim() == "Coach";
//
//     return Scaffold(
//       extendBodyBehindAppBar: true,
//       appBar: CustomAppBar(title: "VS ${widget.game.opponent.toUpperCase()}"),
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Colors.green, Colors.white],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//           image: DecorationImage(
//             image: AssetImage("assets/background.png"),
//             fit: BoxFit.cover,
//             opacity: 0.2,
//           ),
//         ),
//         child: SafeArea(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(16),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const SizedBox(height: 8),
//                 _buildScoreCard(won),
//                 const SizedBox(height: 24),
//                 _buildSectionTitle("GAME STATS"),
//                 const SizedBox(height: 10),
//                 _buildStatsTable(),
//                 const SizedBox(height: 24),
//                 _buildSectionTitle("GAME FILES"),
//                 const SizedBox(height: 10),
//                 _buildPdfSection(),
//                 const SizedBox(height: 24),
//                 _buildSectionTitle("GAME VIDEOS"),
//                 const SizedBox(height: 10),
//                 _buildVideosSection(),
//                 const SizedBox(height: 24),
//                 _buildSectionTitle("COACH NOTES"),
//                 const SizedBox(height: 10),
//                 _buildCoachNotes(isCoach),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildScoreCard(bool won) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         _scoreBox("${widget.game.ourScore}"),
//         const SizedBox(width: 16),
//         Icon(
//           won ? Icons.arrow_forward : Icons.arrow_back,
//           color: Colors.green,
//           size: 28,
//         ),
//         const SizedBox(width: 16),
//         _scoreBox("${widget.game.theirScore}"),
//       ],
//     );
//   }
//
//   Widget _scoreBox(String score) {
//     return Container(
//       width: 90,
//       height: 90,
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [
//           BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 6, offset: const Offset(0, 3)),
//         ],
//       ),
//       child: Center(
//         child: Text(
//           score,
//           style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.black),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildSectionTitle(String title) {
//     return Text(
//       title,
//       style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 0.5),
//     );
//   }
//
//   Widget _buildStatsTable() {
//     return Column(
//       children: widget.game.stats.map((stat) {
//         return Container(
//           margin: const EdgeInsets.only(bottom: 8),
//           padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2))],
//           ),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(stat["title"] ?? "", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
//               Text(stat["value"] ?? "", style: const TextStyle(fontSize: 14)),
//             ],
//           ),
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildPdfSection() {
//     return Column(
//       children: widget.game.pdfFiles.map((fileName) {
//         return Container(
//           margin: const EdgeInsets.only(bottom: 10),
//           padding: const EdgeInsets.all(12),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2))],
//           ),
//           child: Row(
//             children: [
//               const Icon(Icons.picture_as_pdf, color: Colors.red, size: 32),
//               const SizedBox(width: 12),
//               Expanded(
//                 child: Text(fileName, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
//               ),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.green,
//                   minimumSize: const Size(60, 32),
//                   padding: const EdgeInsets.symmetric(horizontal: 12),
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//                 ),
//                 onPressed: () => _openPdf(fileName),
//                 child: const Text("open", style: TextStyle(fontSize: 13)),
//               ),
//               const SizedBox(width: 4),
//               IconButton(
//                 icon: const Icon(Icons.download, color: Colors.black54),
//                 onPressed: () => _downloadPdf(fileName),
//               ),
//             ],
//           ),
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildVideosSection() {
//     return Column(
//       children: widget.game.videos.map((video) {
//         return Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(video["title"] ?? "", style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
//             const SizedBox(height: 8),
//             Container(
//               height: 180,
//               decoration: BoxDecoration(
//                 color: Colors.black87,
//                 borderRadius: BorderRadius.circular(12),
//                 image: video["thumbnail"] != null
//                     ? DecorationImage(
//                   image: AssetImage(video["thumbnail"]!),
//                   fit: BoxFit.cover,
//                   opacity: 0.7,
//                 )
//                     : null,
//               ),
//               child: Center(
//                 child: Container(
//                   width: 52,
//                   height: 52,
//                   decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
//                   child: const Icon(Icons.play_arrow, color: Colors.black, size: 32),
//                 ),
//               ),
//             ),
//             const SizedBox(height: 16),
//           ],
//         );
//       }).toList(),
//     );
//   }
//
//   Widget _buildCoachNotes(bool isCoach) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         if (_notes.isEmpty && !isCoach)
//           const Text("No coach notes yet.", style: TextStyle(color: Colors.black45)),
//
//         ..._notes.map((note) => Container(
//           margin: const EdgeInsets.only(bottom: 10),
//           padding: const EdgeInsets.all(14),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(12),
//             boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2))],
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   const CircleAvatar(
//                     radius: 22,
//                     backgroundImage: AssetImage("assets/profile.png"),
//                   ),
//                   const SizedBox(width: 10),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(note["name"] ?? "",
//                           style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
//                       Text(note["role"] ?? "",
//                           style: const TextStyle(color: Colors.black54, fontSize: 13)),
//                     ],
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 10),
//               Text(note["text"] ?? "", style: const TextStyle(fontSize: 14)),
//             ],
//           ),
//         )),
//
//         if (isCoach) ...[
//           const SizedBox(height: 8),
//           TextField(
//             controller: _noteController,
//             maxLines: 3,
//             decoration: InputDecoration(
//               filled: true,
//               fillColor: Colors.white,
//               hintText: "Write a note...",
//               border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
//             ),
//           ),
//           const SizedBox(height: 8),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: Colors.green,
//                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                 minimumSize: const Size(double.infinity, 48),
//               ),
//               onPressed: _addNote,
//               child: const Text("Save Note"),
//             ),
//           ),
//         ],
//       ],
//     );
//   }
// }

import 'package:flutter/material.dart';
import '../appbar/CustomAppBar.dart';
import 'GameHistoryModel.dart';

class GameDetailHistoryView extends StatefulWidget {
  final GameHistory game;
  final String userRole;

  const GameDetailHistoryView({
    super.key,
    required this.game,
    required this.userRole,
  });

  @override
  State<GameDetailHistoryView> createState() => _GameDetailViewState();
}

class _GameDetailViewState extends State<GameDetailHistoryView> {
  final List<Map<String, String>> _notes = [];
  final TextEditingController _noteController = TextEditingController();

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  void _addNote() {
    final text = _noteController.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _notes.add({"name": "Ahmed Mahmoud", "role": "Coach", "text": text});
      _noteController.clear();
    });
  }

  void _openPdf(String fileName) => ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Opening $fileName... (Firebase not connected yet)")));

  void _downloadPdf(String fileName) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text("Downloading $fileName... (Firebase not connected yet)")));

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bool won = widget.game.ourScore > widget.game.theirScore;
    final bool isCoach = widget.userRole.trim() == "Coach";
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final subtitleColor = isDark ? Colors.white54 : Colors.black54;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(title: "VS ${widget.game.opponent.toUpperCase()}"),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                : [Colors.green, Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          image: const DecorationImage(
            image: AssetImage("assets/background.png"),
            fit: BoxFit.cover,
            opacity: 0.2,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                _buildScoreCard(won, cardBg, textColor),
                const SizedBox(height: 24),
                _buildSectionTitle("GAME STATS", textColor),
                const SizedBox(height: 10),
                _buildStatsTable(cardBg, textColor),
                const SizedBox(height: 24),
                _buildSectionTitle("GAME FILES", textColor),
                const SizedBox(height: 10),
                _buildPdfSection(cardBg, textColor),
                const SizedBox(height: 24),
                _buildSectionTitle("GAME VIDEOS", textColor),
                const SizedBox(height: 10),
                _buildVideosSection(textColor),
                const SizedBox(height: 24),
                _buildSectionTitle("COACH NOTES", textColor),
                const SizedBox(height: 10),
                _buildCoachNotes(isCoach, isDark, cardBg, textColor, subtitleColor),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildScoreCard(bool won, Color cardBg, Color textColor) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _scoreBox("${widget.game.ourScore}", cardBg, textColor),
        const SizedBox(width: 16),
        Icon(won ? Icons.arrow_forward : Icons.arrow_back,
            color: Colors.green, size: 28),
        const SizedBox(width: 16),
        _scoreBox("${widget.game.theirScore}", cardBg, textColor),
      ],
    );
  }

  Widget _scoreBox(String score, Color cardBg, Color textColor) {
    return Container(
      width: 90,
      height: 90,
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 6,
              offset: const Offset(0, 3)),
        ],
      ),
      child: Center(
        child: Text(score,
            style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                color: textColor)),
      ),
    );
  }

  Widget _buildSectionTitle(String title, Color textColor) {
    return Text(title,
        style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            letterSpacing: 0.5,
            color: textColor));
  }

  Widget _buildStatsTable(Color cardBg, Color textColor) {
    return Column(
      children: widget.game.stats.map((stat) {
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2))
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(stat["title"] ?? "",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      color: textColor)),
              Text(stat["value"] ?? "",
                  style: TextStyle(fontSize: 14, color: textColor)),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildPdfSection(Color cardBg, Color textColor) {
    return Column(
      children: widget.game.pdfFiles.map((fileName) {
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2))
            ],
          ),
          child: Row(
            children: [
              const Icon(Icons.picture_as_pdf, color: Colors.red, size: 32),
              const SizedBox(width: 12),
              Expanded(
                child: Text(fileName,
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                        color: textColor)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  minimumSize: const Size(60, 32),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
                onPressed: () => _openPdf(fileName),
                child: const Text("open",
                    style: TextStyle(fontSize: 13, color: Colors.white)),
              ),
              const SizedBox(width: 4),
              IconButton(
                icon: Icon(Icons.download,
                    color: textColor.withValues(alpha: 0.5)),
                onPressed: () => _downloadPdf(fileName),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildVideosSection(Color textColor) {
    return Column(
      children: widget.game.videos.map((video) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(video["title"] ?? "",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: textColor)),
            const SizedBox(height: 8),
            Container(
              height: 180,
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
                image: video["thumbnail"] != null
                    ? DecorationImage(
                    image: AssetImage(video["thumbnail"]!),
                    fit: BoxFit.cover,
                    opacity: 0.7)
                    : null,
              ),
              child: Center(
                child: Container(
                  width: 52,
                  height: 52,
                  decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle),
                  child: const Icon(Icons.play_arrow,
                      color: Colors.black, size: 32),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildCoachNotes(bool isCoach, bool isDark, Color cardBg,
      Color textColor, Color subtitleColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_notes.isEmpty && !isCoach)
          Text("No coach notes yet.",
              style: TextStyle(color: subtitleColor)),

        ..._notes.map((note) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2))
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const CircleAvatar(
                    radius: 22,
                    backgroundImage: AssetImage("assets/profile.png"),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(note["name"] ?? "",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: textColor)),
                      Text(note["role"] ?? "",
                          style: TextStyle(
                              color: subtitleColor, fontSize: 13)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(note["text"] ?? "",
                  style: TextStyle(fontSize: 14, color: textColor)),
            ],
          ),
        )),

        if (isCoach) ...[
          const SizedBox(height: 8),
          TextField(
            controller: _noteController,
            maxLines: 3,
            style: TextStyle(color: textColor),
            decoration: InputDecoration(
              filled: true,
              fillColor: cardBg,
              hintText: "Write a note...",
              hintStyle: TextStyle(color: textColor.withValues(alpha: 0.4)),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                minimumSize: const Size(double.infinity, 48),
              ),
              onPressed: _addNote,
              child: const Text("Save Note",
                  style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ],
    );
  }
}
