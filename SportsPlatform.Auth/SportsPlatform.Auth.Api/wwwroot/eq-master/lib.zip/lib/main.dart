import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'core/preferences_service.dart';
import 'core/app_bloc.dart';
import 'team/team_bloc.dart'; // Added
import 'event/event_bloc.dart';
import 'notifications/notification_bloc.dart';
import 'auth/LoginView.dart';
import 'auth/SignUpView.dart';
import 'core/design_tokens.dart';
import 'core/responsive_system.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PreferencesService.init();

  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => AppBloc()..add(AppStarted())),
        BlocProvider(create: (context) => TeamBloc()..add(LoadTeamMembers())),
        BlocProvider(create: (context) => EventBloc()..add(LoadEvents())),
        BlocProvider(create: (context) => NotificationBloc()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static final GlobalKey<NavigatorState> _navigatorKey =
      GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AppBloc, AppState>(
      builder: (context, state) {
        return MaterialApp(
          navigatorKey: _navigatorKey,
          title: 'Equipex',
          debugShowCheckedModeBanner: false,
          theme: ThemeData.light().copyWith(
            colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
            primaryColor: AppColors.primary,
            textTheme: ThemeData.light().textTheme.apply(fontFamily: 'SFPro'),
            primaryTextTheme: ThemeData.light().primaryTextTheme.apply(
              fontFamily: 'SFPro',
            ),
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            colorScheme: ColorScheme.fromSeed(
              seedColor: AppColors.primary,
              brightness: Brightness.dark,
            ),
            fontFamily: 'SFPro',
            scaffoldBackgroundColor: Colors.black,
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.transparent,
              elevation: 0,
              iconTheme: IconThemeData(color: Colors.white),
              titleTextStyle: TextStyle(
                fontFamily: 'SFPro',
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            textTheme: const TextTheme(
              bodyMedium: TextStyle(fontFamily: 'SFPro', color: Colors.white),
              bodyLarge: TextStyle(fontFamily: 'SFPro', color: Colors.white),
            ),
          ),
          themeMode: state.themeMode,
          home: state.isInitialized
              ? const SplashView()
              : const SizedBox.shrink(),
        );
      },
    );
  }
}

class SplashView extends StatefulWidget {
  const SplashView({super.key});

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();

    Timer(const Duration(seconds: 4), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          settings: const RouteSettings(name: '/'),
          builder: (context) => const OnboardingView(),
        ),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double logoSize = MediaQuery.of(context).size.width * 0.8;
    if (logoSize > 630) logoSize = 630;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: isDark
                    ? [Colors.black87, Colors.black]
                    : [Colors.green, Colors.white],
              ),
              image: const DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
                opacity: 0.15,
              ),
            ),
          ),
          if (isDark) Container(color: Colors.black.withValues(alpha: 0.35)),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RotationTransition(
                  turns: _controller,
                  child: Image.asset(
                    'assets/logo.png',
                    width: logoSize,
                    height: logoSize,
                  ),
                ),
                Text(
                  'EQUIPEX',
                  style: TextStyle(
                    fontFamily: 'Facon',
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class OnboardingView extends StatefulWidget {
  final int initialPage;

  const OnboardingView({super.key, this.initialPage = 0});

  @override
  State<OnboardingView> createState() => _OnboardingViewState();
}

class _OnboardingViewState extends State<OnboardingView> {
  late PageController _pageController;
  late int _currentPage;

  @override
  void initState() {
    super.initState();
    _currentPage = widget.initialPage;
    _pageController = PageController(initialPage: widget.initialPage);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _goToLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        settings: const RouteSettings(name: '/'),
        builder: (_) => const LoginView(),
      ),
    );
  }

  void _goToPeak() {
    _pageController.animateToPage(
      2,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  void _goBack() {
    _pageController.previousPage(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: isDark
                    ? [Colors.black87, Colors.black]
                    : [Colors.green, Colors.white],
              ),
              image: const DecorationImage(
                image: AssetImage('assets/background.png'),
                fit: BoxFit.cover,
                opacity: 0.15,
              ),
            ),
          ),
          if (isDark) Container(color: Colors.black.withValues(alpha: 0.35)),
          PageView(
            controller: _pageController,
            onPageChanged: (index) => setState(() => _currentPage = index),
            children: [
              OnboardingPage(
                title: 'Unite Your Entire Squad',
                description:
                    'Seamlessly connect Coaches, Players, Doctors, and Analysts in one centralized hub.',
                imagePath: 'assets/unite.png',
                showNext: true,
                nextLabel: 'Next',
                onNext: () => _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                ),
                onSkip: _goToPeak,
                onBack: null,
                currentPage: _currentPage,
              ),
              OnboardingPage(
                title: 'Tactical Insights',
                description:
                    'Empower your analysts and coaches with deep insights and real-time report exchange.',
                imagePath: 'assets/tactical.png',
                showNext: true,
                nextLabel: 'Next',
                onNext: () => _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                ),
                onSkip: _goToPeak,
                onBack: _goBack,
                currentPage: _currentPage,
              ),
              OnboardingPage(
                title: 'Peak Player Condition',
                description:
                    'Keep your team game-ready with updated medical reports and fitness tracking.',
                imagePath: 'assets/peak.png',
                showNext: false,
                nextLabel: "Let's Start",
                onNext: _goToLogin,
                onSkip: null,
                onBack: _goBack,
                extraButtons: [
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 50),
                      side: const BorderSide(color: Colors.green),
                    ),
                    onPressed: () => Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        settings: const RouteSettings(name: '/'),
                        builder: (_) => const SignUpView(),
                      ),
                    ),
                    child: const Text('Create Account'),
                  ),
                ],
                currentPage: _currentPage,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class OnboardingPage extends StatelessWidget {
  final String title;
  final String description;
  final String imagePath;
  final VoidCallback onNext;
  final VoidCallback? onSkip;
  final VoidCallback? onBack;
  final List<Widget>? extraButtons;
  final String nextLabel;
  final bool showNext;
  final int currentPage;

  const OnboardingPage({
    super.key,
    required this.title,
    required this.description,
    required this.imagePath,
    required this.onNext,
    required this.onSkip,
    required this.onBack,
    this.extraButtons,
    this.nextLabel = 'Next',
    this.showNext = true,
    required this.currentPage,
  });

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return SafeArea(
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: isDark ? Colors.black.withValues(alpha: 0.7) : Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (onBack != null)
                      TextButton(
                        onPressed: onBack,
                        child: const Text(
                          'Back',
                          style: TextStyle(color: AppColors.primary),
                        ),
                      )
                    else
                      const SizedBox.shrink(),
                    if (onSkip != null)
                      TextButton(
                        onPressed: onSkip,
                        child: const Text(
                          'Skip',
                          style: TextStyle(color: AppColors.primary),
                        ),
                      )
                    else
                      const SizedBox.shrink(),
                  ],
                ),
                const SizedBox(height: 10),
                Image.asset(
                  imagePath,
                  height: ResponsiveSystem.height(context) * 0.3,
                ),
                const SizedBox(height: 20),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 16,
                    color: isDark ? Colors.white70 : Colors.black54,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 30),
                if (showNext)
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: const Size(double.infinity, 50),
                    ),
                    onPressed: onNext,
                    child: Text(nextLabel),
                  )
                else ...[
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: const Size(double.infinity, 50),
                    ),
                    onPressed: onNext,
                    child: Text(nextLabel),
                  ),
                  const SizedBox(height: 10),
                  ...?extraButtons,
                ],
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(3, (index) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: currentPage == index ? 20 : 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: isDark ? Colors.white70 : Colors.grey,
                        borderRadius: BorderRadius.circular(5),
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
