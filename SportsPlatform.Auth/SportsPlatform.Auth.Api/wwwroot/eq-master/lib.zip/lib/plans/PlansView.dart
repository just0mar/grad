import 'package:eqq/addplans/AddPlansView.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import 'PlansViewModel.dart';

class PlansView extends StatefulWidget {
  const PlansView({super.key});

  @override
  State<PlansView> createState() => _PlansViewState();
}

class _PlansViewState extends State<PlansView> {
  late final PlansViewModel _viewModel;

  @override
  void initState() {
    super.initState();
    _viewModel = PlansViewModel();
    _viewModel.addListener(_onViewModelChanged);
  }

  @override
  void dispose() {
    _viewModel.removeListener(_onViewModelChanged);
    super.dispose();
  }

  void _onViewModelChanged() {
    setState(() {});
  }

  void _openPdf(String pdfPath) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PdfViewerScreen(pdfPath: pdfPath)),
    );
  }

  void _deletePlan(
    int globalIndex,
    bool isDark,
    Color cardBg,
    Color textColor,
  ) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Confirm Delete",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.close, color: textColor),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                "Are you sure you want to remove plan?",
                style: TextStyle(fontSize: 16, color: textColor),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text("Cancel"),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                          color: isDark ? Colors.white54 : Colors.black,
                        ),
                        foregroundColor: Colors.red,
                      ),
                      onPressed: () {
                        _viewModel.removePlanAt(globalIndex);
                        Navigator.pop(context);
                      },
                      child: const Text("Yes remove"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onPlanAdded(Map<String, dynamic> newPlan) {
    _viewModel.addPlan(newPlan);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final filtered = _viewModel.filteredPlans;
    final selectedCategory = _viewModel.selectedCategory;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ── Category toggle + add button ──
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    backgroundColor: selectedCategory == "Offensive"
                        ? Colors.green
                        : isDark
                        ? const Color(0xFF1B3A2D)
                        : Colors.grey.shade300,
                    foregroundColor: selectedCategory == "Offensive"
                        ? Colors.white
                        : textColor,
                    textStyle: const TextStyle(fontSize: 13),
                  ),
                  onPressed: () => _viewModel.setCategory("Offensive"),
                  child: const Text("Offensive"),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    backgroundColor: selectedCategory == "Defensive"
                        ? Colors.green
                        : isDark
                        ? const Color(0xFF1B3A2D)
                        : Colors.grey.shade300,
                    foregroundColor: selectedCategory == "Defensive"
                        ? Colors.white
                        : textColor,
                    textStyle: const TextStyle(fontSize: 13),
                  ),
                  onPressed: () => _viewModel.setCategory("Defensive"),
                  child: const Text("Defensive"),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                  backgroundColor: Colors.blueGrey,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddPlanScreen(onPlanAdded: _onPlanAdded),
                    ),
                  );
                },
                child: const Icon(Icons.add, size: 20),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // ── Empty state ──
          if (filtered.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 40),
                child: Text(
                  "No ${selectedCategory.toLowerCase()} plans yet.\nTap + to add one.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: isDark ? Colors.white70 : Colors.black54,
                  ),
                ),
              ),
            ),

          // ── Plan cards ──
          for (int i = 0; i < filtered.length; i++)
            Builder(
              builder: (context) {
                final globalIndex = _viewModel.plans.indexOf(filtered[i]);
                return Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: isDark
                        ? cardBg
                        : Colors.white.withValues(alpha: 0.9),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            filtered[i]["title"],
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: textColor,
                            ),
                          ),
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(
                                  Icons.picture_as_pdf,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  final pdf = filtered[i]["pdfPath"];
                                  if (pdf == null || pdf.isEmpty) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                          "No PDF assigned to this plan",
                                        ),
                                      ),
                                    );
                                  } else {
                                    _openPdf(pdf);
                                  }
                                },
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.delete,
                                  color: isDark
                                      ? Colors.white54
                                      : Colors.black54,
                                ),
                                onPressed: () => _deletePlan(
                                  globalIndex,
                                  isDark,
                                  cardBg,
                                  textColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Image(
                        image: AssetImage(filtered[i]["image"]),
                        fit: BoxFit.contain,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        filtered[i]["description"],
                        style: TextStyle(fontSize: 16, color: textColor),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}

class PdfViewerScreen extends StatelessWidget {
  final String pdfPath;

  const PdfViewerScreen({super.key, required this.pdfPath});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF0A1F15) : Colors.white,
      appBar: AppBar(
        backgroundColor: isDark ? const Color(0xFF1B3A2D) : Colors.white,
        title: Text(
          "PDF Viewer",
          style: TextStyle(color: isDark ? Colors.white : Colors.black),
        ),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: isDark ? Colors.white : Colors.black,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SfPdfViewer.asset(pdfPath),
    );
  }
}
