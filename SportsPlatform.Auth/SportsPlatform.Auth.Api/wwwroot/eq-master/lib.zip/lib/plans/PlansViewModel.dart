import 'package:flutter/material.dart';

class PlansViewModel extends ChangeNotifier {
  String _selectedCategory = "Offensive";

  final List<Map<String, dynamic>> _plans = <Map<String, dynamic>>[
    <String, dynamic>{
      "title": "PLAN 1: Top",
      "category": "Offensive",
      "image": "assets/Plan1.png",
      "description":
          "The offensive sequence begins with the point guard passing ...",
      "pdfPath": "",
    },
    <String, dynamic>{
      "title": "PLAN 2",
      "category": "Offensive",
      "image": "assets/Plan2.png",
      "description":
          "The offensive sequence begins with the point guard passing ...",
      "pdfPath": "assets/Plan2.pdf",
    },
  ];

  String get selectedCategory => _selectedCategory;
  List<Map<String, dynamic>> get plans => _plans;

  List<Map<String, dynamic>> get filteredPlans {
    return _plans
        .where((Map<String, dynamic> p) => p["category"] == _selectedCategory)
        .toList();
  }

  void setCategory(String category) {
    if (_selectedCategory == category) return;
    _selectedCategory = category;
    notifyListeners();
  }

  void removePlanAt(int globalIndex) {
    _plans.removeAt(globalIndex);
    for (int i = 0; i < _plans.length; i++) {
      _plans[i]["title"] = "PLAN ${i + 1}";
    }
    notifyListeners();
  }

  void addPlan(Map<String, dynamic> newPlan) {
    final int number = _plans.length + 1;
    _plans.add(<String, dynamic>{
      "title": "PLAN $number",
      "category": newPlan["category"],
      "image": newPlan["image"] ?? "assets/Plan1.png",
      "description": newPlan["description"] ?? "",
      "pdfPath": newPlan["pdfPath"] ?? "",
      "videoPath": newPlan["videoPath"] ?? "",
    });
    _selectedCategory = newPlan["category"] as String;
    notifyListeners();
  }
}
