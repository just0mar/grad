import 'package:flutter/material.dart';
import '../auth/LoginView.dart';
import '../core/responsive_system.dart';

class PeakConditionView extends StatelessWidget {
  const PeakConditionView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox.expand(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.green,
                Colors.white,
              ],
            ),
            image: DecorationImage(
              image: AssetImage("assets/background.png"),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                // Back button at top left
                Align(
                  alignment: Alignment.topLeft,
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text(
                      "Back",
                      style: TextStyle(fontFamily: 'SFPro', color: Colors.black),
                    ),
                  ),
                ),

                const Spacer(),

                Image.asset("assets/peak.png", height: ResponsiveSystem.height(context) * 0.3),
                const SizedBox(height: 20),

                const Text(
                  "Peak Player Condition",
                  style: TextStyle(
                    fontFamily: 'Facon',
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    "Keep your team game-ready with updated medical reports and fitness tracking.",
                    style: TextStyle(fontFamily: 'SFPro'),
                    textAlign: TextAlign.center,
                  ),
                ),

                const Spacer(),

                // Let's Start button → navigates to LoginView
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const LoginView()),
                      );
                    },
                    child: const Text(
                      "Let's Start",
                      style: TextStyle(
                        fontFamily: 'SFPro',
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // Create Account button
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 50),
                      side: const BorderSide(color: Colors.black),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    onPressed: () {
                      // TODO: Navigate to Sign Up
                    },
                    child: const Text(
                      "Create Account",
                      style: TextStyle(
                        fontFamily: 'SFPro',
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
