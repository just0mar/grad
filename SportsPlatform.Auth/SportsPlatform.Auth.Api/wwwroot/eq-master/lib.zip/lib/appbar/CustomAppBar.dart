import 'package:flutter/material.dart';

import '../core/responsive_system.dart';
import '../notifications/NotificationsView.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBack;
  final bool? showBackButton;
  final List<Map<String, dynamic>>? plans;
  final String userRole;

  const CustomAppBar({
    super.key,
    required this.title,
    this.onBack,
    this.showBackButton,
    this.plans,
    this.userRole = '',
  });

  @override
  Widget build(BuildContext context) {
    final bool canGoBack =
        showBackButton ?? (onBack != null || Navigator.of(context).canPop());
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color iconColor = isDark ? Colors.white : Colors.black;
    final Color textColor = isDark ? Colors.white : Colors.black;

    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leading: canGoBack
          ? Padding(
              padding: const EdgeInsets.only(left: 8),
              child: IconButton(
                icon: Icon(Icons.arrow_back, color: iconColor),
                onPressed: onBack ?? () => Navigator.of(context).pop(),
              ),
            )
          : null,
      titleSpacing: 0,
      centerTitle: false,
      title: Padding(
        padding: EdgeInsets.only(left: canGoBack ? 16 : 24),
        child: Text(
          title.toUpperCase(),
          style: TextStyle(
            fontFamily: 'Facon',
            fontSize: ResponsiveSystem.titleFontSize(context),
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
            color: textColor,
          ),
        ),
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.search, color: iconColor),
          onPressed: () {
            // TODO: Implement search with BLoC
          },
        ),
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: IconButton(
            icon: Icon(Icons.notifications_none, color: iconColor),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => NotificationsView(userRole: userRole),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
