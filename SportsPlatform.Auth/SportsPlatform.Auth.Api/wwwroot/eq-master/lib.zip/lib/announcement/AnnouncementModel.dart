class Announcement {
  final String authorName;
  final String authorRole;
  final String authorImage;
  final String caption;
  final bool isEmergency;

  Announcement({
    required this.authorName,
    required this.authorRole,
    required this.authorImage,
    required this.caption,
    required this.isEmergency,
  });
}