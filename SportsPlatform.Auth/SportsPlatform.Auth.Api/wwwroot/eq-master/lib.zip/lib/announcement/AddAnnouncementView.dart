import 'package:flutter/material.dart';

import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../core/responsive_system.dart';
import '../core/responsive_widgets.dart';
import 'AnnouncementModel.dart';

class AddAnnouncementView extends StatefulWidget {
  final String authorName;
  final String authorRole;
  final String authorImage;

  const AddAnnouncementView({
    super.key,
    this.authorName = '',
    this.authorRole = '',
    this.authorImage = 'assets/profile.png',
  });

  @override
  State<AddAnnouncementView> createState() => _AddAnnouncementViewState();
}

class _AddAnnouncementViewState extends State<AddAnnouncementView> {
  final TextEditingController _captionController = TextEditingController();
  final TextEditingController _attachmentController = TextEditingController();

  bool _isEmergency = false;

  @override
  void dispose() {
    _captionController.dispose();
    _attachmentController.dispose();
    super.dispose();
  }

  bool get _isValid => _captionController.text.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final Color labelColor = isDark ? Colors.white70 : Colors.black54;
    final Color textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: 'Add Announcement'),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
            ),
            image: const DecorationImage(
              image: AssetImage('assets/background.png'),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  padding: ResponsiveSystem.pagePadding(context),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextField(
                          controller: _captionController,
                          onChanged: (_) => setState(() {}),
                          style: TextStyle(
                            fontFamily: 'SFPro',
                            color: textColor,
                          ),
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: fieldColor,
                            labelText: 'Announcement caption',
                            labelStyle: TextStyle(
                              fontFamily: 'SFPro',
                              color: labelColor,
                            ),
                            border: const OutlineInputBorder(
                              borderSide: BorderSide(color: AppColors.primary),
                              borderRadius: BorderRadius.all(
                                Radius.circular(30),
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: isDark
                                    ? Colors.white24
                                    : AppColors.primary,
                              ),
                              borderRadius: const BorderRadius.all(
                                Radius.circular(30),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: _attachmentController,
                          onChanged: (_) => setState(() {}),
                          style: TextStyle(
                            fontFamily: 'SFPro',
                            color: textColor,
                          ),
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: fieldColor,
                            labelText: 'Announcement attachment',
                            labelStyle: TextStyle(
                              fontFamily: 'SFPro',
                              color: labelColor,
                            ),
                            prefixIcon: const Icon(
                              Icons.attach_file,
                              color: AppColors.primary,
                            ),
                            border: const OutlineInputBorder(
                              borderSide: BorderSide(color: AppColors.primary),
                              borderRadius: BorderRadius.all(
                                Radius.circular(30),
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: isDark
                                    ? Colors.white24
                                    : AppColors.primary,
                              ),
                              borderRadius: const BorderRadius.all(
                                Radius.circular(30),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Checkbox(
                              value: _isEmergency,
                              activeColor: Colors.green,
                              checkColor: Colors.white,
                              side: BorderSide(
                                color: isDark ? Colors.white54 : Colors.black54,
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _isEmergency = value ?? false;
                                });
                              },
                            ),
                            Text(
                              'Emergency',
                              style: TextStyle(
                                fontFamily: 'SFPro',
                                color: textColor,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        ResponsivePrimaryButton(
                          context: context,
                          label: 'Add announcement',
                          onPressed: () {
                            if (!_isValid) {
                              return;
                            }
                            _showSuccessDialog(
                              context,
                              textColor: textColor,
                              fieldColor: fieldColor,
                              onConfirm: () {
                                final announcement = Announcement(
                                  authorName: widget.authorName,
                                  authorRole: widget.authorRole,
                                  authorImage: widget.authorImage,
                                  caption: _captionController.text.trim(),
                                  isEmergency: _isEmergency,
                                );
                                Navigator.pop(context);
                                Navigator.pop(context, announcement);
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  void _showSuccessDialog(
    BuildContext context, {
    required Color textColor,
    required Color fieldColor,
    required VoidCallback onConfirm,
  }) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        backgroundColor: fieldColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  icon: Icon(Icons.close, color: textColor),
                  onPressed: () => Navigator.pop(dialogContext),
                ),
              ),
              Text(
                'Announcement added successfully',
                style: TextStyle(
                  fontFamily: 'SFPro',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              ResponsivePrimaryButton(
                context: dialogContext,
                label: 'Ok',
                onPressed: onConfirm,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
