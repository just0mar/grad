// Port of the React web app's `roleAccess.js`.
//
// Backend role enum names (used internally in Dart code):
//   ClubManager, TeamManager, Coach, TeamAnalyst,
//   FitnessCoach, TeamDoctor, Player
//
// Display labels are returned by [roleLabel].

class RoleAccess {
  final bool isAdmin;
  final bool isManager;
  final bool isCoach;
  final bool isAnalyst;
  final bool isFitnessCoach;
  final bool isDoctor;
  final bool isPlayer;

  // Granular permissions
  final bool canManageTeam;
  final bool canManageEvents;
  final bool canManageAnnouncements;
  final bool canManageAttendance;
  final bool canEnterStats;
  final bool canWriteFitness;
  final bool canWriteMedical;
  final bool canViewPlans;
  final bool canViewStats;
  final bool canViewMedical;
  final bool canViewFitness;
  final bool canViewAllPlayerProfiles;

  const RoleAccess({
    this.isAdmin = false,
    this.isManager = false,
    this.isCoach = false,
    this.isAnalyst = false,
    this.isFitnessCoach = false,
    this.isDoctor = false,
    this.isPlayer = false,
    this.canManageTeam = false,
    this.canManageEvents = false,
    this.canManageAnnouncements = false,
    this.canManageAttendance = false,
    this.canEnterStats = false,
    this.canWriteFitness = false,
    this.canWriteMedical = false,
    this.canViewPlans = false,
    this.canViewStats = false,
    this.canViewMedical = false,
    this.canViewFitness = false,
    this.canViewAllPlayerProfiles = false,
  });
}

const _staffFull = ['ClubManager', 'TeamManager'];
const _staffReadAll = ['Coach', 'TeamAnalyst', 'FitnessCoach', 'TeamDoctor'];

bool _hasRole(List<String> roles, String role) => roles.contains(role);
bool _hasAny(List<String> roles, List<String> check) =>
    check.any((r) => roles.contains(r));

/// Compute granular permissions from the user's role list.
RoleAccess getRoleAccess(List<String> roles, {bool isAdmin = false}) {
  final isManager = isAdmin || _hasAny(roles, _staffFull);
  final isCoach = _hasRole(roles, 'Coach');
  final isAnalyst = _hasRole(roles, 'TeamAnalyst');
  final isFitnessCoach = _hasRole(roles, 'FitnessCoach');
  final isDoctor = _hasRole(roles, 'TeamDoctor');
  final isPlayer =
      _hasRole(roles, 'Player') && !isManager && !_hasAny(roles, _staffReadAll);

  return RoleAccess(
    isAdmin: isAdmin,
    isManager: isManager,
    isCoach: isCoach,
    isAnalyst: isAnalyst,
    isFitnessCoach: isFitnessCoach,
    isDoctor: isDoctor,
    isPlayer: isPlayer,
    canManageTeam: isManager,
    canManageEvents: isManager,
    canManageAnnouncements: isManager,
    canManageAttendance: isManager,
    canEnterStats: isAnalyst,
    canWriteFitness: isAdmin || isFitnessCoach,
    canWriteMedical: isAdmin || isDoctor,
    canViewPlans: true, // all roles; coach controls visibility on creation
    canViewStats: true,
    canViewMedical:
        isManager || isCoach || isFitnessCoach || isDoctor || isPlayer,
    canViewFitness:
        isManager || isCoach || isFitnessCoach || isDoctor || isPlayer,
    canViewAllPlayerProfiles:
        isManager || isCoach || isAnalyst || isFitnessCoach || isDoctor,
  );
}

/// Map a backend role enum name to a human-readable label.
String roleLabel(String role) {
  const labels = {
    'ClubManager': 'Club Manager',
    'TeamManager': 'Team Manager',
    'Coach': 'Coach',
    'FitnessCoach': 'Fitness Coach',
    'TeamAnalyst': 'Analyst',
    'TeamDoctor': 'Doctor',
    'Player': 'Player',
    'Admin': 'Admin',
  };
  return labels[role] ?? role;
}

/// Determine which tab index to land on after login.
///
/// 0=Home, 1=Events, 2=Team, 3=Profile, 4=Messages
int getRoleLandingTab(RoleAccess access, {bool hasTeam = false, bool hasClub = false}) {
  if (!hasTeam && !hasClub) {
    // No team/club — go to Home (where they can create or join)
    return 0;
  }

  if (access.isAnalyst) return 2; // Team tab → Stats sub-tab
  if (access.isCoach) return 2; // Team tab → Plans sub-tab
  if (access.isFitnessCoach) return 2;
  if (access.isDoctor) return 2;
  return 2; // Team tab by default when a team exists
}
