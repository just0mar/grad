import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF4A647A);
  static const Color primaryDark = Color(0xFF344A5D);
  static const Color primaryLight = Color(0xFFD8E2EA);
  static const Color surfaceDark = Color(0xFF1B3A2D);
  static const Color success = Color(0xFF2E7D32);
}

class AppSpacing {
  static const double xs = 8;
  static const double sm = 16;
  static const double md = 24;
  static const double lg = 32;
  static const double xl = 40;
  static const double xxl = 48;
}
