import 'package:shared_preferences/shared_preferences.dart';

class PreferencesService {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Theme preference
  static const String _themeKey = 'theme_mode';
  
  static Future<void> setThemeMode(String mode) async {
    await _prefs.setString(_themeKey, mode);
  }

  static String getThemeMode() {
    return _prefs.getString(_themeKey) ?? 'system';
  }

  // Auth/Session preference (example)
  static const String _isLoggedInKey = 'is_logged_in';
  
  static Future<void> setLoggedIn(bool value) async {
    await _prefs.setBool(_isLoggedInKey, value);
  }

  static bool isLoggedIn() {
    return _prefs.getBool(_isLoggedInKey) ?? false;
  }

  // Generic methods
  static Future<void> clear() async {
    await _prefs.clear();
  }
}
