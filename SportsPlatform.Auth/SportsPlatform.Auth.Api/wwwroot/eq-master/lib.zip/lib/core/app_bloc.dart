import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'preferences_service.dart';

// Events
abstract class AppEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class ThemeChanged extends AppEvent {
  final ThemeMode themeMode;
  ThemeChanged(this.themeMode);
  @override
  List<Object?> get props => [themeMode];
}

class AppStarted extends AppEvent {}

// State
class AppState extends Equatable {
  final ThemeMode themeMode;
  final bool isInitialized;

  const AppState({
    this.themeMode = ThemeMode.system,
    this.isInitialized = false,
  });

  AppState copyWith({
    ThemeMode? themeMode,
    bool? isInitialized,
  }) {
    return AppState(
      themeMode: themeMode ?? this.themeMode,
      isInitialized: isInitialized ?? this.isInitialized,
    );
  }

  @override
  List<Object?> get props => [themeMode, isInitialized];
}

// Bloc
class AppBloc extends Bloc<AppEvent, AppState> {
  AppBloc() : super(const AppState()) {
    on<AppStarted>(_onAppStarted);
    on<ThemeChanged>(_onThemeChanged);
  }

  Future<void> _onAppStarted(AppStarted event, Emitter<AppState> emit) async {
    final themeStr = PreferencesService.getThemeMode();
    ThemeMode mode;
    switch (themeStr) {
      case 'light':
        mode = ThemeMode.light;
        break;
      case 'dark':
        mode = ThemeMode.dark;
        break;
      default:
        mode = ThemeMode.system;
    }
    emit(state.copyWith(themeMode: mode, isInitialized: true));
  }

  Future<void> _onThemeChanged(ThemeChanged event, Emitter<AppState> emit) async {
    final modeStr = event.themeMode.toString().split('.').last;
    await PreferencesService.setThemeMode(modeStr);
    emit(state.copyWith(themeMode: event.themeMode));
  }
}
