import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'secure_storage_service.dart';

/// Centralized HTTP client with JWT Bearer injection and 401 refresh.
class ApiClient {
  // For Android emulator use 10.0.2.2 to reach host localhost.
  // For iOS simulator use 127.0.0.1.
  // For real device use the machine's LAN IP (currently WiFi).
  static String _baseUrl = 'http://192.168.1.4:5122';

  static String get baseUrl => _baseUrl;

  /// Call once at startup if you need a different URL.
  static void configure({required String baseUrl}) {
    _baseUrl = baseUrl;
  }

  // ── Helpers ──

  static Map<String, String> _jsonHeaders([String? token]) => {
        HttpHeaders.contentTypeHeader: 'application/json',
        if (token != null) HttpHeaders.authorizationHeader: 'Bearer $token',
      };

  static Future<String?> _token() => SecureStorageService.getAccessToken();

  // ── Core request with auto-refresh ──

  static Future<http.Response> _request(
    String method,
    String path, {
    Object? body,
    Map<String, String>? queryParams,
    Map<String, String>? extraHeaders,
    bool isRetry = false,
  }) async {
    final token = await _token();
    final uri = Uri.parse('$_baseUrl$path').replace(
      queryParameters:
          queryParams != null && queryParams.isNotEmpty ? queryParams : null,
    );

    final headers = {
      ..._jsonHeaders(token),
      if (extraHeaders != null) ...extraHeaders,
    };

    final String? encodedBody =
        body != null ? jsonEncode(body) : null;

    http.Response response;
    switch (method) {
      case 'GET':
        response = await http.get(uri, headers: headers);
        break;
      case 'POST':
        response = await http.post(uri, headers: headers, body: encodedBody);
        break;
      case 'PUT':
        response = await http.put(uri, headers: headers, body: encodedBody);
        break;
      case 'DELETE':
        response = await http.delete(uri, headers: headers, body: encodedBody);
        break;
      default:
        throw UnsupportedError('HTTP method $method not supported');
    }

    // Handle 401 — attempt token refresh once.
    if (response.statusCode == 401 && !isRetry) {
      final refreshed = await _tryRefresh();
      if (refreshed) {
        return _request(method, path,
            body: body,
            queryParams: queryParams,
            extraHeaders: extraHeaders,
            isRetry: true);
      }
      // Refresh failed — caller should handle 401 (e.g. redirect to login).
    }

    return response;
  }

  static Future<bool> _tryRefresh() async {
    final refreshToken = await SecureStorageService.getRefreshToken();
    if (refreshToken == null) return false;

    try {
      final uri = Uri.parse('$_baseUrl/auth/refresh');
      final response = await http.post(
        uri,
        headers: _jsonHeaders(),
        body: jsonEncode({'refreshToken': refreshToken}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final newAccess = data['accessToken'] as String?;
        if (newAccess != null) {
          await SecureStorageService.saveTokens(
            accessToken: newAccess,
            refreshToken: data['refreshToken'] as String?,
          );
          return true;
        }
      }
    } catch (_) {
      // Refresh failed
    }

    // Clear stale tokens so the app redirects to login.
    await SecureStorageService.clearTokens();
    return false;
  }

  // ── Public API ──

  static Future<http.Response> get(String path,
          {Map<String, String>? queryParams}) =>
      _request('GET', path, queryParams: queryParams);

  static Future<http.Response> post(String path, {Object? body}) =>
      _request('POST', path, body: body);

  static Future<http.Response> put(String path, {Object? body}) =>
      _request('PUT', path, body: body);

  static Future<http.Response> delete(String path, {Object? body}) =>
      _request('DELETE', path, body: body);

  // ── Response helpers ──

  /// Decode a successful JSON response body. Throws [ApiException] on error.
  static Map<String, dynamic> decodeResponse(http.Response response) {
    final body = response.body.isNotEmpty
        ? jsonDecode(response.body)
        : <String, dynamic>{};

    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (body is Map<String, dynamic>) return body;
      return {'data': body};
    }

    final message = body is Map ? (body['message'] ?? body['error'] ?? 'Unknown error') : 'Request failed';
    throw ApiException(
      statusCode: response.statusCode,
      message: message.toString(),
    );
  }

  static List<dynamic> decodeListResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      final body = jsonDecode(response.body);
      if (body is List) return body;
      return [];
    }

    final body = response.body.isNotEmpty
        ? jsonDecode(response.body)
        : <String, dynamic>{};
    final message = body is Map ? (body['message'] ?? 'Unknown error') : 'Request failed';
    throw ApiException(
      statusCode: response.statusCode,
      message: message.toString(),
    );
  }
}

class ApiException implements Exception {
  final int statusCode;
  final String message;

  const ApiException({required this.statusCode, required this.message});

  bool get isUnauthorized => statusCode == 401;
  bool get isForbidden => statusCode == 403;
  bool get isNotFound => statusCode == 404;

  @override
  String toString() => 'ApiException($statusCode): $message';
}
