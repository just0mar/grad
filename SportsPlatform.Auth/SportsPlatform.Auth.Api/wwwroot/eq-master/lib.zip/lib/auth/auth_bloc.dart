import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../core/preferences_service.dart';

// Events
abstract class AuthEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoginRequested extends AuthEvent {
  final String email;
  final String password;
  final String role;
  LoginRequested({
    required this.email,
    required this.password,
    required this.role,
  });

  @override
  List<Object?> get props => [email, password, role];
}

class SignUpRequested extends AuthEvent {
  final String email;
  final String name;
  final String password;
  final String role;
  final String age;

  SignUpRequested({
    required this.email,
    required this.name,
    required this.password,
    required this.role,
    required this.age,
  });

  @override
  List<Object?> get props => [email, name, password, role, age];
}

class LogoutRequested extends AuthEvent {}

// States
abstract class AuthState extends Equatable {
  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class Authenticated extends AuthState {
  final String role;
  final String userId;
  Authenticated({required this.role, required this.userId});
  @override
  List<Object?> get props => [role, userId];
}

class AuthError extends AuthState {
  final String message;
  AuthError(this.message);
  @override
  List<Object?> get props => [message];
}

// Bloc
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc() : super(AuthInitial()) {
    on<LoginRequested>(_onLoginRequested);
    on<SignUpRequested>(_onSignUpRequested);
    on<LogoutRequested>(_onLogoutRequested);
  }

  Future<void> _onLoginRequested(
    LoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      // Simulate network request
      await Future.delayed(const Duration(seconds: 1));
      if (event.email.isNotEmpty && event.password.isNotEmpty) {
        await PreferencesService.setLoggedIn(true);
        emit(
          Authenticated(
            role: event.role,
            userId: event.email.trim().toLowerCase(),
          ),
        );
      } else {
        emit(AuthError("Invalid credentials"));
      }
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  Future<void> _onSignUpRequested(
    SignUpRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      await Future.delayed(const Duration(seconds: 1));
      // In a real app, you'd save user data to a database
      await PreferencesService.setLoggedIn(true);
      emit(
        Authenticated(
          role: event.role,
          userId: event.email.trim().toLowerCase(),
        ),
      );
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  Future<void> _onLogoutRequested(
    LogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    await PreferencesService.setLoggedIn(false);
    emit(AuthInitial());
  }
}
