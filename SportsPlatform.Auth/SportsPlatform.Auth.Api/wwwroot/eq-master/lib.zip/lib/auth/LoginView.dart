import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../navigation/MainNavigation.dart';
import 'SignUpView.dart';
import '../main.dart' show OnboardingView;
import '../core/design_tokens.dart';
import '../core/responsive_system.dart';
import 'auth_bloc.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _selectedRole = "Team Manager";

  final List<String> _roles = [
    "Team Manager",
    "Coach",
    "Fitness Coach",
    "Doctor",
    "Player",
    "Analyst",
  ];

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _goBackToPeak() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const OnboardingView(initialPage: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final padding = ResponsiveSystem.pagePadding(context);

    return BlocProvider(
      create: (context) => AuthBloc(),
      child: BlocListener<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is Authenticated) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                settings: const RouteSettings(name: '/'),
                builder: (_) =>
                    MainNavigation(userRole: state.role, userId: state.userId),
              ),
              (route) => false,
            );
          } else if (state is AuthError) {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(SnackBar(content: Text(state.message)));
          }
        },
        child: Scaffold(
          extendBodyBehindAppBar: true,
          body: Builder(
            builder: (context) {
              return SizedBox.expand(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: isDark
                          ? [Colors.black, Colors.black87]
                          : [Colors.green, Colors.white],
                    ),
                    image: const DecorationImage(
                      image: AssetImage("assets/background.png"),
                      fit: BoxFit.cover,
                      opacity: 0.15,
                    ),
                  ),
                  child: SafeArea(
                    child: SingleChildScrollView(
                      padding: padding,
                      child: Center(
                        child: Container(
                          constraints: BoxConstraints(
                            maxWidth: ResponsiveSystem.mobileMaxWidth,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(
                                      Icons.arrow_back,
                                      color: isDark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                    onPressed: _goBackToPeak,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    "LOG IN",
                                    style: TextStyle(
                                      fontFamily: 'Facon',
                                      fontSize: ResponsiveSystem.titleFontSize(
                                        context,
                                      ),
                                      fontWeight: FontWeight.bold,
                                      color: isDark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: ResponsiveSystem.verticalGap(context),
                              ),
                              TextField(
                                controller: _emailController,
                                decoration: _buildInputDecoration(
                                  "Email/ Phone number",
                                ),
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: _passwordController,
                                obscureText: true,
                                decoration: _buildInputDecoration("Password"),
                              ),
                              const SizedBox(height: 16),
                              DropdownButtonFormField<String>(
                                initialValue: _selectedRole,
                                decoration: _buildInputDecoration(
                                  "Select Role",
                                ),
                                items: _roles
                                    .map(
                                      (role) => DropdownMenuItem(
                                        value: role,
                                        child: Text(role),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    setState(() => _selectedRole = value);
                                  }
                                },
                              ),
                              Align(
                                alignment: Alignment.centerRight,
                                child: TextButton(
                                  style: TextButton.styleFrom(
                                    foregroundColor: isDark
                                        ? Colors.white70
                                        : Colors.black,
                                  ),
                                  onPressed: () {},
                                  child: const Text("Forgot password"),
                                ),
                              ),
                              const SizedBox(height: 20),
                              BlocBuilder<AuthBloc, AuthState>(
                                builder: (context, state) {
                                  return ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppColors.primary,
                                      minimumSize: const Size(
                                        double.infinity,
                                        48,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                    ),
                                    onPressed: state is AuthLoading
                                        ? null
                                        : () {
                                            context.read<AuthBloc>().add(
                                              LoginRequested(
                                                email: _emailController.text,
                                                password:
                                                    _passwordController.text,
                                                role: _selectedRole,
                                              ),
                                            );
                                          },
                                    child: state is AuthLoading
                                        ? const CircularProgressIndicator(
                                            color: Colors.white,
                                          )
                                        : const Text(
                                            "Log in",
                                            style: TextStyle(
                                              color: Colors.white,
                                            ),
                                          ),
                                  );
                                },
                              ),
                              const SizedBox(height: 16),
                              OutlinedButton(
                                style: OutlinedButton.styleFrom(
                                  minimumSize: const Size(
                                    double.infinity,
                                    48,
                                  ),
                                  side: BorderSide(
                                    color: isDark
                                        ? Colors.white54
                                        : Colors.black,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                      settings: const RouteSettings(name: '/'),
                                      builder: (_) => const SignUpView(),
                                    ),
                                  );
                                },
                                child: Text(
                                  "Create Account",
                                  style: TextStyle(
                                    color: isDark ? Colors.white : Colors.black,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 40),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  _socialButton(
                                    Icons.g_mobiledata,
                                    Colors.red,
                                    () {},
                                  ),
                                  const SizedBox(width: 20),
                                  _socialButton(
                                    Icons.apple,
                                    isDark ? Colors.white : Colors.black,
                                    () {},
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration(String label) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color borderColor = isDark ? Colors.white38 : AppColors.primary;
    return InputDecoration(
      labelText: label,
      helperText: '',
      helperStyle: TextStyle(color: isDark ? Colors.white : Colors.black87),
      labelStyle: TextStyle(color: isDark ? Colors.white70 : Colors.black87),
      hintStyle: TextStyle(color: isDark ? Colors.white54 : Colors.black54),
      filled: true,
      fillColor: isDark
          ? Colors.white.withValues(alpha: 0.08)
          : Colors.white.withValues(alpha: 0.92),
      border: OutlineInputBorder(
        borderSide: BorderSide(color: borderColor),
        borderRadius: BorderRadius.circular(12),
      ),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: borderColor),
        borderRadius: BorderRadius.circular(12),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: AppColors.primary, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  Widget _socialButton(IconData icon, Color color, VoidCallback onPressed) {
    return IconButton(
      icon: Icon(icon, size: 40, color: color),
      onPressed: onPressed,
    );
  }
}
