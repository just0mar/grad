import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appbar/CustomAppBar.dart';
import '../core/api_client.dart';
import '../core/responsive_system.dart';
import '../core/responsive_widgets.dart';
import '../team/team_bloc.dart';
import '../event/EventModel.dart';

class AddEventView extends StatefulWidget {
  const AddEventView({super.key});

  @override
  State<AddEventView> createState() => _AddEventViewState();
}

class _AddEventViewState extends State<AddEventView> {
  final TextEditingController _descriptionController = TextEditingController();
  
  String? _selectedType;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  final List<String> _eventTypes = const [
    'Match',
    'Training',
    'Test',
    'Meeting',
  ];

  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _pickDate(BuildContext context) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? now,
      firstDate: now,
      lastDate: DateTime(now.year + 2),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _pickTime(BuildContext context) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? const TimeOfDay(hour: 9, minute: 0),
    );
    if (picked != null) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  bool get _isReady => _selectedType != null && _selectedDate != null && _selectedTime != null;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final labelColor = isDark ? Colors.white70 : null;
    final textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: 'ADD EVENT'),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                : [Colors.green, Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          image: const DecorationImage(
            image: AssetImage('assets/background.png'),
            fit: BoxFit.cover,
            opacity: 0.2,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: ResponsiveSystem.pagePadding(context),
            child: Column(
              children: [
                DropdownButtonFormField<String>(
                  initialValue: _selectedType,
                  dropdownColor: fieldColor,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: 'Event type',
                    labelStyle:
                        TextStyle(color: labelColor, fontFamily: 'SFPro'),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  style: TextStyle(color: textColor, fontFamily: 'SFPro'),
                  items: _eventTypes
                      .map(
                        (e) => DropdownMenuItem(
                          value: e,
                          child: Text(e,
                              style: const TextStyle(fontFamily: 'SFPro')),
                        ),
                      )
                      .toList(),
                  onChanged: (val) {
                    setState(() {
                      _selectedType = val;
                    });
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  readOnly: true,
                  style: TextStyle(color: textColor, fontFamily: 'SFPro'),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: _selectedDate == null
                        ? 'MM/DD/YYYY'
                        : '${_selectedDate!.month}/${_selectedDate!.day}/${_selectedDate!.year}',
                    labelStyle:
                        TextStyle(color: labelColor, fontFamily: 'SFPro'),
                    suffixIcon: IconButton(
                      icon: Icon(
                        Icons.calendar_today,
                        color: isDark ? Colors.white70 : Colors.black54,
                      ),
                      onPressed: () => _pickDate(context),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  readOnly: true,
                  style: TextStyle(color: textColor, fontFamily: 'SFPro'),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: _selectedTime == null
                        ? 'Select Time'
                        : _selectedTime!.format(context),
                    labelStyle:
                        TextStyle(color: labelColor, fontFamily: 'SFPro'),
                    suffixIcon: IconButton(
                      icon: Icon(
                        Icons.access_time,
                        color: isDark ? Colors.white70 : Colors.black54,
                      ),
                      onPressed: () => _pickTime(context),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 4,
                  style: TextStyle(color: textColor, fontFamily: 'SFPro'),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: 'Event description',
                    labelStyle:
                        TextStyle(color: labelColor, fontFamily: 'SFPro'),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                ResponsivePrimaryButton(
                  context: context,
                  label: 'Add event',
                  onPressed: () async {
                    if (!_isReady) {
                      return;
                    }
                    final Event event = Event(
                      type: _selectedType!,
                      date: _selectedDate!,
                      time: _selectedTime!,
                      description: _descriptionController.text.trim(),
                    );

                    // POST to backend
                    try {
                      final teamState = context.read<TeamBloc>().state;
                      final clubId = teamState.activeClubId;
                      final teamId = teamState.selectedTeamId;
                      if (clubId.isNotEmpty && teamId.isNotEmpty) {
                        final startDate = DateTime(
                          _selectedDate!.year,
                          _selectedDate!.month,
                          _selectedDate!.day,
                          _selectedTime!.hour,
                          _selectedTime!.minute,
                        );
                        await ApiClient.post(
                          '/clubs/$clubId/teams/$teamId/events',
                          body: {
                            'eventType': _selectedType,
                            'title': _descriptionController.text.trim(),
                            'startDate': startDate.toIso8601String(),
                          },
                        );
                      }
                    } catch (_) {
                      // API call failed — still add locally
                    }

                    if (!context.mounted) return;
                    Navigator.pop(context, event);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
