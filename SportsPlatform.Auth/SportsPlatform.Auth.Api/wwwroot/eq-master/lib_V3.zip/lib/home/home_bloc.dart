import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../addteam/AddTeamModel.dart';
import '../announcement/AnnouncementModel.dart';
import '../core/api_client.dart';

// Events
abstract class HomeEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadHomeData extends HomeEvent {
  final String clubId;
  final String teamId;

  LoadHomeData({this.clubId = '', this.teamId = ''});

  @override
  List<Object?> get props => [clubId, teamId];
}

class AddTeamEvent extends HomeEvent {
  final Team team;
  AddTeamEvent(this.team);
  @override
  List<Object?> get props => [team];
}

class AddAnnouncementEvent extends HomeEvent {
  final Announcement announcement;
  AddAnnouncementEvent(this.announcement);
  @override
  List<Object?> get props => [announcement];
}

// State
class HomeState extends Equatable {
  final List<Team?> teams;
  final List<Announcement> announcements;
  final bool isLoading;
  final String? errorMessage;

  const HomeState({
    this.teams = const [],
    this.announcements = const [],
    this.isLoading = false,
    this.errorMessage,
  });

  HomeState copyWith({
    List<Team?>? teams,
    List<Announcement>? announcements,
    bool? isLoading,
    String? errorMessage,
    bool clearError = false,
  }) {
    return HomeState(
      teams: teams ?? this.teams,
      announcements: announcements ?? this.announcements,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }

  @override
  List<Object?> get props => [teams, announcements, isLoading, errorMessage];
}

// Bloc
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc() : super(const HomeState()) {
    on<LoadHomeData>(_onLoadHomeData);
    on<AddTeamEvent>(_onAddTeam);
    on<AddAnnouncementEvent>(_onAddAnnouncement);
  }

  Future<void> _onLoadHomeData(LoadHomeData event, Emitter<HomeState> emit) async {
    emit(state.copyWith(isLoading: true));

    try {
      // Load user's clubs → teams
      final clubsResponse = await ApiClient.get('/clubs/my');
      final clubsData = ApiClient.decodeListResponse(clubsResponse);

      final List<Team> loadedTeams = [];

      for (final club in clubsData) {
        final clubMap = club as Map<String, dynamic>;
        final clubId = clubMap['clubId']?.toString() ?? clubMap['id']?.toString() ?? '';
        final clubName = clubMap['name']?.toString() ?? clubMap['clubName']?.toString() ?? '';

        if (clubId.isEmpty) continue;

        try {
          final teamsResponse = await ApiClient.get('/clubs/$clubId/teams');
          final teamsData = ApiClient.decodeListResponse(teamsResponse);

          for (final t in teamsData) {
            final tm = t as Map<String, dynamic>;
            loadedTeams.add(Team(
              id: tm['teamId']?.toString() ?? tm['id']?.toString() ?? '',
              country: '',
              club: clubName,
              sport: tm['sport']?.toString() ?? 'Basketball',
              category: tm['categoryName']?.toString() ?? tm['teamName']?.toString() ?? '',
            ));
          }
        } catch (_) {
          // Failed to load teams for this club
        }
      }

      // Load announcements for the active team
      List<Announcement> loadedAnnouncements = [];
      if (event.clubId.isNotEmpty && event.teamId.isNotEmpty) {
        try {
          final annResponse = await ApiClient.get(
            '/clubs/${event.clubId}/teams/${event.teamId}/announcements',
          );
          final annData = ApiClient.decodeListResponse(annResponse);

          loadedAnnouncements = annData.map((a) {
            final map = a as Map<String, dynamic>;
            return Announcement(
              authorName: map['authorName']?.toString() ?? 'Unknown',
              authorRole: map['authorRole']?.toString() ?? '',
              authorImage: 'assets/profile.png',
              caption: map['content']?.toString() ?? map['message']?.toString() ?? map['caption']?.toString() ?? '',
              isEmergency: map['isEmergency'] == true,
            );
          }).toList();
        } catch (_) {
          // Announcements failed — non-critical
        }
      }

      emit(state.copyWith(
        teams: loadedTeams.isNotEmpty ? loadedTeams : const [],
        announcements: loadedAnnouncements,
        isLoading: false,
        clearError: true,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.message));
    } catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.toString()));
    }
  }

  void _onAddTeam(AddTeamEvent event, Emitter<HomeState> emit) {
    final newTeams = List<Team?>.from(state.teams)..add(event.team);
    emit(state.copyWith(teams: newTeams));
  }

  void _onAddAnnouncement(AddAnnouncementEvent event, Emitter<HomeState> emit) {
    final newAnnouncements = List<Announcement>.from(state.announcements)
      ..add(event.announcement);
    emit(state.copyWith(announcements: newAnnouncements));
  }
}
