import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'EventModel.dart';
import '../core/api_client.dart';

// Events
abstract class EventEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadEvents extends EventEvent {
  final String clubId;
  final String teamId;

  LoadEvents({this.clubId = '', this.teamId = ''});

  @override
  List<Object?> get props => [clubId, teamId];
}

class AddEvent extends EventEvent {
  final Event event;
  AddEvent(this.event);
  @override
  List<Object?> get props => [event];
}

class SelectDay extends EventEvent {
  final DateTime selectedDay;
  final DateTime focusedDay;
  SelectDay(this.selectedDay, this.focusedDay);
  @override
  List<Object?> get props => [selectedDay, focusedDay];
}

// State
class EventState extends Equatable {
  final List<Event> events;
  final DateTime selectedDay;
  final DateTime focusedDay;
  final Map<DateTime, List<Event>> eventsByDay;
  final bool isLoading;
  final String? errorMessage;

  EventState({
    this.events = const [],
    DateTime? selectedDay,
    DateTime? focusedDay,
    this.eventsByDay = const {},
    this.isLoading = false,
    this.errorMessage,
  })  : selectedDay = selectedDay ?? DateTime.now(),
        focusedDay = focusedDay ?? DateTime.now();

  EventState copyWith({
    List<Event>? events,
    DateTime? selectedDay,
    DateTime? focusedDay,
    Map<DateTime, List<Event>>? eventsByDay,
    bool? isLoading,
    String? errorMessage,
    bool clearError = false,
  }) {
    return EventState(
      events: events ?? this.events,
      selectedDay: selectedDay ?? this.selectedDay,
      focusedDay: focusedDay ?? this.focusedDay,
      eventsByDay: eventsByDay ?? this.eventsByDay,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }

  List<Event> get upcomingEvents {
    final DateTime now = DateTime.now();
    const List<String> types = ["Match", "Training", "Meeting", "Test"];
    final List<Event> result = [];

    for (final String type in types) {
      final List<Event> upcoming = events
          .where((e) =>
              e.type.trim() == type &&
              e.date.isAfter(now.subtract(const Duration(days: 1))))
          .toList()
        ..sort((a, b) => a.date.compareTo(b.date));

      if (upcoming.isNotEmpty) {
        result.add(upcoming.first);
      }
    }
    return result;
  }

  @override
  List<Object?> get props => [events, selectedDay, focusedDay, eventsByDay, isLoading, errorMessage];
}

// Bloc
class EventBloc extends Bloc<EventEvent, EventState> {
  EventBloc() : super(EventState()) {
    on<LoadEvents>(_onLoadEvents);
    on<AddEvent>(_onAddEvent);
    on<SelectDay>(_onSelectDay);
  }

  Future<void> _onLoadEvents(LoadEvents event, Emitter<EventState> emit) async {
    if (event.clubId.isEmpty || event.teamId.isEmpty) return;

    emit(state.copyWith(isLoading: true));
    try {
      final response = await ApiClient.get(
        '/clubs/${event.clubId}/teams/${event.teamId}/events',
      );
      final data = ApiClient.decodeListResponse(response);

      final events = data.map((e) {
        final map = e as Map<String, dynamic>;
        final dateStr = map['startDate']?.toString() ?? map['date']?.toString() ?? '';
        DateTime date;
        try {
          date = DateTime.parse(dateStr);
        } catch (_) {
          date = DateTime.now();
        }

        return Event(
          type: map['eventType']?.toString() ?? map['type']?.toString() ?? 'Training',
          date: date,
          time: TimeOfDay(hour: date.hour, minute: date.minute),
          description: map['title']?.toString() ?? map['description']?.toString() ?? '',
        );
      }).toList();

      final eventsByDay = _rebuildEventsByDay(events);
      emit(state.copyWith(
        events: events,
        eventsByDay: eventsByDay,
        isLoading: false,
        clearError: true,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.message));
    } catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.toString()));
    }
  }

  void _onAddEvent(AddEvent event, Emitter<EventState> emit) {
    final newEvents = List<Event>.from(state.events)..add(event.event);
    final newEventsByDay = _rebuildEventsByDay(newEvents);
    emit(state.copyWith(events: newEvents, eventsByDay: newEventsByDay));
  }

  void _onSelectDay(SelectDay event, Emitter<EventState> emit) {
    emit(state.copyWith(selectedDay: event.selectedDay, focusedDay: event.focusedDay));
  }

  Map<DateTime, List<Event>> _rebuildEventsByDay(List<Event> events) {
    final map = <DateTime, List<Event>>{};
    for (final event in events) {
      final day = DateTime(event.date.year, event.date.month, event.date.day);
      map.putIfAbsent(day, () => []).add(event);
    }
    return map;
  }
}
