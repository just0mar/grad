import 'package:flutter/material.dart';
import '../core/api_client.dart';

class PlansViewModel extends ChangeNotifier {
  String _selectedCategory = "Offensive";
  bool _isLoading = false;

  final List<Map<String, dynamic>> _plans = <Map<String, dynamic>>[];

  String _clubId = '';
  String _teamId = '';

  String get selectedCategory => _selectedCategory;
  List<Map<String, dynamic>> get plans => _plans;
  bool get isLoading => _isLoading;

  List<Map<String, dynamic>> get filteredPlans {
    return _plans
        .where((Map<String, dynamic> p) => p["category"] == _selectedCategory)
        .toList();
  }

  void setCategory(String category) {
    if (_selectedCategory == category) return;
    _selectedCategory = category;
    notifyListeners();
  }

  /// Initialize with club/team context and load from API
  Future<void> loadPlans(String clubId, String teamId) async {
    _clubId = clubId;
    _teamId = teamId;

    if (_clubId.isEmpty || _teamId.isEmpty) return;

    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiClient.get('/clubs/$_clubId/teams/$_teamId/plans');
      final data = ApiClient.decodeListResponse(response);

      _plans.clear();
      for (int i = 0; i < data.length; i++) {
        final map = data[i] as Map<String, dynamic>;
        _plans.add(<String, dynamic>{
          "id": map['planId']?.toString() ?? map['id']?.toString() ?? '',
          "title": map['title']?.toString() ?? "PLAN ${i + 1}",
          "category": map['category']?.toString() ?? "Offensive",
          "image": map['imageUrl']?.toString() ?? "assets/Plan1.png",
          "description": map['description']?.toString() ?? "",
          "pdfPath": map['pdfUrl']?.toString() ?? "",
          "videoPath": map['videoUrl']?.toString() ?? "",
        });
      }
    } catch (_) {
      // API not available — plans remain empty
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> removePlanAt(int globalIndex) async {
    if (globalIndex >= _plans.length) return;

    final planId = _plans[globalIndex]['id']?.toString() ?? '';
    _plans.removeAt(globalIndex);
    for (int i = 0; i < _plans.length; i++) {
      _plans[i]["title"] = "PLAN ${i + 1}";
    }
    notifyListeners();

    // Delete from backend
    if (planId.isNotEmpty && _clubId.isNotEmpty && _teamId.isNotEmpty) {
      try {
        await ApiClient.delete('/clubs/$_clubId/teams/$_teamId/plans/$planId');
      } catch (_) {
        // Silent failure — already removed from local state
      }
    }
  }

  Future<void> addPlan(Map<String, dynamic> newPlan) async {
    final int number = _plans.length + 1;
    final localPlan = <String, dynamic>{
      "title": "PLAN $number",
      "category": newPlan["category"],
      "image": newPlan["image"] ?? "assets/Plan1.png",
      "description": newPlan["description"] ?? "",
      "pdfPath": newPlan["pdfPath"] ?? "",
      "videoPath": newPlan["videoPath"] ?? "",
    };

    _plans.add(localPlan);
    _selectedCategory = newPlan["category"] as String;
    notifyListeners();

    // Create on backend
    if (_clubId.isNotEmpty && _teamId.isNotEmpty) {
      try {
        final response = await ApiClient.post(
          '/clubs/$_clubId/teams/$_teamId/plans',
          body: {
            'title': localPlan['title'],
            'category': localPlan['category'],
            'description': localPlan['description'],
          },
        );
        final data = ApiClient.decodeResponse(response);
        localPlan['id'] = data['planId']?.toString() ?? data['id']?.toString() ?? '';
        notifyListeners();
      } catch (_) {
        // Created locally only
      }
    }
  }
}
