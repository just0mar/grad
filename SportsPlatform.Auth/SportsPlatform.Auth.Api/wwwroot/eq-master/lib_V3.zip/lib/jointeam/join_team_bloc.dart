import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../core/api_client.dart';

// Events
abstract class JoinTeamEvent extends Equatable {
  const JoinTeamEvent();
  @override
  List<Object?> get props => [];
}

class LoadPendingInvitations extends JoinTeamEvent {
  const LoadPendingInvitations();
}

class AcceptRequest extends JoinTeamEvent {
  final int index;
  const AcceptRequest(this.index);
  @override
  List<Object?> get props => [index];
}

class RejectRequest extends JoinTeamEvent {
  final int index;
  const RejectRequest(this.index);
  @override
  List<Object?> get props => [index];
}

// State
class JoinTeamState extends Equatable {
  final List<Map<String, dynamic>> requests;
  final bool isLoading;
  final String? errorMessage;

  const JoinTeamState({
    required this.requests,
    this.isLoading = false,
    this.errorMessage,
  });

  JoinTeamState copyWith({
    List<Map<String, dynamic>>? requests,
    bool? isLoading,
    String? errorMessage,
    bool clearError = false,
  }) {
    return JoinTeamState(
      requests: requests ?? this.requests,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }

  @override
  List<Object?> get props => [requests, isLoading, errorMessage];
}

// Bloc
class JoinTeamBloc extends Bloc<JoinTeamEvent, JoinTeamState> {
  JoinTeamBloc() : super(const JoinTeamState(requests: [])) {
    on<LoadPendingInvitations>(_onLoadPendingInvitations);
    on<AcceptRequest>(_onAcceptRequest);
    on<RejectRequest>(_onRejectRequest);
  }

  Future<void> _onLoadPendingInvitations(
    LoadPendingInvitations event,
    Emitter<JoinTeamState> emit,
  ) async {
    emit(state.copyWith(isLoading: true));
    try {
      final response = await ApiClient.get('/invitations/pending');
      final data = ApiClient.decodeListResponse(response);

      final requests = data.map((inv) {
        final map = inv as Map<String, dynamic>;
        return <String, dynamic>{
          'id': map['invitationId']?.toString() ?? map['id']?.toString() ?? '',
          'team': map['teamName']?.toString() ?? map['team']?.toString() ?? 'Unknown',
          'clubName': map['clubName']?.toString() ?? '',
          'members': map['memberCount'] ?? map['members'] ?? 0,
        };
      }).toList();

      emit(state.copyWith(
        requests: requests,
        isLoading: false,
        clearError: true,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.message));
    } catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.toString()));
    }
  }

  Future<void> _onAcceptRequest(AcceptRequest event, Emitter<JoinTeamState> emit) async {
    if (event.index >= state.requests.length) return;

    final invitation = state.requests[event.index];
    final invId = invitation['id']?.toString() ?? '';

    if (invId.isNotEmpty) {
      try {
        await ApiClient.post('/invitations/$invId/accept');
      } catch (_) {
        // Handle silently — remove from list anyway
      }
    }

    final updated = List<Map<String, dynamic>>.from(state.requests);
    updated.removeAt(event.index);
    emit(state.copyWith(requests: updated));
  }

  Future<void> _onRejectRequest(RejectRequest event, Emitter<JoinTeamState> emit) async {
    if (event.index >= state.requests.length) return;

    final invitation = state.requests[event.index];
    final invId = invitation['id']?.toString() ?? '';

    if (invId.isNotEmpty) {
      try {
        await ApiClient.delete('/invitations/$invId');
      } catch (_) {
        // Handle silently
      }
    }

    final updated = List<Map<String, dynamic>>.from(state.requests);
    updated.removeAt(event.index);
    emit(state.copyWith(requests: updated));
  }

  Future<bool> joinTeamById(String id) async {
    if (id.isEmpty) return false;
    try {
      await ApiClient.post('/invitations/accept-by-code', body: {'code': id});
      return true;
    } catch (_) {
      return false;
    }
  }
}
