import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../gamehistory/GameHistoryModel.dart';
import '../core/api_client.dart';

// Events
abstract class StatsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadStats extends StatsEvent {
  final String sport;
  final String clubId;
  final String teamId;

  LoadStats(this.sport, {this.clubId = '', this.teamId = ''});

  @override
  List<Object?> get props => [sport, clubId, teamId];
}

class UpdateStat extends StatsEvent {
  final String label;
  final double value;
  UpdateStat(this.label, this.value);

  @override
  List<Object?> get props => [label, value];
}

class UpdateTableStats extends StatsEvent {
  final List<Map<String, dynamic>> rows;
  UpdateTableStats(this.rows);
  @override
  List<Object?> get props => [rows];
}

// State
class StatsState extends Equatable {
  final Map<String, double> stats;
  final List<GameHistory> gameHistory;
  final List<Map<String, dynamic>> chartLines;
  final List<Map<String, dynamic>> tableRows;
  final bool isLoading;
  final String? errorMessage;

  const StatsState({
    this.stats = const {},
    this.gameHistory = const [],
    this.chartLines = const [],
    this.tableRows = const [],
    this.isLoading = false,
    this.errorMessage,
  });

  StatsState copyWith({
    Map<String, double>? stats,
    List<GameHistory>? gameHistory,
    List<Map<String, dynamic>>? chartLines,
    List<Map<String, dynamic>>? tableRows,
    bool? isLoading,
    String? errorMessage,
    bool clearError = false,
  }) {
    return StatsState(
      stats: stats ?? this.stats,
      gameHistory: gameHistory ?? this.gameHistory,
      chartLines: chartLines ?? this.chartLines,
      tableRows: tableRows ?? this.tableRows,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }

  @override
  List<Object?> get props => [stats, gameHistory, chartLines, tableRows, isLoading, errorMessage];
}

// Bloc
class StatsBloc extends Bloc<StatsEvent, StatsState> {
  StatsBloc() : super(const StatsState()) {
    on<LoadStats>(_onLoadStats);
    on<UpdateStat>(_onUpdateStat);
    on<UpdateTableStats>(_onUpdateTableStats);
  }

  Future<void> _onLoadStats(LoadStats event, Emitter<StatsState> emit) async {
    emit(state.copyWith(isLoading: true));

    // If we have club/team IDs, try to load from API
    if (event.clubId.isNotEmpty && event.teamId.isNotEmpty) {
      try {
        // Load team stats
        Map<String, double> parsedStats = {};
        try {
          final statsResponse = await ApiClient.get(
            '/clubs/${event.clubId}/teams/${event.teamId}/stats',
          );
          final statsData = ApiClient.decodeResponse(statsResponse);
          statsData.forEach((key, value) {
            if (value is num) {
              parsedStats[key] = value.toDouble();
            }
          });
        } catch (_) {
          // Stats endpoint might not exist yet
        }

        // Load match history
        List<GameHistory> matchHistory = [];
        try {
          final matchesResponse = await ApiClient.get(
            '/clubs/${event.clubId}/teams/${event.teamId}/stats/matches',
          );
          final matchesData = ApiClient.decodeListResponse(matchesResponse);

          matchHistory = matchesData.map((m) {
            final map = m as Map<String, dynamic>;
            return GameHistory(
              opponent: map['opponent']?.toString() ?? map['opponentName']?.toString() ?? 'Unknown',
              ourScore: (map['teamScore'] ?? map['ourScore'] ?? 0) as int,
              theirScore: (map['opponentScore'] ?? map['theirScore'] ?? 0) as int,
              date: map['date']?.toString() ?? map['matchDate']?.toString() ?? '',
              stats: const [],
              pdfFiles: const [],
              videos: const [],
            );
          }).toList();
        } catch (_) {
          // Match history might not exist yet
        }

        emit(state.copyWith(
          stats: parsedStats,
          gameHistory: matchHistory,
          chartLines: _buildChartLines(event.sport, parsedStats),
          tableRows: _buildTableRows(event.sport, parsedStats),
          isLoading: false,
          clearError: true,
        ));
        return;
      } catch (e) {
        // Fall through to default data
      }
    }

    // No API data — generate empty chart/table structure for the sport
    emit(state.copyWith(
      chartLines: _buildChartLines(event.sport, {}),
      tableRows: _buildTableRows(event.sport, {}),
      isLoading: false,
      clearError: true,
    ));
  }

  void _onUpdateStat(UpdateStat event, Emitter<StatsState> emit) {
    final updatedStats = Map<String, double>.from(state.stats);
    updatedStats[event.label] = event.value;
    emit(state.copyWith(stats: updatedStats));
  }

  void _onUpdateTableStats(UpdateTableStats event, Emitter<StatsState> emit) {
    emit(state.copyWith(tableRows: event.rows));
  }

  // ── Default chart/table structures per sport ──
  // (will be populated from API when data exists)

  List<Map<String, dynamic>> _buildChartLines(String sport, Map<String, double> data) {
    if (sport == 'Football') {
      return [
        {
          'label': 'Goals',
          'color': Colors.green,
          'spots': <double>[0, 0, 0, 0, 0],
        },
        {
          'label': 'Assists',
          'color': Colors.blue,
          'spots': <double>[0, 0, 0, 0, 0],
        },
      ];
    }
    // Basketball default
    return [
      {
        'label': 'Points',
        'color': Colors.green,
        'spots': <double>[0, 0, 0, 0, 0],
      },
      {
        'label': 'Rebounds',
        'color': Colors.orange,
        'spots': <double>[0, 0, 0, 0, 0],
      },
      {
        'label': 'Assists',
        'color': Colors.blue,
        'spots': <double>[0, 0, 0, 0, 0],
      },
    ];
  }

  List<Map<String, dynamic>> _buildTableRows(String sport, Map<String, double> data) {
    if (sport == 'Football') {
      return [
        {'title': 'Goals', 'lastGame': '-', 'cumulative': '-'},
        {'title': 'Assists', 'lastGame': '-', 'cumulative': '-'},
        {'title': 'Shots on Target', 'lastGame': '-', 'cumulative': '-'},
        {'title': 'Pass Accuracy', 'lastGame': '-', 'cumulative': '-'},
      ];
    }
    // Basketball default
    return [
      {'title': 'Points', 'lastGame': '-', 'cumulative': '-'},
      {'title': 'Rebounds', 'lastGame': '-', 'cumulative': '-'},
      {'title': 'Assists', 'lastGame': '-', 'cumulative': '-'},
      {'title': 'Steals', 'lastGame': '-', 'cumulative': '-'},
      {'title': 'Blocks', 'lastGame': '-', 'cumulative': '-'},
      {'title': 'Turnovers', 'lastGame': '-', 'cumulative': '-'},
    ];
  }
}
