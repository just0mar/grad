import 'role_access.dart';

/// Centralized permission service.
///
/// All permission checks go through [RoleAccess] which mirrors the
/// React web app's `roleAccess.js` exactly.
class PermissionService {
  /// Convenience — kept for backward compatibility.
  static bool canEditStates(String role) {
    return role.trim() == 'TeamAnalyst';
  }

  /// Build a full [RoleAccess] from the user's role list.
  static RoleAccess accessFor(List<String> roles, {bool isAdmin = false}) {
    return getRoleAccess(roles, isAdmin: isAdmin);
  }
}
