import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import '../chat/ChatView.dart';
import '../core/responsive_system.dart';
import 'messages_bloc.dart';

class MessagesView extends StatelessWidget {
  final List<Map<String, dynamic>> plans;

  const MessagesView({
    super.key,
    required this.plans,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return BlocProvider(
      create: (context) => MessagesBloc()..add(LoadMessages()),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: CustomAppBar(
          title: "Messages",
          plans: plans,
        ),
        body: SizedBox.expand(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: isDark
                    ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                    : [Colors.green, Colors.white],
              ),
              image: const DecorationImage(
                image: AssetImage("assets/background.png"),
                fit: BoxFit.cover,
                opacity: 0.2,
              ),
            ),
            child: SafeArea(
              child: BlocBuilder<MessagesBloc, MessagesState>(
                builder: (context, state) {
                  if (state.isLoading) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return ListView.builder(
                    padding: ResponsiveSystem.pagePadding(context),
                    itemCount: state.teamMembers.length,
                    itemBuilder: (context, index) {
                      final member = state.teamMembers[index];
                      return _MessageCard(member: member);
                    },
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  final TeamMember member;

  const _MessageCard({required this.member});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChatView(
              personName: member.name,
              personImage: member.image,
            ),
          ),
        );
      },
      child: Card(
        color: isDark ? const Color(0xFF1B3A2D) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 3,
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              CircleAvatar(
                backgroundImage: AssetImage(member.image),
                radius: 28,
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    member.name,
                    style: TextStyle(
                      fontFamily: 'SFPro',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : Colors.black,
                    ),
                  ),
                  Text(
                    member.role,
                    style: TextStyle(
                      fontFamily: 'SFPro',
                      fontSize: 16,
                      color: isDark ? Colors.white54 : Colors.grey,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
