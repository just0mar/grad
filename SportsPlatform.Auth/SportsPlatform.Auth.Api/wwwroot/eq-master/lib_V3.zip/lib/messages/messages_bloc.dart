import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../core/api_client.dart';

// The existing TeamMember model used by MessagesView
class TeamMember {
  final String name;
  final String role;
  final String image;

  TeamMember({required this.name, required this.role, this.image = 'assets/profile.png'});
}

// Events
abstract class MessagesEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadMessages extends MessagesEvent {
  final String clubId;
  final String teamId;

  LoadMessages({this.clubId = '', this.teamId = ''});

  @override
  List<Object?> get props => [clubId, teamId];
}

// State
class MessagesState extends Equatable {
  final List<TeamMember> teamMembers;
  final bool isLoading;
  final String? errorMessage;

  const MessagesState({
    this.teamMembers = const [],
    this.isLoading = false,
    this.errorMessage,
  });

  MessagesState copyWith({
    List<TeamMember>? teamMembers,
    bool? isLoading,
    String? errorMessage,
    bool clearError = false,
  }) {
    return MessagesState(
      teamMembers: teamMembers ?? this.teamMembers,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }

  @override
  List<Object?> get props => [teamMembers, isLoading, errorMessage];
}

// Bloc
class MessagesBloc extends Bloc<MessagesEvent, MessagesState> {
  MessagesBloc() : super(const MessagesState()) {
    on<LoadMessages>(_onLoadMessages);
  }

  Future<void> _onLoadMessages(LoadMessages event, Emitter<MessagesState> emit) async {
    if (event.clubId.isEmpty || event.teamId.isEmpty) {
      // No team context — try loading conversations
      emit(state.copyWith(isLoading: true));
      try {
        final response = await ApiClient.get('/messages/conversations');
        final data = ApiClient.decodeListResponse(response);

        final members = data.map((m) {
          final map = m as Map<String, dynamic>;
          return TeamMember(
            name: map['name']?.toString() ?? map['participantName']?.toString() ?? 'Unknown',
            role: map['role']?.toString() ?? '',
          );
        }).toList();

        emit(state.copyWith(
          teamMembers: members,
          isLoading: false,
          clearError: true,
        ));
      } on ApiException catch (e) {
        emit(state.copyWith(isLoading: false, errorMessage: e.message));
      } catch (e) {
        emit(state.copyWith(isLoading: false, errorMessage: e.toString()));
      }
      return;
    }

    // Load team members as potential message targets
    emit(state.copyWith(isLoading: true));
    try {
      final response = await ApiClient.get(
        '/clubs/${event.clubId}/teams/${event.teamId}/members',
      );
      final data = ApiClient.decodeListResponse(response);

      final members = data.map((m) {
        final map = m as Map<String, dynamic>;
        return TeamMember(
          name: map['name']?.toString() ?? map['userName']?.toString() ?? 'Unknown',
          role: map['role']?.toString() ?? 'Player',
        );
      }).toList();

      emit(state.copyWith(
        teamMembers: members,
        isLoading: false,
        clearError: true,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.message));
    } catch (e) {
      emit(state.copyWith(isLoading: false, errorMessage: e.toString()));
    }
  }
}
