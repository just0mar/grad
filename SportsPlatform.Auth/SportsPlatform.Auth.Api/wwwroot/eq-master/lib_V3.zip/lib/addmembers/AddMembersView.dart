import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appbar/CustomAppBar.dart';
import '../core/api_client.dart';
import '../core/design_tokens.dart';
import '../core/responsive_system.dart';
import '../core/responsive_widgets.dart';
import '../members/MemberModel.dart';
import '../team/team_bloc.dart';

class AddMembersView extends StatelessWidget {
  const AddMembersView({super.key});

  @override
  Widget build(BuildContext context) {
    return const _AddMembersContent();
  }
}

class _AddMembersContent extends StatelessWidget {
  const _AddMembersContent();

  final String invitationLink = 'https://equipex.app/join/perf-rev-8821';

  bool _canAddMember(String enteredId) => enteredId.isNotEmpty;
  bool _canSendRequest(String value) => value.isNotEmpty;

  Member _buildMemberFromId(String enteredId) {
    return Member(name: 'Member #$enteredId', role: 'Player');
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: 'Add Members'),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
            ),
            image: const DecorationImage(
              image: AssetImage('assets/background.png'),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: DefaultTabController(
            length: 3,
            child: Column(
              children: [
                SizedBox(
                  height:
                      kToolbarHeight + ResponsiveSystem.verticalGap(context),
                ),
                Container(
                  margin: EdgeInsets.symmetric(
                    horizontal: ResponsiveSystem.horizontalPadding(context),
                  ),
                  decoration: BoxDecoration(
                    color: isDark ? const Color(0xFF1B3A2D) : Colors.white,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: TabBar(
                    isScrollable: true,
                    labelColor: Colors.green,
                    unselectedLabelColor: isDark
                        ? Colors.white60
                        : Colors.black54,
                    indicatorColor: AppColors.primary,
                    labelStyle: const TextStyle(
                      fontFamily: 'SFPro',
                      fontWeight: FontWeight.bold,
                    ),
                    unselectedLabelStyle: const TextStyle(fontFamily: 'SFPro'),
                    tabs: const [
                      Tab(text: 'Add by ID'),
                      Tab(text: 'Requests'),
                      Tab(text: 'Invitation'),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      _AddByIdTab(
                        canAddMember: _canAddMember,
                        buildMember: _buildMemberFromId,
                      ),
                      _RequestsTab(canSendRequest: _canSendRequest),
                      _InvitationTab(link: invitationLink),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AddByIdTab extends StatefulWidget {
  final bool Function(String) canAddMember;
  final Member Function(String) buildMember;

  const _AddByIdTab({required this.canAddMember, required this.buildMember});

  @override
  State<_AddByIdTab> createState() => _AddByIdTabState();
}

class _AddByIdTabState extends State<_AddByIdTab> {
  final TextEditingController _idController = TextEditingController();

  @override
  void dispose() {
    _idController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;

    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          padding: ResponsiveSystem.pagePadding(context),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight),
            child: Column(
              children: [
                TextField(
                  controller: _idController,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: isDark ? Colors.white : Colors.black,
                    fontFamily: 'SFPro',
                  ),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: 'Member Id',
                    labelStyle: TextStyle(
                      color: isDark ? Colors.white70 : Colors.black54,
                      fontFamily: 'SFPro',
                    ),
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(30)),
                      borderSide: BorderSide(color: AppColors.primary),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                ResponsivePrimaryButton(
                  context: context,
                  label: 'Add',
                  onPressed: () async {
                    final String enteredId = _idController.text.trim();
                    if (!widget.canAddMember(enteredId)) {
                      return;
                    }

                    final Member member = widget.buildMember(enteredId);

                    // Try to invite via backend
                    try {
                      final teamState = context.read<TeamBloc>().state;
                      final clubId = teamState.activeClubId;
                      final teamId = teamState.selectedTeamId;
                      if (clubId.isNotEmpty && teamId.isNotEmpty) {
                        await ApiClient.post(
                          '/clubs/$clubId/teams/$teamId/invitations',
                          body: {
                            'identifier': enteredId,
                            'role': 'Player',
                          },
                        );
                      }
                    } catch (_) {
                      // Fallback to local add
                    }

                    if (!context.mounted) return;
                    context.read<TeamBloc>().add(AddTeamMember(member));

                    _showStatusDialog(
                      context,
                      message: 'Member $enteredId added successfully!',
                    );
                    _idController.clear();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _RequestsTab extends StatefulWidget {
  final bool Function(String) canSendRequest;

  const _RequestsTab({required this.canSendRequest});

  @override
  State<_RequestsTab> createState() => _RequestsTabState();
}

class _RequestsTabState extends State<_RequestsTab> {
  final TextEditingController _requestController = TextEditingController();

  @override
  void dispose() {
    _requestController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;

    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          padding: ResponsiveSystem.pagePadding(context),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight),
            child: Column(
              children: [
                TextField(
                  controller: _requestController,
                  style: TextStyle(
                    color: isDark ? Colors.white : Colors.black,
                    fontFamily: 'SFPro',
                  ),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: fieldColor,
                    labelText: 'Member Email/Phone number',
                    labelStyle: TextStyle(
                      color: isDark ? Colors.white70 : Colors.black54,
                      fontFamily: 'SFPro',
                    ),
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(30)),
                      borderSide: BorderSide(color: AppColors.primary),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                ResponsivePrimaryButton(
                  context: context,
                  label: 'Send request',
                  onPressed: () async {
                    final String value = _requestController.text.trim();
                    if (!widget.canSendRequest(value)) {
                      return;
                    }

                    // Send invitation via backend
                    try {
                      final teamState = context.read<TeamBloc>().state;
                      final clubId = teamState.activeClubId;
                      final teamId = teamState.selectedTeamId;
                      if (clubId.isNotEmpty && teamId.isNotEmpty) {
                        await ApiClient.post(
                          '/clubs/$clubId/teams/$teamId/invitations',
                          body: {
                            'email': value,
                            'role': 'Player',
                          },
                        );
                      }
                    } catch (_) {
                      // Handle error silently
                    }

                    if (!context.mounted) return;
                    _showStatusDialog(
                      context,
                      message: 'Request sent successfully!',
                    );
                    _requestController.clear();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _InvitationTab extends StatelessWidget {
  final String link;

  const _InvitationTab({required this.link});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;

    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          padding: ResponsiveSystem.pagePadding(context),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.green),
                    borderRadius: BorderRadius.circular(30),
                    color: fieldColor,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          link,
                          style: TextStyle(
                            fontSize: 14,
                            color: isDark ? Colors.white : Colors.black,
                            fontFamily: 'SFPro',
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.copy, color: Colors.green),
                        onPressed: () => _showSnackBar(context, 'Link copied!'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                ResponsivePrimaryButton(
                  context: context,
                  label: 'Copy link',
                  onPressed: () => _showSnackBar(context, 'Link copied!'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

void _showSnackBar(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

void _showStatusDialog(BuildContext context, {required String message}) {
  final bool isDark = Theme.of(context).brightness == Brightness.dark;

  showDialog<void>(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: isDark ? const Color(0xFF1B3A2D) : Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.topRight,
              child: IconButton(
                icon: Icon(
                  Icons.close,
                  color: isDark ? Colors.white : Colors.black,
                ),
                onPressed: () => Navigator.pop(ctx),
              ),
            ),
            Text(
              message,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.black,
                fontFamily: 'SFPro',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ResponsivePrimaryButton(
              context: ctx,
              label: 'Ok',
              onPressed: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    ),
  );
}
