import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../addteam/AddTeamModel.dart';
import '../members/MemberModel.dart';
import '../core/api_client.dart';


abstract class TeamEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadTeamMembers extends TeamEvent {}

class ConfigureTeamAccess extends TeamEvent {
  final String userId;
  final String fallbackRole;

  /// Clubs from AuthResponse: [{clubId, clubName, role}]
  final List<Map<String, dynamic>> clubs;

  /// Teams from AuthResponse: [{teamId, teamName, clubId, role}]
  final List<Map<String, dynamic>> teams;

  ConfigureTeamAccess({
    required this.userId,
    required this.fallbackRole,
    this.clubs = const [],
    this.teams = const [],
  });

  @override
  List<Object?> get props => [userId, fallbackRole, clubs, teams];
}

class RegisterTeam extends TeamEvent {
  final Team team;
  final String fallbackRole;

  RegisterTeam({required this.team, required this.fallbackRole});

  @override
  List<Object?> get props => [team, fallbackRole];
}

class SwitchTeamContext extends TeamEvent {
  final String teamId;

  SwitchTeamContext(this.teamId);

  @override
  List<Object?> get props => [teamId];
}

class ClearPermissionError extends TeamEvent {}

class UpdateMemberStatus extends TeamEvent {
  final int index;
  final bool isInSquad;
  UpdateMemberStatus(this.index, this.isInSquad);

  @override
  List<Object?> get props => [index, isInSquad];
}

class UpdateMemberData extends TeamEvent {
  final int index;
  final Member member;
  final bool requiresStateEditPermission;

  UpdateMemberData(
    this.index,
    this.member, {
    this.requiresStateEditPermission = false,
  });

  @override
  List<Object?> get props => [index, member, requiresStateEditPermission];
}

class AddTeamMember extends TeamEvent {
  final Member member;
  AddTeamMember(this.member);

  @override
  List<Object?> get props => [member];
}

// States
class TeamState extends Equatable {
  final List<Member> members;
  final Map<String, List<Member>> membersByTeamId;
  final List<Team> availableTeams;
  final String selectedTeamId;
  final String selectedTeamName;
  final String userRoleInSelectedTeam;
  final String currentUserId;
  final bool isLoading;
  final String? permissionError;
  final String? errorMessage;

  /// Active club ID from the backend club→team hierarchy.
  final String activeClubId;

  const TeamState({
    this.members = const [],
    this.membersByTeamId = const {},
    this.availableTeams = const [],
    this.selectedTeamId = '',
    this.selectedTeamName = 'My Team',
    this.userRoleInSelectedTeam = '',
    this.currentUserId = '',
    this.isLoading = false,
    this.permissionError,
    this.errorMessage,
    this.activeClubId = '',
  });

  TeamState copyWith({
    List<Member>? members,
    Map<String, List<Member>>? membersByTeamId,
    List<Team>? availableTeams,
    String? selectedTeamId,
    String? selectedTeamName,
    String? userRoleInSelectedTeam,
    String? currentUserId,
    bool? isLoading,
    String? permissionError,
    bool clearPermissionError = false,
    String? errorMessage,
    bool clearError = false,
    String? activeClubId,
  }) {
    return TeamState(
      members: members ?? this.members,
      membersByTeamId: membersByTeamId ?? this.membersByTeamId,
      availableTeams: availableTeams ?? this.availableTeams,
      selectedTeamId: selectedTeamId ?? this.selectedTeamId,
      selectedTeamName: selectedTeamName ?? this.selectedTeamName,
      userRoleInSelectedTeam:
          userRoleInSelectedTeam ?? this.userRoleInSelectedTeam,
      currentUserId: currentUserId ?? this.currentUserId,
      isLoading: isLoading ?? this.isLoading,
      permissionError: clearPermissionError
          ? null
          : (permissionError ?? this.permissionError),
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      activeClubId: activeClubId ?? this.activeClubId,
    );
  }

  @override
  List<Object?> get props => [
    members,
    membersByTeamId,
    availableTeams,
    selectedTeamId,
    selectedTeamName,
    userRoleInSelectedTeam,
    currentUserId,
    isLoading,
    permissionError,
    errorMessage,
    activeClubId,
  ];
}

// Bloc
class TeamBloc extends Bloc<TeamEvent, TeamState> {
  TeamBloc() : super(const TeamState()) {
    on<LoadTeamMembers>(_onLoadTeamMembers);
    on<ConfigureTeamAccess>(_onConfigureTeamAccess);
    on<RegisterTeam>(_onRegisterTeam);
    on<SwitchTeamContext>(_onSwitchTeamContext);
    on<ClearPermissionError>(_onClearPermissionError);
    on<UpdateMemberStatus>(_onUpdateMemberStatus);
    on<UpdateMemberData>(_onUpdateMemberData);
    on<AddTeamMember>(_onAddTeamMember);
  }

  // ── Load members for the currently selected team ──

  Future<void> _onLoadTeamMembers(
    LoadTeamMembers event,
    Emitter<TeamState> emit,
  ) async {
    if (state.activeClubId.isEmpty || state.selectedTeamId.isEmpty) {
      return;
    }

    emit(state.copyWith(isLoading: true));

    try {
      final response = await ApiClient.get(
        '/clubs/${state.activeClubId}/teams/${state.selectedTeamId}/members',
      );
      final data = ApiClient.decodeListResponse(response);

      final members = data.map((m) {
        final map = m as Map<String, dynamic>;
        return Member(
          userId: map['userId']?.toString() ?? map['id']?.toString() ?? '',
          name: map['name']?.toString() ?? map['userName']?.toString() ?? '',
          role: map['role']?.toString() ?? 'Player',
          image: 'assets/profile.png',
          age: map['age'] as int? ?? 0,
        );
      }).toList();

      final updatedMap = <String, List<Member>>{
        ...state.membersByTeamId,
        state.selectedTeamId: members,
      };

      emit(state.copyWith(
        members: members,
        membersByTeamId: updatedMap,
        isLoading: false,
        clearError: true,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(
        isLoading: false,
        errorMessage: e.message,
      ));
    } catch (e) {
      emit(state.copyWith(
        isLoading: false,
        errorMessage: e.toString(),
      ));
    }
  }

  // ── Configure team access from login response ──

  Future<void> _onConfigureTeamAccess(
    ConfigureTeamAccess event,
    Emitter<TeamState> emit,
  ) async {
    emit(state.copyWith(isLoading: true, currentUserId: event.userId));

    // Build teams from the auth response
    final List<Team> teams = [];
    String clubId = '';

    if (event.teams.isNotEmpty) {
      for (final t in event.teams) {
        final teamId = t['teamId']?.toString() ?? '';
        final teamName = t['teamName']?.toString() ?? '';
        final tClubId = t['clubId']?.toString() ?? '';
        final role = t['role']?.toString() ?? event.fallbackRole;

        if (clubId.isEmpty) clubId = tClubId;

        teams.add(Team(
          id: teamId,
          country: '',
          club: teamName,
          sport: 'Basketball', // Default — backend doesn't provide sport in auth response
          category: '',
          memberRoles: {event.userId: role},
        ));
      }
    }

    // If we have clubs but no teams, try to load teams from the first club
    if (teams.isEmpty && event.clubs.isNotEmpty) {
      clubId = event.clubs.first['clubId']?.toString() ?? '';
      if (clubId.isNotEmpty) {
        try {
          final response = await ApiClient.get('/clubs/$clubId/teams');
          final data = ApiClient.decodeListResponse(response);
          for (final t in data) {
            final map = t as Map<String, dynamic>;
            teams.add(Team(
              id: map['teamId']?.toString() ?? map['id']?.toString() ?? '',
              country: '',
              club: map['teamName']?.toString() ?? map['name']?.toString() ?? '',
              sport: map['sport']?.toString() ?? 'Basketball',
              category: map['categoryName']?.toString() ?? '',
              memberRoles: {event.userId: event.fallbackRole},
            ));
          }
        } catch (_) {
          // API call failed — continue with empty teams
        }
      }
    }

    if (teams.isEmpty) {
      // No teams at all — fresh account
      emit(state.copyWith(
        currentUserId: event.userId,
        userRoleInSelectedTeam: event.fallbackRole,
        availableTeams: const [],
        isLoading: false,
        activeClubId: clubId,
      ));
      return;
    }

    final selectedTeam = teams.first;
    final selectedTeamId = selectedTeam.id;

    emit(state.copyWith(
      currentUserId: event.userId,
      availableTeams: teams,
      selectedTeamId: selectedTeamId,
      selectedTeamName: '${selectedTeam.club} ${selectedTeam.category}'.trim(),
      userRoleInSelectedTeam:
          selectedTeam.memberRoles[event.userId] ?? event.fallbackRole,
      activeClubId: clubId,
      isLoading: false,
    ));

    // Trigger member loading for the selected team
    add(LoadTeamMembers());
  }

  void _onRegisterTeam(RegisterTeam event, Emitter<TeamState> emit) {
    final String userId = state.currentUserId;
    final String generatedId = event.team.id.isNotEmpty
        ? event.team.id
        : 'team-${DateTime.now().millisecondsSinceEpoch}';
    final team = event.team.copyWith(
      id: generatedId,
      memberRoles: {
        ...event.team.memberRoles,
        if (userId.isNotEmpty) userId: event.fallbackRole,
      },
    );

    final updatedTeams = List<Team>.from(state.availableTeams)..add(team);

    emit(
      state.copyWith(
        availableTeams: updatedTeams,
      ),
    );
  }

  void _onSwitchTeamContext(SwitchTeamContext event, Emitter<TeamState> emit) {
    final targetTeam = state.availableTeams.firstWhere(
      (team) => team.id == event.teamId,
      orElse: () => state.availableTeams.isNotEmpty
          ? state.availableTeams.first
          : Team(
              country: '',
              club: 'My Team',
              sport: 'Basketball',
              category: '',
            ),
    );
    if (targetTeam.id.isEmpty && state.availableTeams.isEmpty) {
      return;
    }

    final userRole =
        targetTeam.memberRoles[state.currentUserId] ??
        state.userRoleInSelectedTeam;

    // Use cached members if available, otherwise trigger API load
    final cachedMembers = state.membersByTeamId[targetTeam.id];

    emit(
      state.copyWith(
        selectedTeamId: targetTeam.id,
        selectedTeamName: '${targetTeam.club} ${targetTeam.category}'.trim(),
        userRoleInSelectedTeam: userRole,
        members: cachedMembers ?? const [],
        clearPermissionError: true,
      ),
    );

    // If no cached members, load from API
    if (cachedMembers == null || cachedMembers.isEmpty) {
      add(LoadTeamMembers());
    }
  }

  void _onClearPermissionError(
    ClearPermissionError event,
    Emitter<TeamState> emit,
  ) {
    emit(state.copyWith(clearPermissionError: true));
  }

  void _onUpdateMemberStatus(
    UpdateMemberStatus event,
    Emitter<TeamState> emit,
  ) {
    if (state.userRoleInSelectedTeam.trim() != 'TeamAnalyst') {
      emit(state.copyWith(permissionError: 'Only Analyst can edit states.', clearPermissionError: false));
      return;
    }

    final updatedMembers = List<Member>.from(state.members);
    final member = updatedMembers[event.index];
    updatedMembers[event.index] = Member(
      name: member.name,
      role: member.role,
      image: member.image,
      age: member.age,
      isInSquad: event.isInSquad,
      medicalPdfUrl: member.medicalPdfUrl,
      medicalPdfName: member.medicalPdfName,
      fitnessPdfUrl: member.fitnessPdfUrl,
      fitnessPdfName: member.fitnessPdfName,
      analysisPdfUrl: member.analysisPdfUrl,
      analysisPdfName: member.analysisPdfName,
      videoUrl: member.videoUrl,
      videoFileName: member.videoFileName,
      medicalNotes: member.medicalNotes,
      injuryType: member.injuryType,
      absencePeriod: member.absencePeriod,
    );

    final updatedMap = <String, List<Member>>{
      ...state.membersByTeamId,
      state.selectedTeamId: updatedMembers,
    };

    emit(
      state.copyWith(
        members: updatedMembers,
        membersByTeamId: updatedMap,
        clearPermissionError: true,
      ),
    );
  }

  void _onUpdateMemberData(UpdateMemberData event, Emitter<TeamState> emit) {
    if (event.requiresStateEditPermission &&
        state.userRoleInSelectedTeam.trim() != 'TeamAnalyst') {
      emit(state.copyWith(permissionError: 'Only Analyst can edit states.', clearPermissionError: false));
      return;
    }

    final updatedMembers = List<Member>.from(state.members);
    updatedMembers[event.index] = event.member;

    final updatedMap = <String, List<Member>>{
      ...state.membersByTeamId,
      state.selectedTeamId: updatedMembers,
    };

    emit(
      state.copyWith(
        members: updatedMembers,
        membersByTeamId: updatedMap,
        clearPermissionError: true,
      ),
    );
  }

  void _onAddTeamMember(AddTeamMember event, Emitter<TeamState> emit) {
    final updatedMembers = List<Member>.from(state.members)..add(event.member);
    final updatedMap = <String, List<Member>>{
      ...state.membersByTeamId,
      state.selectedTeamId: updatedMembers,
    };

    emit(state.copyWith(members: updatedMembers, membersByTeamId: updatedMap));
  }
}
