import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../core/api_client.dart';
import '../core/preferences_service.dart';
import '../core/secure_storage_service.dart';

// ─────────────────────────────────────────────
// Events
// ─────────────────────────────────────────────

abstract class AuthEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Login with email + password. No role — backend returns roles.
class LoginRequested extends AuthEvent {
  final String email;
  final String password;
  LoginRequested({required this.email, required this.password});

  @override
  List<Object?> get props => [email, password];
}

/// Register a new account.
class SignUpRequested extends AuthEvent {
  final String email;
  final String name;
  final String password;
  final String? dob; // "YYYY-MM-DD"

  SignUpRequested({
    required this.email,
    required this.name,
    required this.password,
    this.dob,
  });

  @override
  List<Object?> get props => [email, name, password, dob];
}

class LogoutRequested extends AuthEvent {}

/// Fired at app startup to check if a stored session is still valid.
class AuthRestoreRequested extends AuthEvent {}

// ─────────────────────────────────────────────
// States
// ─────────────────────────────────────────────

abstract class AuthState extends Equatable {
  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class Authenticated extends AuthState {
  /// Primary role from `user.roles[0]` (backend enum: Coach, Player, etc.)
  final String role;

  /// Backend user ID (GUID).
  final String userId;

  /// User's email.
  final String email;

  /// User's display name.
  final String name;

  /// Whether the user is an admin.
  final bool isAdmin;

  /// All roles from the backend.
  final List<String> roles;

  /// Clubs the user belongs to: [{clubId, clubName, role}]
  final List<Map<String, dynamic>> clubs;

  /// Teams the user belongs to: [{teamId, teamName, clubId, role}]
  final List<Map<String, dynamic>> teams;

  Authenticated({
    required this.role,
    required this.userId,
    required this.email,
    required this.name,
    this.isAdmin = false,
    this.roles = const [],
    this.clubs = const [],
    this.teams = const [],
  });

  @override
  List<Object?> get props =>
      [role, userId, email, name, isAdmin, roles, clubs, teams];
}

class AuthError extends AuthState {
  final String message;
  AuthError(this.message);
  @override
  List<Object?> get props => [message];
}

// ─────────────────────────────────────────────
// Bloc
// ─────────────────────────────────────────────

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc() : super(AuthInitial()) {
    on<LoginRequested>(_onLoginRequested);
    on<SignUpRequested>(_onSignUpRequested);
    on<LogoutRequested>(_onLogoutRequested);
    on<AuthRestoreRequested>(_onAuthRestoreRequested);
  }

  // ── Login ──

  Future<void> _onLoginRequested(
    LoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final response = await ApiClient.post('/auth/login', body: {
        'email': event.email.trim(),
        'password': event.password,
      });

      final data = ApiClient.decodeResponse(response);
      await _persistAndEmit(data, emit);
    } on ApiException catch (e) {
      emit(AuthError(e.message));
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  // ── Sign Up ──

  Future<void> _onSignUpRequested(
    SignUpRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final body = <String, dynamic>{
        'email': event.email.trim(),
        'password': event.password,
        'name': event.name.trim(),
      };
      if (event.dob != null && event.dob!.isNotEmpty) {
        body['dob'] = event.dob;
      }

      final response = await ApiClient.post('/auth/register', body: body);
      final data = ApiClient.decodeResponse(response);
      await _persistAndEmit(data, emit);
    } on ApiException catch (e) {
      emit(AuthError(e.message));
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  // ── Logout ──

  Future<void> _onLogoutRequested(
    LogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    try {
      final refreshToken = await SecureStorageService.getRefreshToken();
      if (refreshToken != null) {
        await ApiClient.post('/auth/logout', body: {
          'refreshToken': refreshToken,
        });
      }
    } catch (_) {
      // Ignore logout errors
    }
    await SecureStorageService.clearTokens();
    await PreferencesService.setLoggedIn(false);
    emit(AuthInitial());
  }

  // ── Restore session on app startup ──

  Future<void> _onAuthRestoreRequested(
    AuthRestoreRequested event,
    Emitter<AuthState> emit,
  ) async {
    final token = await SecureStorageService.getAccessToken();
    if (token == null) {
      emit(AuthInitial());
      return;
    }

    // We have a stored token — try to use the cached user data.
    final userJson = await SecureStorageService.getUser();
    if (userJson != null) {
      emit(_buildAuthenticated(userJson));
      return;
    }

    // No cached user — token exists but no user info. Clear & go to login.
    await SecureStorageService.clearTokens();
    emit(AuthInitial());
  }

  // ── Helpers ──

  Future<void> _persistAndEmit(
    Map<String, dynamic> data,
    Emitter<AuthState> emit,
  ) async {
    final accessToken = data['accessToken'] as String?;
    final refreshToken = data['refreshToken'] as String?;
    final user = data['user'] as Map<String, dynamic>?;

    if (accessToken == null || user == null) {
      emit(AuthError(data['message']?.toString() ?? 'Login failed'));
      return;
    }

    await SecureStorageService.saveTokens(
      accessToken: accessToken,
      refreshToken: refreshToken,
    );
    await SecureStorageService.saveUser(user);
    await PreferencesService.setLoggedIn(true);

    emit(_buildAuthenticated(user));
  }

  Authenticated _buildAuthenticated(Map<String, dynamic> user) {
    final roles = (user['roles'] as List<dynamic>?)
            ?.map((r) => r.toString())
            .toList() ??
        [];
    final clubs = (user['clubs'] as List<dynamic>?)
            ?.map((c) => Map<String, dynamic>.from(c as Map))
            .toList() ??
        [];
    final teams = (user['teams'] as List<dynamic>?)
            ?.map((t) => Map<String, dynamic>.from(t as Map))
            .toList() ??
        [];

    return Authenticated(
      role: roles.isNotEmpty ? roles.first : '',
      userId: user['userId']?.toString() ?? '',
      email: user['email']?.toString() ?? '',
      name: user['name']?.toString() ?? '',
      isAdmin: user['isAdmin'] == true,
      roles: roles,
      clubs: clubs,
      teams: teams,
    );
  }
}
