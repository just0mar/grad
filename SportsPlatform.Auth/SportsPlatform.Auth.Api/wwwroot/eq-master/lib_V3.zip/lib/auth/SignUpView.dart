import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../congrats/CongratsView.dart';
import '../main.dart' show OnboardingView;
import '../core/design_tokens.dart';
import '../core/responsive_system.dart';
import 'auth_bloc.dart';

class SignUpView extends StatefulWidget {
  const SignUpView({super.key});

  @override
  State<SignUpView> createState() => _SignUpViewState();
}

class _SignUpViewState extends State<SignUpView> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _dobController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    _nameController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _dobController.dispose();
    super.dispose();
  }

  void _goBackToPeak() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const OnboardingView(initialPage: 2)),
    );
  }

  InputDecoration _inputDecoration(String label, BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(fontFamily: 'SFPro'),
      filled: true,
      fillColor: isDark ? Colors.grey[900] : Colors.white,
      border: OutlineInputBorder(
        borderSide: const BorderSide(color: AppColors.primary),
        borderRadius: BorderRadius.circular(12),
      ),
      enabledBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: AppColors.primary),
        borderRadius: BorderRadius.circular(12),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: AppColors.primary, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final padding = ResponsiveSystem.pagePadding(context);

    return BlocProvider(
      create: (context) => AuthBloc(),
      child: BlocListener<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is Authenticated) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                settings: const RouteSettings(name: '/'),
                builder: (_) => CongratsView(
                  selectedRole: state.role,
                  userId: state.userId,
                  clubs: state.clubs,
                  teams: state.teams,
                ),
              ),
            );
          } else if (state is AuthError) {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(SnackBar(content: Text(state.message)));
          }
        },
        child: Scaffold(
          extendBodyBehindAppBar: true,
          body: Builder(
            builder: (context) {
              return SizedBox.expand(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: isDark
                          ? [Colors.black, Colors.black87]
                          : [Colors.green, Colors.white],
                    ),
                    image: const DecorationImage(
                      image: AssetImage("assets/background.png"),
                      fit: BoxFit.cover,
                      opacity: 0.15,
                    ),
                  ),
                  child: SafeArea(
                    child: SingleChildScrollView(
                      padding: padding,
                      child: Center(
                        child: Container(
                          constraints: BoxConstraints(
                            maxWidth: ResponsiveSystem.mobileMaxWidth,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(
                                      Icons.arrow_back,
                                      color: isDark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                    onPressed: _goBackToPeak,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    "SIGN UP",
                                    style: TextStyle(
                                      fontFamily: 'Facon',
                                      fontSize: ResponsiveSystem.titleFontSize(
                                        context,
                                      ),
                                      fontWeight: FontWeight.bold,
                                      color: isDark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: ResponsiveSystem.verticalGap(context),
                              ),
                              TextField(
                                controller: _emailController,
                                decoration: _inputDecoration(
                                  "Email/ Phone number",
                                  context,
                                ),
                                style: TextStyle(
                                  color: isDark ? Colors.white : Colors.black,
                                ),
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: _nameController,
                                decoration: _inputDecoration("Name", context),
                                style: TextStyle(
                                  color: isDark ? Colors.white : Colors.black,
                                ),
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: _passwordController,
                                obscureText: true,
                                decoration: _inputDecoration(
                                  "Password",
                                  context,
                                ),
                                style: TextStyle(
                                  color: isDark ? Colors.white : Colors.black,
                                ),
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: _confirmPasswordController,
                                obscureText: true,
                                decoration: _inputDecoration(
                                  "Confirm Password",
                                  context,
                                ),
                                style: TextStyle(
                                  color: isDark ? Colors.white : Colors.black,
                                ),
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: _dobController,
                                keyboardType: TextInputType.datetime,
                                decoration: _inputDecoration("Date of Birth (YYYY-MM-DD)", context),
                                style: TextStyle(
                                  color: isDark ? Colors.white : Colors.black,
                                ),
                              ),
                              const SizedBox(height: 32),
                              BlocBuilder<AuthBloc, AuthState>(
                                builder: (context, state) {
                                  return ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.green,
                                      minimumSize: const Size(
                                        double.infinity,
                                        48,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                    onPressed: state is AuthLoading
                                        ? null
                                        : () {
                                            if (_passwordController.text !=
                                                _confirmPasswordController
                                                    .text) {
                                              ScaffoldMessenger.of(
                                                context,
                                              ).showSnackBar(
                                                const SnackBar(
                                                  content: Text(
                                                    "Passwords do not match",
                                                  ),
                                                ),
                                              );
                                              return;
                                            }
                                            context.read<AuthBloc>().add(
                                              SignUpRequested(
                                                email: _emailController.text,
                                                name: _nameController.text,
                                                password:
                                                    _passwordController.text,
                                                dob: _dobController.text.trim().isNotEmpty
                                                    ? _dobController.text.trim()
                                                    : null,
                                              ),
                                            );
                                          },
                                    child: state is AuthLoading
                                        ? const CircularProgressIndicator(
                                            color: Colors.white,
                                          )
                                        : const Text(
                                            "Finish sign up",
                                            style: TextStyle(
                                              fontFamily: 'SFPro',
                                              color: Colors.white,
                                            ),
                                          ),
                                  );
                                },
                              ),
                              const SizedBox(height: 24),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
