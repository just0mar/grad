import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import '../team/team_bloc.dart';
import '../core/responsive_widgets.dart';
import '../core/secure_storage_service.dart';
import '../core/role_access.dart';

class ProfileView extends StatefulWidget {
  final List<Map<String, dynamic>> plans;

  const ProfileView({
    super.key,
    required this.plans,
  });

  @override
  State<ProfileView> createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  String _userName = '';
  String _userEmail = '';
  String _userRole = '';
  String _userId = '';

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final user = await SecureStorageService.getUser();
    if (user != null && mounted) {
      final roles = (user['roles'] as List<dynamic>?)?.map((r) => r.toString()).toList() ?? [];
      setState(() {
        _userName = user['name']?.toString() ?? '';
        _userEmail = user['email']?.toString() ?? '';
        _userId = user['userId']?.toString() ?? '';
        _userRole = roles.isNotEmpty ? roleLabel(roles.first) : '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark
        ? const Color(0xFF1B3A2D)
        : Colors.white.withValues(alpha: 0.9);
    final textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(
        title: "Profile",
        plans: widget.plans,
      ),
      body: BlocBuilder<TeamBloc, TeamState>(
        builder: (context, state) {
          // Typically we'd find the current user's data in the state.
          // For now, we'll keep the UI hardcoded but remove the Provider dependency.
          return SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: isDark
                      ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                      : [Colors.green, Colors.white],
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.2,
                ),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: MediaQuery.of(context).size.height - (kToolbarHeight + 48),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: kToolbarHeight + 48),

                      // ── Profile card ──
                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.fromLTRB(90, 20, 20, 20),
                            decoration: BoxDecoration(
                              color: cardBg,
                              borderRadius: BorderRadius.circular(25),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.05),
                                  blurRadius: 15,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _userName.isNotEmpty ? _userName : 'Loading...',
                                  style: TextStyle(
                                    fontFamily: 'SFPro',
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                    color: textColor,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  _userEmail.isNotEmpty ? _userEmail : '...',
                                  style: TextStyle(
                                    fontFamily: 'SFPro',
                                    fontSize: 14,
                                    color: isDark ? Colors.white54 : Colors.grey,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  "Bio",
                                  style: TextStyle(
                                    fontFamily: 'SFPro',
                                    fontWeight: FontWeight.w600,
                                    color: textColor,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  "\"Former pro player | Youth development specialist | FIBA certified coach\"",
                                  style: TextStyle(
                                    fontFamily: 'SFPro',
                                    fontSize: 13,
                                    color: isDark ? Colors.white70 : Colors.black87,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            left: -10,
                            top: 10,
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: isDark
                                      ? const Color(0xFF1B3A2D)
                                      : Colors.white,
                                  width: 4,
                                ),
                              ),
                              child: const CircleAvatar(
                                radius: 45,
                                backgroundImage: AssetImage("assets/profile.png"),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 60,
                            top: 60,
                            child: GestureDetector(
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const EditProfileView(),
                                ),
                              ),
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: const BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.edit, color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 25),

                      // ── Info card ──
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: cardBg,
                          borderRadius: BorderRadius.circular(25),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.05),
                              blurRadius: 15,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            _InfoRow(
                              title: "Role",
                              value: _userRole.isNotEmpty ? _userRole : '...',
                              isDark: isDark,
                            ),
                            const SizedBox(height: 12),
                            _InfoRow(
                              title: "ID",
                              value: _userId.isNotEmpty ? _userId.substring(0, _userId.length > 8 ? 8 : _userId.length) : '...',
                              isDark: isDark,
                            ),
                            const SizedBox(height: 12),
                            _InfoRow(title: "Age", value: "35 yrs", isDark: isDark),
                            const SizedBox(height: 12),
                            _InfoRow(
                              title: "Years of experience",
                              value: "10 yrs",
                              isDark: isDark,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30),

                      Text(
                        "AHMED'S TEAMS",
                        style: TextStyle(
                          fontFamily: 'Facon',
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                          color: textColor,
                        ),
                      ),
                      const SizedBox(height: 15),
                      Row(
                        children: const [
                          Expanded(
                            child: _TeamCard(
                              title: "ITTIHAD U16\nBOYS A",
                              gradientColors: [
                                Color(0xFF7ED957),
                                Color(0xFF3DAE2B),
                              ],
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: _TeamCard(
                              title: "SMOUHA U14\nGIRLS B",
                              gradientColors: [
                                Color(0xFF8BB8FF),
                                Color(0xFF4E7DCC),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Edit Profile View — uses CustomAppBar
// ─────────────────────────────────────────────

class EditProfileView extends StatelessWidget {
  const EditProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldColor = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final labelColor = isDark ? Colors.white70 : Colors.black54;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const CustomAppBar(title: "Edit Profile"),
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                  : [Colors.green, Colors.white],
            ),
            image: const DecorationImage(
              image: AssetImage("assets/background.png"),
              fit: BoxFit.cover,
              opacity: 0.2,
            ),
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height - (kToolbarHeight + 48),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: kToolbarHeight + 48),

                  const SizedBox(height: 25),

                  TextFormField(
                    initialValue: "Ahmed Mahmoud",
                    style: TextStyle(fontFamily: 'SFPro', color: textColor),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: fieldColor,
                      labelText: "Name",
                      labelStyle: TextStyle(fontFamily: 'SFPro', color: labelColor),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: isDark ? Colors.white12 : Colors.grey.shade300,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    initialValue: "AhmedMahmoudC@gmail.com",
                    style: TextStyle(fontFamily: 'SFPro', color: textColor),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: fieldColor,
                      labelText: "Email",
                      labelStyle: TextStyle(fontFamily: 'SFPro', color: labelColor),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: isDark ? Colors.white12 : Colors.grey.shade300,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    initialValue:
                        "Former pro player | Youth development specialist | FIBA certified coach",
                    style: TextStyle(fontFamily: 'SFPro', color: textColor),
                    maxLines: 2,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: fieldColor,
                      labelText: "Bio",
                      labelStyle: TextStyle(fontFamily: 'SFPro', color: labelColor),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: isDark ? Colors.white12 : Colors.grey.shade300,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),

                  Row(
                    children: [
                      Expanded(
                        child: ResponsivePrimaryButton(
                          context: context,
                          label: "Save changes",
                          onPressed: () => Navigator.pop(context),
                          backgroundColor: Colors.green,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: ResponsivePrimaryButton(
                          context: context,
                          label: "Remove",
                          onPressed: () => Navigator.pop(context),
                          backgroundColor: Colors.red,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Helper Widgets
// ─────────────────────────────────────────────

class _InfoRow extends StatelessWidget {
  final String title;
  final String value;
  final bool isDark;

  const _InfoRow({
    required this.title,
    required this.value,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(fontFamily: 'SFPro', color: isDark ? Colors.white54 : Colors.grey),
        ),
        Text(
          value,
          style: TextStyle(
            fontFamily: 'SFPro',
            fontWeight: FontWeight.w600,
            color: isDark ? Colors.white : Colors.black,
          ),
        ),
      ],
    );
  }
}

class _TeamCard extends StatelessWidget {
  final String title;
  final List<Color> gradientColors;

  const _TeamCard({required this.title, required this.gradientColors});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.2,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Align(
        alignment: Alignment.bottomLeft,
        child: Text(
          title,
          style: const TextStyle(
            fontFamily: 'SFPro',
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}
