import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../core/responsive_system.dart';
import '../team/team_bloc.dart';
import '../event/event_bloc.dart';
import '../event/EventModel.dart';
import 'MemberModel.dart';

class GameSquadView extends StatelessWidget {
  const GameSquadView({super.key});

  Event? _getNextMatch(List<Event> events) {
    final now = DateTime.now();
    final matches = events
        .where((e) => e.type.trim() == "Match" && e.date.isAfter(now))
        .toList();
    if (matches.isEmpty) return null;
    matches.sort((a, b) => a.date.compareTo(b.date));
    return matches.first;
  }

  void _saveSquad(BuildContext context) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("Squad saved successfully!")));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;
    final subTextColor = isDark ? Colors.white54 : Colors.black54;

    return BlocBuilder<EventBloc, EventState>(
      builder: (context, eventState) {
        final nextMatch = _getNextMatch(eventState.events);

        return BlocConsumer<TeamBloc, TeamState>(
          listener: (context, teamState) {
            if (teamState.permissionError != null &&
                teamState.permissionError!.isNotEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(teamState.permissionError!)),
              );
              context.read<TeamBloc>().add(ClearPermissionError());
            }
          },
          builder: (context, teamState) {
            final eligible = teamState.members
                .where((m) => m.role == "Player" && !m.isInjured)
                .toList();
            final injured = teamState.members
                .where((m) => m.role == "Player" && m.isInjured)
                .toList();
            final bool canEditStates =
                teamState.userRoleInSelectedTeam.trim() == 'TeamAnalyst';

            return Scaffold(
              extendBodyBehindAppBar: true,
              appBar: const CustomAppBar(title: "Add GameSquad"),
              body: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isDark
                        ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                        : [Colors.green, Colors.white],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  image: const DecorationImage(
                    image: AssetImage("assets/background.png"),
                    fit: BoxFit.cover,
                    opacity: 0.2,
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    children: [
                      SizedBox(height: ResponsiveSystem.verticalGap(context)),
                      Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: ResponsiveSystem.horizontalPadding(
                            context,
                          ),
                        ),
                        child: nextMatch == null
                            ? _buildNoMatchBanner(isDark)
                            : _buildMatchBanner(context, nextMatch),
                      ),
                      SizedBox(height: ResponsiveSystem.verticalGap(context)),
                      if (nextMatch == null)
                        Expanded(
                          child: Center(
                            child: Text(
                              "No upcoming match found.\nAdd a Match event first.",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: subTextColor,
                                fontSize: ResponsiveSystem.bodyFontSize(
                                  context,
                                ),
                              ),
                            ),
                          ),
                        )
                      else
                        Expanded(
                          child: SingleChildScrollView(
                            padding: EdgeInsets.symmetric(
                              horizontal: ResponsiveSystem.horizontalPadding(
                                context,
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "SELECT PLAYERS",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                    letterSpacing: 0.5,
                                    color: subTextColor,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  canEditStates
                                      ? 'Analyst mode: state editing enabled'
                                      : 'State editing is locked for this role',
                                  style: TextStyle(
                                    color: canEditStates
                                        ? AppColors.primary
                                        : Colors.orange,
                                    fontSize: 12,
                                  ),
                                ),
                                const SizedBox(height: AppSpacing.xs),
                                if (eligible.isEmpty)
                                  _buildEmptyState(
                                    "No eligible players available",
                                    subTextColor,
                                  ),
                                ...eligible.map((member) {
                                  final globalIndex = teamState.members.indexOf(
                                    member,
                                  );
                                  return _buildPlayerCheckTile(
                                    context,
                                    member,
                                    globalIndex,
                                    eligible: true,
                                    isDark: isDark,
                                    cardBg: cardBg,
                                    textColor: textColor,
                                    subTextColor: subTextColor,
                                    canEditStates: canEditStates,
                                  );
                                }),
                                if (injured.isNotEmpty) ...[
                                  const SizedBox(height: 16),
                                  const Text(
                                    "UNAVAILABLE (INJURED)",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                      letterSpacing: 0.5,
                                      color: Colors.red,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  ...injured.map(
                                    (m) => _buildPlayerCheckTile(
                                      context,
                                      m,
                                      -1,
                                      eligible: false,
                                      isDark: isDark,
                                      cardBg: cardBg,
                                      textColor: textColor,
                                      subTextColor: subTextColor,
                                      canEditStates: canEditStates,
                                    ),
                                  ),
                                ],
                                const SizedBox(height: 80),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              bottomNavigationBar: nextMatch == null
                  ? null
                  : Padding(
                      padding: EdgeInsets.all(
                        ResponsiveSystem.horizontalPadding(context),
                      ),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          minimumSize: Size(
                            double.infinity,
                            ResponsiveSystem.buttonHeight(context),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: () => _saveSquad(context),
                        child: const Text(
                          "Save Squad",
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      ),
                    ),
            );
          },
        );
      },
    );
  }

  Widget _buildMatchBanner(BuildContext context, Event match) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: Colors.green.shade700,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "NEXT MATCH",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            "Match — ${match.date.day}/${match.date.month}/${match.date.year}",
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          Text(
            match.time.format(context),
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
          if (match.description.isNotEmpty)
            Text(
              match.description,
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
        ],
      ),
    );
  }

  Widget _buildNoMatchBanner(bool isDark) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF2A1F00) : Colors.orange.shade100,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? Colors.orange.shade800 : Colors.orange.shade300,
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.info_outline,
            color: isDark ? Colors.orange.shade300 : Colors.orange.shade700,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              "No upcoming match scheduled yet.",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white70 : Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerCheckTile(
    BuildContext context,
    Member member,
    int globalIndex, {
    required bool eligible,
    required bool isDark,
    required Color cardBg,
    required Color textColor,
    required Color subTextColor,
    required bool canEditStates,
  }) {
    final disabledBg = isDark ? const Color(0xFF141414) : Colors.grey.shade100;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: eligible ? cardBg : disabledBg,
        borderRadius: BorderRadius.circular(16),
        boxShadow: eligible
            ? [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                ),
              ]
            : [],
      ),
      child: ListTile(
        leading: Stack(
          children: [
            CircleAvatar(backgroundImage: AssetImage(member.image), radius: 22),
            if (!eligible)
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: 14,
                  height: 16,
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close, color: Colors.white, size: 10),
                ),
              ),
          ],
        ),
        title: Text(
          member.name,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: eligible
                ? textColor
                : (isDark ? Colors.white24 : Colors.black38),
          ),
        ),
        subtitle: eligible
            ? null
            : Text(
                member.injuryType.isNotEmpty ? member.injuryType : "Injured",
                style: const TextStyle(color: Colors.red, fontSize: 12),
              ),
        trailing: eligible
            ? Checkbox(
                value: member.isInSquad,
                activeColor: Colors.green,
                checkColor: Colors.white,
                side: BorderSide(
                  color: isDark ? Colors.white38 : Colors.grey.shade400,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                onChanged: (val) {
                  if (!canEditStates) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Only Analyst can edit states.'),
                      ),
                    );
                    return;
                  }
                  context.read<TeamBloc>().add(
                    UpdateMemberStatus(globalIndex, val ?? false),
                  );
                },
              )
            : const Icon(Icons.lock, color: Colors.grey, size: 20),
      ),
    );
  }

  Widget _buildEmptyState(String msg, Color subTextColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Text(msg, style: TextStyle(color: subTextColor, fontSize: 14)),
    );
  }
}
