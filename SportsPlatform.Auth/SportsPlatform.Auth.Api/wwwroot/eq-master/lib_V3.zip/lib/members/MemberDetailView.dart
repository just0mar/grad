import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fl_chart/fl_chart.dart';
import '../appbar/CustomAppBar.dart';
import '../core/design_tokens.dart';
import '../core/api_client.dart';
import '../team/team_bloc.dart';
import 'MemberDetailModel.dart';
import 'MemberModel.dart';

class MemberDetailView extends StatefulWidget {
  final Member member;
  final int memberIndex;

  const MemberDetailView({
    super.key,
    required this.member,
    required this.memberIndex,
  });

  @override
  State<MemberDetailView> createState() => _MemberDetailViewState();
}

class _MemberDetailViewState extends State<MemberDetailView> {
  List<PlayerStat> _playerStats = [];
  List<FitnessRecord> _fitnessRecords = [];
  List<MedicalRecord> _medicalRecords = [];
  List<FlSpot> _chartLine1 = [];
  List<FlSpot> _chartLine2 = [];
  List<FlSpot> _chartLine3 = [];
  bool _isLoadingDetails = false;

  @override
  void initState() {
    super.initState();
    _loadPlayerData();
  }

  Future<void> _loadPlayerData() async {
    final teamState = context.read<TeamBloc>().state;
    final clubId = teamState.activeClubId;
    final teamId = teamState.selectedTeamId;
    final playerUserId = widget.member.userId;

    if (clubId.isEmpty || teamId.isEmpty || playerUserId.isEmpty) return;
    if (widget.member.role.trim() != 'Player') return;

    setState(() => _isLoadingDetails = true);

    // Load player stats
    try {
      final response = await ApiClient.get(
        '/clubs/$clubId/teams/$teamId/stats/players/$playerUserId',
      );
      final data = ApiClient.decodeResponse(response);
      if (mounted) {
        final List<PlayerStat> stats = [];
        data.forEach((key, value) {
          if (value is Map) {
            stats.add(PlayerStat(
              title: key.toString(),
              lastGame: value['lastGame']?.toString() ?? '-',
              cumulative: value['cumulative']?.toString() ?? '-',
            ));
          } else if (value is num) {
            stats.add(PlayerStat(
              title: key.toString(),
              lastGame: '-',
              cumulative: value.toString(),
            ));
          }
        });
        if (stats.isNotEmpty) {
          setState(() => _playerStats = stats);
        }
      }
    } catch (_) {
      // Stats not available — keep empty
    }

    // Load player match history for chart data
    try {
      final response = await ApiClient.get(
        '/clubs/$clubId/teams/$teamId/stats/players/$playerUserId/matches',
      );
      final data = ApiClient.decodeListResponse(response);
      if (mounted && data.isNotEmpty) {
        final List<FlSpot> line1 = [];
        final List<FlSpot> line2 = [];
        final List<FlSpot> line3 = [];
        for (int i = 0; i < data.length && i < 6; i++) {
          final map = data[i] as Map<String, dynamic>;
          line1.add(FlSpot(i.toDouble(), (map['points'] ?? map['goals'] ?? 0).toDouble()));
          line2.add(FlSpot(i.toDouble(), (map['rebounds'] ?? map['assists'] ?? 0).toDouble()));
          line3.add(FlSpot(i.toDouble(), (map['blocks'] ?? map['saves'] ?? 0).toDouble()));
        }
        setState(() {
          _chartLine1 = line1;
          _chartLine2 = line2;
          _chartLine3 = line3;
        });
      }
    } catch (_) {
      // Chart data not available
    }

    // Load fitness records
    try {
      final response = await ApiClient.get(
        '/clubs/$clubId/teams/$teamId/players/$playerUserId/fitness',
      );
      final data = ApiClient.decodeListResponse(response);
      if (mounted && data.isNotEmpty) {
        final records = data.map((r) {
          final map = r as Map<String, dynamic>;
          return FitnessRecord(
            label: map['label']?.toString() ?? map['metricName']?.toString() ?? '',
            value: map['value']?.toString() ?? map['metricValue']?.toString() ?? '-',
          );
        }).toList();
        setState(() => _fitnessRecords = records);
      }
    } catch (_) {
      // Fitness records not available
    }

    // Load medical records
    try {
      final response = await ApiClient.get(
        '/clubs/$clubId/teams/$teamId/players/$playerUserId/medical',
      );
      final data = ApiClient.decodeListResponse(response);
      if (mounted && data.isNotEmpty) {
        final records = data.map((r) {
          final map = r as Map<String, dynamic>;
          return MedicalRecord(
            title: map['diagnosis']?.toString() ?? map['title']?.toString() ?? map['injuryType']?.toString() ?? '',
            status: map['status']?.toString() ?? map['clearanceStatus']?.toString() ?? '',
            startDate: map['startDate']?.toString() ?? map['injuryDate']?.toString(),
            endDate: map['endDate']?.toString() ?? map['returnDate']?.toString(),
          );
        }).toList();
        setState(() => _medicalRecords = records);
      }
    } catch (_) {
      // Medical records not available
    }

    if (mounted) {
      setState(() => _isLoadingDetails = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TeamBloc, TeamState>(
      builder: (context, state) {
        // Use the member from state to ensure it's reactive
        final currentMember = state.members.length > widget.memberIndex
            ? state.members[widget.memberIndex]
            : widget.member;

        final isDark = Theme.of(context).brightness == Brightness.dark;
        final cardBg = isDark ? const Color(0xFF1B3A2D) : Colors.white;
        final textColor = isDark ? Colors.white : Colors.black;
        final subTextColor = isDark ? Colors.white54 : Colors.black54;

        final List<FlSpot> threePointsData = _chartLine1.isNotEmpty
            ? _chartLine1
            : const [
                FlSpot(0, 0), FlSpot(1, 0), FlSpot(2, 0),
                FlSpot(3, 0), FlSpot(4, 0), FlSpot(5, 0),
              ];
        final List<FlSpot> reboundsData = _chartLine2.isNotEmpty
            ? _chartLine2
            : const [
                FlSpot(0, 0), FlSpot(1, 0), FlSpot(2, 0),
                FlSpot(3, 0), FlSpot(4, 0), FlSpot(5, 0),
              ];
        final List<FlSpot> blocksData = _chartLine3.isNotEmpty
            ? _chartLine3
            : const [
                FlSpot(0, 0), FlSpot(1, 0), FlSpot(2, 0),
                FlSpot(3, 0), FlSpot(4, 0), FlSpot(5, 0),
              ];

        final List<PlayerStat> playerStats = _playerStats;
        final List<FitnessRecord> fitnessRecords = _fitnessRecords;
        final List<MedicalRecord> medicalRecords = _medicalRecords;

        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: CustomAppBar(title: currentMember.name),
          body: SizedBox.expand(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF0A1F15), const Color(0xFF020806)]
                      : [Colors.green, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                image: const DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.cover,
                  opacity: 0.2,
                ),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.only(
                  top: kToolbarHeight + 48,
                  left: 16,
                  right: 16,
                  bottom: 16,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildProfileCard(
                      currentMember,
                      cardBg,
                      textColor,
                      subTextColor,
                    ),
                    const SizedBox(height: 16),
                    if (currentMember.role.trim() == "Player") ...[
                      if (_isLoadingDetails)
                        const Center(child: Padding(
                          padding: EdgeInsets.all(16),
                          child: CircularProgressIndicator(color: Colors.green),
                        )),
                      _buildMedicalStatusBanner(currentMember, isDark),
                      const SizedBox(height: 16),
                      _buildSection(
                        title: "Medical PDF",
                        icon: Icons.medical_services,
                        iconColor: Colors.red,
                        textColor: textColor,
                        child: currentMember.medicalPdfUrl != null
                            ? _buildPdfCard(
                                context,
                                currentMember.medicalPdfName ?? "Medical PDF",
                                cardBg,
                                textColor,
                              )
                            : _buildEmptyState(
                                "No medical PDF uploaded yet",
                                isDark,
                                cardBg,
                              ),
                      ),
                      const SizedBox(height: 16),
                      if (currentMember.medicalNotes.isNotEmpty) ...[
                        _buildSection(
                          title: "Medical Notes",
                          icon: Icons.notes,
                          iconColor: Colors.orange,
                          textColor: textColor,
                          child: _buildInfoCard(
                            currentMember.medicalNotes,
                            cardBg,
                            textColor,
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                      _buildSection(
                        title: "Fitness Plan PDF",
                        icon: Icons.fitness_center,
                        iconColor: Colors.blue,
                        textColor: textColor,
                        child: currentMember.fitnessPdfUrl != null
                            ? _buildPdfCard(
                                context,
                                currentMember.fitnessPdfName ?? "Fitness PDF",
                                cardBg,
                                textColor,
                              )
                            : _buildEmptyState(
                                "No fitness PDF uploaded yet",
                                isDark,
                                cardBg,
                              ),
                      ),
                      const SizedBox(height: 16),
                      _buildSection(
                        title: "Performance Analysis PDF",
                        icon: Icons.bar_chart,
                        iconColor: AppColors.primary,
                        textColor: textColor,
                        child: currentMember.analysisPdfUrl != null
                            ? _buildPdfCard(
                                context,
                                currentMember.analysisPdfName ?? "Analysis PDF",
                                cardBg,
                                textColor,
                              )
                            : _buildEmptyState(
                                "No analysis PDF uploaded yet",
                                isDark,
                                cardBg,
                              ),
                      ),
                      const SizedBox(height: 24),
                      _buildSectionHeader(
                        "PLAYER ANALYSIS",
                        Icons.bar_chart,
                        AppColors.primary,
                        textColor,
                      ),
                      const SizedBox(height: 12),
                      _buildAnalysisChart(
                        context,
                        isDark,
                        cardBg,
                        textColor,
                        subTextColor,
                        threePointsData,
                        reboundsData,
                        blocksData,
                      ),
                      const SizedBox(height: 16),
                      _buildAnalysisStatsTable(
                        isDark,
                        cardBg,
                        textColor,
                        subTextColor,
                        playerStats,
                      ),
                      const SizedBox(height: 24),
                      _buildSectionHeader(
                        "PLAYER FITNESS RECORDS",
                        Icons.fitness_center,
                        Colors.blue,
                        textColor,
                      ),
                      const SizedBox(height: 12),
                      _buildFitnessTable(
                        isDark,
                        cardBg,
                        textColor,
                        fitnessRecords,
                      ),
                      const SizedBox(height: 24),
                      _buildSectionHeader(
                        "PLAYER MEDICAL RECORDS",
                        Icons.healing,
                        Colors.red,
                        textColor,
                      ),
                      const SizedBox(height: 12),
                      _buildMedicalRecordsList(
                        isDark,
                        cardBg,
                        textColor,
                        subTextColor,
                        medicalRecords,
                      ),
                    ],
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAnalysisChart(
    BuildContext context,
    bool isDark,
    Color cardBg,
    Color textColor,
    Color subTextColor,
    List<FlSpot> d1,
    List<FlSpot> d2,
    List<FlSpot> d3,
  ) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 20, 20, 12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.25,
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: 35,
                gridData: const FlGridData(show: true, drawVerticalLine: false),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: d1,
                    isCurved: true,
                    color: Colors.blue,
                    barWidth: 2,
                    dotData: const FlDotData(show: false),
                  ),
                  LineChartBarData(
                    spots: d2,
                    isCurved: true,
                    color: Colors.green,
                    barWidth: 2,
                    dotData: const FlDotData(show: false),
                  ),
                  LineChartBarData(
                    spots: d3,
                    isCurved: true,
                    color: Colors.lime,
                    barWidth: 2,
                    dotData: const FlDotData(show: false),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnalysisStatsTable(
    bool isDark,
    Color cardBg,
    Color textColor,
    Color subTextColor,
    List<PlayerStat> stats,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: stats
            .map(
              (s) => ListTile(
                title: Text(s.title, style: TextStyle(color: textColor)),
                trailing: Text(
                  s.cumulative,
                  style: TextStyle(color: textColor),
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _buildFitnessTable(
    bool isDark,
    Color cardBg,
    Color textColor,
    List<FitnessRecord> records,
  ) {
    return Column(
      children: records
          .map(
            (r) => Card(
              color: cardBg,
              child: ListTile(
                title: Text(r.label, style: TextStyle(color: textColor)),
                trailing: Text(r.value, style: TextStyle(color: textColor)),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildMedicalRecordsList(
    bool isDark,
    Color cardBg,
    Color textColor,
    Color subTextColor,
    List<MedicalRecord> records,
  ) {
    return Column(
      children: records
          .map(
            (r) => Card(
              color: cardBg,
              child: ListTile(
                title: Text(r.title, style: TextStyle(color: textColor)),
                subtitle: Text(r.status, style: TextStyle(color: subTextColor)),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildProfileCard(
    Member member,
    Color cardBg,
    Color textColor,
    Color subTextColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(backgroundImage: AssetImage(member.image), radius: 36),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                member.name,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: textColor,
                ),
              ),
              Text(member.role, style: TextStyle(color: subTextColor)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMedicalStatusBanner(Member member, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: member.isInjured
            ? Colors.red.withValues(alpha: 0.1)
            : Colors.green.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        member.isInjured ? "Injured: ${member.injuryType}" : "Fit to play",
        style: TextStyle(color: member.isInjured ? Colors.red : Colors.green),
      ),
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required Color iconColor,
    required Color textColor,
    required Widget child,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: iconColor, size: 20),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(color: textColor, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 8),
        child,
      ],
    );
  }

  Widget _buildSectionHeader(
    String title,
    IconData icon,
    Color color,
    Color textColor,
  ) {
    return Row(
      children: [
        Icon(icon, color: color),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(color: textColor, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _buildPdfCard(
    BuildContext context,
    String name,
    Color cardBg,
    Color textColor,
  ) {
    return Card(
      color: cardBg,
      child: ListTile(
        leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
        title: Text(name, style: TextStyle(color: textColor)),
      ),
    );
  }

  Widget _buildInfoCard(String text, Color cardBg, Color textColor) {
    return Card(
      color: cardBg,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text(text, style: TextStyle(color: textColor)),
      ),
    );
  }

  Widget _buildEmptyState(String msg, bool isDark, Color cardBg) {
    return Text(msg, style: const TextStyle(color: Colors.grey));
  }
}
